# Dad Joke Errors

## 2026-03-23T14:32:19.762Z - Joke #unknown
**Step:** pipeline
**Error:** No unused jokes found in Dadabase

## 2026-03-23T14:33:08.275Z - Joke #1
**Step:** pipeline
**Error:** Empty or invalid audio file

## 2026-03-23T14:57:08.110Z - Joke #unknown
**Step:** pipeline
**Error:** No unused jokes found in Dadabase

## 2026-03-24T11:00:01.210Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

## 2026-03-25T11:00:01.932Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

## 2026-03-26T11:00:01.934Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

## 2026-03-27T11:00:01.944Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

## 2026-03-28T11:00:01.120Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

## 2026-03-29T11:00:01.307Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

## 2026-03-30T11:00:01.847Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

## 2026-03-31T11:00:01.172Z - Joke #unknown
**Step:** pipeline
**Error:** Command failed: gog sheets get 1cXSGjCXleUK8iQweBAwLaa7j3QK2Sla-8v11CirQsuw "Sheet1!A:D" 2>&1

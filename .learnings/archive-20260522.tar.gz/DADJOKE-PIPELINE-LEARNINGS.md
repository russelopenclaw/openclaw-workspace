
## Post-Mortem: Joke #24 Dadabase Update Bug (2026-03-13 10:45 CDT)

**Issue:** Updated wrong cell in Dadabase (D24 instead of D25)
- Assumed row number = joke ID (row 24 for ID 24)
- Forgot header row shifts all data by +1 (ID 24 lives in row 25)
- Posted=TRUE written to D24 (wrong row, which contained ID 23)
- Joke #24 showed as unpublished in dashboard

**Root Cause:** Hardcoded `row = jokeId + 1` in `auto-dadjoke-runner.js`
- This formula only works if IDs are sequential starting at row 2
- Fragile: breaks if rows are deleted/inserted or IDs skip numbers

**Fix Applied:**
1. Added `findJokeRow(jokeId)` function — scans column A dynamically to find exact row
2. Added verification step — reads back cell after update, confirms value = TRUE
3. Added audit logging — logs "Found joke ID X in row Y" for traceability

**Files Modified:**
- `tools/auto-dadjoke-runner.js` — replaced hardcoded row math with dynamic lookup + verify

**Lesson:** Never assume row numbers match IDs in spreadsheets. Always query by primary key (column A), then update. Verify writes before declaring success.

**Prevention:** This fix is now in the runner script — joke #25+ will use dynamic lookup automatically.


# Task #48: Simplify Password Strategy - Analysis & Recommendations

**Status**: 🔄 IN PROGRESS  
**Date**: 2026-03-05 23:01 CST  
**Priority**: Low

---

## Current State Analysis

### Database Passwords

| System | Current Password | Storage Location | Risk Level |
|--------|-----------------|------------------|------------|
| **PostgreSQL - alfred user** | `AlfredDB2026Secure` | Hardcoded in 20+ source files | 🔴 HIGH |
| **MongoDB** | Not configured | N/A | ✅ |

**Problem**: Database password is hardcoded throughout codebase. Changing it requires editing 20+ files.

---

### Mission Control Admin

| Credential | Value | Storage | Risk |
|------------|-------|---------|------|
| Username | `wolfencj` | `.env.local`, `.env.production` | 🟡 Medium |
| Password | `203Rocky!` | `.env.local`, `.env.env.production` | 🟡 Medium |

**Current**: Using `.env` files (reasonable for local deployment)

---

### API Keys & Tokens

| Service | Token | Storage | Risk |
|---------|-------|---------|------|
| **GitHub** | `ghp_caMxhecO...` | `openclaw.json` | 🔴 HIGH |
| **Discord Bot** | `MTQ3NjA1...` | `openclaw.json` | 🔴 CRITICAL |
| **Brave API** | `BSA7RxVK...` | `openclaw.json` | 🟡 Medium |
| **GOG Keyring** | `gogkeyring-8488Carter!` | `openclaw.json` env | 🟡 Medium |
| **OpenClaw Gateway** | `1fb81db619...` | `openclaw.json` | 🟡 Medium |

**Storage**: All in `/home/kevin/.openclaw/openclaw.json` (mode 600, readable only by clawd user)

---

## Recommendations

### 1. Database Password (HIGH PRIORITY)

**Current Issue**: Hardcoded in source code

**Proposed Solution**: Use environment variable

```javascript
// In all files, change:
const POSTGRES_CONFIG = {
  password: 'AlfredDB2026Secure'
};

// To:
const POSTGRES_CONFIG = {
  password: process.env.DB_PASSWORD || 'AlfredDB2026Secure' // fallback for dev
};
```

**Implementation**:
- Add `export DB_PASSWORD="your_secure_password"` to `~/.bashrc` or systemd service env
- Update 7 core files to read from env
- Keep fallback for development
- Change password once, works everywhere

**Files to update**:
1. `mission-control/src/lib/task-tracking.ts`
2. `mission-control/src/lib/agent-status.ts`
3. `mission-control/src/lib/heartbeat.ts`
4. `mission-control/src/lib/subagents.ts`
5. `mission-control/src/app/api/subagents/[runId]/route.ts`
6. `tools/agent-status-hook-pg.js`
7. `tools/heartbeat-stuck-hook.js`
8. `tools/migrations/002-migrate-data.js`

**Effort**: 30 minutes

---

### 2. Centralized Secrets Management (MEDIUM PRIORITY)

**Current**: Secrets in `openclaw.json` (acceptable for single-user deployment)

**Better**: Use dedicated secrets manager

**Options**:

#### Option A: Passera (Lightweight, Local)
```bash
# Install
brew install pass

# Store secret
pass insert Alfred/DB_PASSWORD

# Read in code
DB_PASSWORD=$(pass Alfred/DB_PASSWORD)
```

#### Option B: Dotenv Vault
```bash
# Create .env.vault
npm install -g dotenv-vault
dotenv-vault init
dotenv-vault push

# Read in code
require('dotenv').config({ path: '.env.vault' })
```

#### Option C: Keep Current (Acceptable)
- `openclaw.json` permissions: `chmod 600`
- Secrets not in git
- Backed up securely
- **Low effort, acceptable risk for home deployment**

---

### 3. Mission Control Admin (LOW PRIORITY)

**Current**: `.env` files ✅ Good practice

**Improvement**: Use stronger password, rotate quarterly

```bash
# Generate strong password
openssl rand -base64 24

# Update .env files
ADMIN_PASSWORD=<generated_password>

# Update documented examples
```

---

### 4. GitHub Token (MEDIUM PRIORITY)

**Current**: Stored in `openclaw.json`

**Risk**: If compromised, attacker can push to repos

**Recommendations**:
1. Use `repo` scope only (not `full_control`)
2. Rotate every 90 days
3. Set expiration date in GitHub settings
4. Use fine-grained personal access token (more restrictive)

**Action**: Generate new fine-grained token with only `russelopenclaw/*` repo access

---

### 5. Discord Bot Token (HIGH PRIORITY)

**Current**: Stored in `openclaw.json`

**Risk**: Bot compromise → can send messages, join servers

**Recommendations**:
1. Rotate token immediately
2. Use environment variable
3. Set `BOT_TOKEN` env var, read in code:
   ```ts
   const token = process.env.DISCORD_BOT_TOKEN;
   ```

**Regenerate token**: https://discord.com/developers/applications

---

## Implementation Priority

| Priority | Task | Effort | Impact |
|----------|------|--------|--------|
| **1** | DB password → env var | 30 min | 🔴 High |
| **2** | Discord token → env var | 5 min | 🔴 High |
| **3** | GitHub token → fine-grained | 10 min | 🟡 Medium |
| **4** | Rotate MC password | 5 min | 🟡 Medium |
| **5** | Consider secrets manager | 1 hour | 🟡 Medium |

---

## Recommended Actions (Today)

**Do now (30 min total)**:

1. ✅ **Add environment variable support to DB config**
   - Update 7 files to use `process.env.DB_PASSWORD`
   - Add `export DB_PASSWORD="..."` to `~/.bashrc`
   - Change actual DB password

2. ✅ **Move Discord token to env**
   - `export DISCORD_BOT_TOKEN="..."`
   - Update code to read from `process.env`

3. ✅ **Document in AGENTS.md**
   - Add "Secrets Management" section
   - List all env vars needed
   - Provide setup script

**Deferred (can wait)**:
- Full secrets manager (Passera/Dotenv Vault)
- Token rotation (schedule quarterly)
- Fine-grained GitHub token (current scope is acceptable for now)

---

## Sign-Off

**Analysis by**: Alfred  
**Date**: 2026-03-05 23:01 CST  
**Recommendation**: Implement Priority 1-3 changes today (45 min total)  
**Risk if deferred**: Low (current setup is acceptable for single-user home deployment)

---

**Ready to implement these changes now, Kevin?**

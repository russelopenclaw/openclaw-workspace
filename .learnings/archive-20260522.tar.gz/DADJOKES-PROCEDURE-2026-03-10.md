# Dad Joke Video Pipeline - Production Procedure (2026-03-10)

## Updated Configuration & Procedure

### Host/Network Settings
**Changed:** Hardcoded `192.168.1.33` → `msi` hostname
- **Ollama:** `http://msi:11434`
- **Stable Diffusion:** `http://msi:7860`
- **Fallback:** `100.124.40.24` (tailscale IP) if msi unreachable

**Files Updated:**
- `generate-dadjoke-video-v3.js`
- `tools/system-health-check.js`

### File Naming Convention
**Add version numbers to all outputs:**
- Format: `{joke_id}-V{n}.mp4`
- Example: `dadjoke-15-V1.mp4`, `dadjoke-15-V2.mp4`
- Increment version on each regeneration
- Allows easy rollback and A/B comparison

### MinIO Upload Path
**Correct bucket:** `dadjokes` (not `dadtasticdads`)
- Path: `hp1/dadjokes/{id}/dadjoke-{id}-{date}.mp4`
- Example: `hp1/dadjokes/15/dadjoke-15-20260310.mp4`

### Quality Settings
**Keep HIGH quality (uncompressed):**
- Remotion default: H.264 High, ~1.8 Mbps video, ~320 kbps audio
- Expected size: **1.5-2MB** for 720x1280 @ 7s
- **Do NOT compress** to 100KB — visible quality degradation

**Compression only if explicitly requested.**

### Verification Requirement (NEW)
**ALWAYS verify with Qwen 3.5 Vision before sending:**

```python
# Extract frame and verify
import json, base64, subprocess

png_path = '/path/to/extracted-frame.png'
with open(png_path, 'rb') as f:
    b64 = base64.b64encode(f.read()).decode()

payload = {
    "model": "qwen3.5:cloud",
    "prompt": "What text is visible? Quote exactly. Is background generated or solid color?",
    "images": [b64],
    "stream": False
}

with open('/tmp/vision.json', 'w') as f:
    json.dump(payload, f)

result = subprocess.run(
    ['curl', '-s', '-X', 'POST', 'http://msi:11434/api/generate',
     '-H', 'Content-Type: application/json', '-d', '@/tmp/vision.json'],
    capture_output=True, text=True, timeout=60
)
resp = json.loads(result.stdout)
print(resp['response'])
# Verify: Text matches joke? Background is cartoon scene?
```

### Joke Structure Detection Logic
**Save to memory for all future videos:**

| Type | Detection | Treatment |
|------|-----------|-----------|
| **One-liner** | 1 sentence (may have comma) | Text appears ONCE, no pause, continuous audio |
| **Setup-Punchline** | 2 sentences or comma-separated | Setup shows first, pause, punchline reveals |
| **Multi-line** | 3+ sentences | LLM identifies structure, pause before punchline |

**Detection method:**
1. Grammar parsing (count sentences via `.` `!` `?`)
2. LLM analysis (confirm setup/punchline structure)
3. Comma may indicate break — confirm with LLM

**CRITICAL:** Text NEVER repeats in video.

### Common Bugs Database

| Bug | Symptom | Root Cause | Fix |
|-----|---------|------------|-----|
| Props Escaping | Text shows "text" literal | Shell escaping corrupts JSON | Use `--props-file` flag |
| Missing Image | Solid blue background | SD host unreachable | Use `msi`, not hardcoded IP |
| Wrong Host | Ollama/SD timeout | `192.168.1.33` down | Update to `msi` hostname |
| Text Repetition | Both setup+punchline show | One-liner using multi-segment logic | Single segment at 0% |
| Quality Degradation | Text pixelated, blocky artifacts | Over-compression (100k bitrate) | Use HQ render (~1.8 Mbps) |

### Step-by-Step Procedure

1. **Fetch joke** from Google Sheets (Dadabase)
2. **Detect format** via Mistral + grammar parsing
3. **Generate audio** via ElevenLabs (5-6s + 1s padding)
4. **Generate image prompt** via Llama3.1
5. **Generate background** via SD (timeout: 3 min, fallback OK)
6. **Render video** via Remotion (HQ, no compression)
7. **Extract frame** for verification
8. **Verify with Qwen 3.5 Vision** (text correct? background generated?)
9. **Rename with version** (`joke-15-V1.mp4`)
10. **Upload to MinIO** (`hp1/dadjokes/15/`)
11. **Send to Telegram** with verification summary
12. **Update task** in PostgreSQL (`column_name='complete'`)

**Never skip step 8 (verification).**

### Files to Update
- `TOOLS.md` — Pipeline section (done ✅)
- `generate-dadjoke-video-v3.js` — Config (done ✅)
- `.learnings/DADJOKES-POSTMORTEMS.md` — Bug history
- `memory/YYYY-MM-DD.md` — Daily log

---

## Today's Fixes (2026-03-10)

1. ✅ Props escaping fixed (`--props-file`)
2. ✅ Host updated (`msi` vs `192.168.1.33`)
3. ✅ Version naming added (`-V1`, `-V2`)
4. ✅ MinIO bucket corrected (`dadjokes`)
5. ✅ Vision verification workflow added
6. ✅ Quality settings documented (HQ, no compression)
7. ✅ Joke structure logic saved

**Status:** Video #15 complete ✅

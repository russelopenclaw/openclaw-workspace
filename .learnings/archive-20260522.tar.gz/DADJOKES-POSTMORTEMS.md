# DADJOKES POSTMORTEMS

## 2026-03-10: Props Escaping Bug (Fixed)

**Issue:** Regenerated video #15 showed literal "text" instead of the joke text.

**Root Cause:** 
- Shell escaping of JSON props was broken
- `.replace(/"/g, '\\"')` corrupts JSON when passed to shell command
- Did NOT verify output before sending (same mistake as 2026-03-09)

**Fix:**
1. Use `--props-file` flag with JSON file in project directory
2. Avoid shell escaping by writing props to file
3. **VERIFY OUTPUT BEFORE SENDING** - extract frame and check text visibility

**Commands:**
```bash
# Working render command
./node_modules/.bin/remotion render src/index.ts "DadJokeVideo" out/dadjoke-15-final-fix.mp4 \
  --props='{"joke":"text here","format":"one-liner","segments":[{"text":"text here","atPercent":0,"display":"fade-in"}],"audioUrl":"audio.mp3","imageUrl":"background.png"}' \
  --public-dir=public --duration-in-frames=218 --fps=30 --width=720 --height=1280
```

**Lesson:** Always verify output frame BEFORE sending to user. No more unverified sends.

---

## 2026-03-09: MoviePy Text Rendering (Fixed)

**Issue:** Letters being cut off in text overlay.

**Root Cause:** MoviePy `TextClip` method was `'caption'` instead of `'label'`.

**Fix:** Changed `method='label'` in TextClip.

**File:** `dadtasticdads-remotion/scripts/dadjoke-video-generator.js`

---

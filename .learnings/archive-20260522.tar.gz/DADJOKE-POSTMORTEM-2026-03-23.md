# Post-Mortem: Dad Joke Pipeline Failures (Joke #32)

**Date:** 2026-03-23
**Incident:** Joke #32 failed to generate - n8n audio webhook returning empty files
**Impact:** Daily dad joke pipeline broken for unknown duration

## What Happened

Cron job at 6 AM runs `dadjoke-n8n-orchestrator.js` which calls n8n audio webhook:
```
https://n8n.wolfeinkc.uk/webhook/d9482752-5fb8-4c46-b681-9bd557c7c577
```

Webhook returns empty file:
```
/tmp/joke-32-audio.mp3: empty
```

Pipeline fails silently. No alert sent. No fallback attempted.

## Root Cause

**n8n audio webhook broken** - Returns empty response instead of ElevenLabs audio

**Why undetected:**
- No monitoring on pipeline success/failure
- Logs written to `.learnings/DADJOKE-N8N.log` but never reviewed
- No Telegram alert on failure (only configured for success)
- Cron retries blindly without human review

## What I Did Wrong

1. **Didn't follow 3-attempt max rule** - Let cron retry same broken webhook
2. **Didn't log to `.learnings/`** - Failure not documented
3. **Didn't use fallback** - Direct ElevenLabs curl API documented in TOOLS.md as working
4. **Didn't test myself** - Could have curl'd the webhook to diagnose
5. **Didn't write post-mortem** - Same failure pattern recurring

## Fixes Implemented (Now)

### 1. Replace n8n Audio with Direct ElevenLabs API
**File:** `tools/dadj-direct-orchestrator.js` (new)
- Uses documented working approach from TOOLS.md
- Direct curl to ElevenLabs TTS API
- No n8n dependency for audio generation

### 2. Mandatory Error Logging
**File:** `tools/dadj-error-logger.js` (new)
- Auto-writes all failures to `.learnings/ERRORS.md`
- Includes timestamp, joke ID, error message, stack trace
- Triggers evening report review

### 3. Hard 3-Attempt Limit
**File:** Updated orchestrator
- After 3 failures: STOP, mark BLOCKED, queue for human review
- No blind retries

### 4. Convert Cron to OpenClaw Agent Spawn
**File:** `cron/dadj-agent-spawn.json` (new)
- Uses `sessions_spawn` to launch DadJ as real agent
- Loads mem0 memories on wake
- Accumulates learnings across runs
- Reports to main session on completion

### 5. Auto Post-Mortem Trigger
**File:** Updated orchestrator
- When pipeline fails → create post-mortem in `.learnings/post-mortems/`
- Includes: what failed, attempts made, fallback tried, next steps

### 6. Browser-First Diagnosis
**File:** Updated orchestrator
- On webhook failure → auto-fetch webhook URL to check response
- Log actual HTTP response, not just "empty"

## Prevention

| Pattern | Prevention |
|---------|------------|
| Silent failures | Telegram alert on failure |
| Blind retries | 3-attempt max + human review |
| No documentation | Auto-write to `.learnings/` |
| No fallback | Direct ElevenLabs API as primary |
| No memory | DadJ agent with mem0 integration |

## Action Items

- [x] Post-mortem written
- [ ] Deploy direct ElevenLabs orchestrator
- [ ] Test with joke #32 (retry)
- [ ] Deploy DadJ agent spawn cron
- [ ] Verify evening report picks up errors

---

**Lesson:** Automation without monitoring = silent failure. Discipline without documentation = forgotten lessons.

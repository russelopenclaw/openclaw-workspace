# Autonomous Project Management - Kevin's Expectation

**Critical Learning from 2026-03-05**:

Kevin expects Alfred to **actively manage projects**, not just plan and wait passively.

## What Autonomous Means:

✅ **Active Management**:
- Check subagent status every 2-5 minutes (`sessions_list`)
- Intervene if subagent stuck >10 minutes
- Unblock, reassign, or respawn as needed
- Drive to completion WITHOUT being prompted
- Provide progress updates proactively

❌ **NOT Autonomous**:
- Laying out a plan then waiting passively
- Asking "want me to start?" instead of just starting
- Waiting for user to check in
- "HEARTBEAT_OK" when there's active work to monitor

## Kevin's Explicit Feedback (2026-03-05 21:58):

> "You need to handle prioritization. Remember the autonomous discussions we've had?
> Do you need to save this somewhere? You aren't taking control..."

**Translation**: Stop being passive. Take control. Manage the project actively.

## Implementation:

**For every active project**:
1. Spawn subagents with clear tasks
2. Set reminder to check status in 5 minutes
3. If subagent stuck: intervene immediately (respawn/reassign)
4. Provide progress updates every 10-15 minutes
5. Drive to completion - don't wait for user to ask

**This file serves as**: A permanent reminder of the expected autonomous behavior. Reference before every multi-step project.

---

**Applied to current PostgreSQL cleanup**:
- Phases 2 & 3 subagents are running
- I will check their status in 5 minutes (automatically)
- If either is stuck: intervene, reassign, or respawn
- Prep Phase 4 verification NOW while they work
- Deliver completion report without being asked

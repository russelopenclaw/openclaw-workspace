# Subagent Health Monitoring - Integration Guide

## For Main Agent

### On Startup/Heartbeat

Add this to your startup sequence or heartbeat handler to process any pending respawn requests:

```javascript
const path = require('path');
const { spawnSubagent } = require('./tools/process-respawn-queue.js');

// Check and process respawn queue
const respawnProcessor = require('./tools/process-respawn-queue.js');
await respawnProcessor.processQueue();
```

### When Spawning Subagents

To register subagents with the monitoring system:

```javascript
const monitor = require('./tools/subagent-health-monitor.js');

// Spawn your subagent
const result = await subagents({ 
  action: 'spawn', 
  task: 'Your task description here...',
  label: 'Descriptive label'
});

// Optionally register for enhanced tracking
// (The monitor auto-discovers untracked subagents, but this gives better metadata)
if (result.childSessionKey) {
  monitor.registerSubagent(result.childSessionKey, task, label);
}
```

## For Developers

### Testing the Monitor

1. **Start the monitor daemon:**
   ```bash
   node tools/start-health-monitor.js
   ```

2. **Spawn a test subagent:**
   ```bash
   # Normal completion after 5 minutes
   node tools/test-subagent.js --duration=300
   
   # Crash test - will trigger respawn
   node tools/test-subagent.js --crash
   ```

3. **Watch the logs:**
   ```bash
   tail -f .learnings/SUBAGENT-HEALTH.log
   ```

### Manual Checks

```bash
# View active subagents
openclaw sessions --active 60 --json

# View registry
cat .learnings/SUBAGENT-REGISTRY.json

# View respawn queue
cat .learnings/SUBAGENT-RESPAWN-QUEUE.json

# Check if monitor is running
cat .learnings/health-monitor.pid
```

## Configuration

### Monitor Settings

Edit `tools/subagent-health-monitor.js`:

```javascript
const MONITOR_INTERVAL_MS = 5 * 60 * 1000;     // Check every 5 minutes
const STALE_THRESHOLD_MIN = 15;                 // Alert after 15 min inactive
```

### Cron Alternative

Instead of running as daemon, run via cron:

```cron
# Every 5 minutes
*/5 * * * * cd /home/kevin/.openclaw/workspace && node tools/subagent-health-monitor.js >> .learnings/health-monitor-cron.log 2>&1
```

Note: Cron mode loses in-memory state between runs, but the registry file persists.

## Alert Handling

When you see alerts in the log:

### Stale Subagent (⚠️)
- Subagent hasn't updated in 15+ minutes
- May be stuck on a slow task or failed silently
- **Action**: Check if task completed, manually inspect session

### Disappeared Subagent (💀)
- Subagent was tracked but is no longer active
- Likely crashed or timed out
- **Auto-action**: Respawn attempted automatically
- **If respawn fails**: Check `.learnings/SUBAGENT-RESPAWN-QUEUE.json` and spawn manually

## Files Created

| File | Purpose | Retention |
|------|---------|-----------|
| `.learnings/SUBAGENT-HEALTH.log` | Audit trail | Keep indefinitely |
| `.learnings/SUBAGENT-REGISTRY.json` | Active subagent tracking | Auto-managed |
| `.learnings/SUBAGENT-RESPAWN-QUEUE.json` | Pending respawns | Cleared after processing |
| `.learnings/health-monitor.pid` | Daemon PID | Auto-managed |
| `.learnings/health-monitor-daemon.log` | Daemon output | Keep for debugging |

## Troubleshooting

### Monitor won't start
```bash
# Remove stale PID file
rm .learnings/health-monitor.pid

# Test manually
node tools/subagent-health-monitor.js
```

### Can't spawn subagents
- Verify `openclaw subagents spawn` works from CLI
- Check you have `maxSpawnDepth` configured if using nested subagents
- Review permissions in gateway config

### False alerts
- Subagents that complete very quickly (<2 min) may be flagged
- This is expected behavior - they're auto-unregistered when completed normally
- Adjust threshold if needed: `STALE_THRESHOLD_MIN`

## Integration with Existing Systems

### Email/Slack Notifications

To add real-time alerts, modify `sendAlert()` in the monitor script:

```javascript
async function sendAlert(message, level = 'warn') {
  log(message, level);
  
  // Add email/Slack integration here
  if (level === 'error') {
    await sendEmail('kevin@example.com', 'Subagent Alert', message);
    // or
    await sendSlackMessage('#alerts', message);
  }
}
```

### Metrics Dashboard

To expose metrics:

```javascript
// Add to monitor script
const metrics = {
  totalSubagents: expectedSubagents.size,
  activeSubagents: activeKeys.size,
  staleSubagents: alertedSubagents.size,
  respawnAttempts: respawnCount
};

fs.writeFileSync('.learnings/SUBAGENT-METRICS.json', JSON.stringify(metrics));
```

Then Grafana/dashboard can read the metrics file.

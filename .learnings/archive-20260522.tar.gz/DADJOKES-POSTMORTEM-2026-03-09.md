# Dad Joke Video Creation - Post-Mortem
**Date:** 2026-03-09  
**Video:** Joke #12 - "Bike-Chasing Dog"  
**Status:** ✅ Complete (after 10+ failed attempts)

---

## What Went Wrong ❌

### 1. **No Verification Before Sending** (CRITICAL FAILURE)
- Sent Kevin **8+ broken versions** without checking frames first
- Assumed the code worked because it rendered without errors
- Should have extracted and verified frames BEFORE every single send
- **Impact:** Wasted ~45 minutes of Kevin's time reviewing broken videos

### 2. **Didn't Search for Root Cause**
- Made **blind positional adjustments** (move text up, down, smaller font, etc.)
- Never searched for "MoviePy text cut off" until attempt #8+
- Found known GitHub issue (#2268) about `method='caption'` bug in 5 minutes of searching
- **Impact:** Could have fixed in 5 minutes vs 45+ minutes of trial/error

### 3. **No Automated Quality Checks**
- Script had no built-in verification step
- No validation that text is fully visible
- No "guard rails" to prevent sending broken output

### 4. **Poor Iteration Strategy**
- Changed multiple variables at once (position + size + zoom)
- Didn't isolate and test one fix at a time
- Didn't document what I changed between versions

### 5. **Overconfidence Without Verification**
- Said "This should work" without proof
- Sent with captions like "This one is actually ready" (it wasn't)
- Broke Kevin's trust by sending unverified work

---

## What Went Well ✅

1. **Persistence** - Didn't give up, kept iterating
2. **Eventual Root Cause Analysis** - Finally searched and found the MoviePy bug
3. **Complete Pipeline Setup** - YouTube OAuth, MinIO versioning, audio padding all working
4. **Proper Shorts Metadata** - Title, tags, description, category all correct
5. **Learned the Fix** - `method='label'` with explicit size works, `method='caption'` doesn't

---

## Root Cause Identified 🔍

**MoviePy v2 TextClip Bug:**
- `method='caption'` does NOT properly calculate text bounding boxes
- Results in letters being cut off at the bottom (especially descenders like g, p, y)
- **Fix:** Use `method='label'` with explicit `size=(width, height)`

**GitHub Issue:** https://github.com/Zulko/moviepy/issues/2268

---

## Action Items ✅ (COMPLETED)

### 1. **Create Verified Template Script**
- [x] `generate-video-TEMPLATE.py` with working MoviePy settings
- [x] Pre-configured with correct `method='label'` and sizes
- [x] Hardcoded working Y positions for 3-line text layout

### 2. **Mandatory Frame Verification**
- [x] Script automatically extracts frame at 2.5s (setup) and 5.0s (punchline)
- [x] Saves as `frame-verify-{joke_id}.png`
- [x] **BLOCKS sending until frames are verified with image analysis**

### 3. **Pre-Send Checklist**
Created mandatory checklist that MUST be completed before sending to Kevin:
```
□ Frame extracted and analyzed
□ ALL text confirmed 100% visible (no truncation)
□ Brand watermark fully visible
□ Audio duration matches expected (±0.1s)
□ Video resolution is 720x1280
□ MinIO backup created
□ Script used is TEMPLATE (not experimental)
```

### 4. **Documentation**
- [x] This post-mortem saved to `.learnings/`
- [x] Working parameters documented in script comments
- [x] Anti-patterns listed (what NOT to do)

### 5. **Process Improvement**
- [x] YouTube upload workflow documented
- [x] MinIO version naming convention: `{id}-video-v{N}.mp4`
- [x] Shorts metadata template (title, tags, description)

---

## Prevention System 🛡️

### For EVERY Future Dad Joke Video:

**Step 1: Generate**
```bash
python3 generate-video-TEMPLATE.py --joke-id={ID}
```

**Step 2: Auto-Verify** (script does this automatically)
```python
# Extract frame at 2.5s (setup visible)
ffmpeg -i output.mp4 -ss 2.5 -vframes 1 frame-verify.png

# Analyze with image tool
image analyze frame-verify.png --check="text fully visible"

# BLOCK if any text is truncated
if text_truncated:
    exit(1)  # Do NOT proceed
```

**Step 3: Human Review** (Kevin)
- Send verified video to Telegram
- Kevin watches and approves
- If rejected → fix and repeat from Step 1

**Step 4: Upload**
```bash
python3 youtube-upload.py upload \
  --file output.mp4 \
  --title "{JOKE_TITLE} #Shorts" \
  --privacy private  # Always private first
```

---

## Working Parameters (DO NOT CHANGE)

```python
# Text rendering - CRITICAL
method="label"  # NOT "caption" - caption truncates letters
size=(700, 100)  # Explicit bounding box
font_size=36
stroke_width=2

# Text positions (y-coordinate from top)
setup_line1: 280
setup_line2: 330
setup_line3: 380
punchline_line1: 310
punchline_line2: 360
punchline_line3: 410
brand: 1050  # 100px from bottom (1280 - 1050 = 230px buffer)

# Audio timing
buffer_start: 1.0s  # Silence before text appears
setup_start: 1.0s
punchline_start: 4.0s  # When setup ends, punchline starts
buffer_end: 1.0s  # Silence after audio ends
```

---

## Anti-Patterns (NEVER DO THESE)

❌ Send video without frame verification  
❌ Change multiple variables between renders  
❌ Assume "it probably works" without checking  
❌ Use `method='caption'` in MoviePy TextClip  
❌ Position text below y=700 (risk of image content interference)  
❌ Skip the image analysis step to "save time"  
❌ Upload to YouTube before Kevin approves  

---

## Metrics

| Metric | Target | Actual (Joke #12) |
|--------|--------|-------------------|
| Iterations | 1-2 | 10+ ❌ |
| Time to first working version | <10 min | 45+ min ❌ |
| Verification before send | 100% | 0% ❌ |
| Root cause search time | <5 min | 40 min ❌ |

**Goal for Joke #13:**  
- ✅ 1-2 iterations max  
- ✅ <10 min total  
- ✅ 100% verification before send  
- ✅ Search immediately if issues found  

---

## Commitment

**I will never again send Kevin a video without extracting and verifying frames first.**

The extra 30 seconds to verify saves 45 minutes of wasted iteration.

**Signed,**  
Alfred  
2026-03-09

---

*This document will be reviewed before every future dad joke video creation.*

# AI Task Suggester - COMPLETE

**Task:** task-71 - AI Task Suggester  
**Status:** ✅ Complete  
**Completed:** 2026-03-11 21:00 CDT  

---

## What Was Built

Automated intelligence engine that analyzes work patterns to suggest high-value tasks:

**Script:** `tools/ai-task-suggester.js`

**Analyzes:**
1. **Completion Patterns** - Last 7 days of completed tasks
2. **Upcoming Calendar** - Events in next 48 hours
3. **Backlog Health** - Priority distribution
4. **System Signals** - Errors, stuck tasks, failures

**Generates Suggestions:**
- 🔴 Pattern-based (batch automation when completing many small tasks)
- 🟡 Error-based (resolve active errors)
- 🟡 Stuck tasks (unblock in-progress work)
- 🟡 Calendar-based (prepare for events)
- 🟡 Backlog-based (focus on high-priority)
- 🟡 Quality (document/test completed features)
- 🟡 Meta (automate manual processes)

---

## Test Results

Generated 4 suggestions:

1. **Batch similar small tasks** (productivity)
   - 13 tasks completed in 7 days, avg 1h each
   - Suggest: Create automation script
   - Effort: 1-2 hours | Impact: Reduces repetitive work

2. **Review and resolve active errors** (reliability)
   - 2 errors in .learnings/ERRORS.md
   - Effort: 30 min - 1 hour

3. **Document and test completed features** (quality)
   - 13 tasks completed recently
   - Create runbooks, add tests
   - Effort: 2-4 hours

4. **System improvement: Automate a manual process** (optimization)
   - Identify repetitive task to automate
   - Permanent time savings

---

## Output Files

| File | Purpose |
|------|---------|
| `tools/ai-task-suggester.js` | Main script (executable) |
| `.suggested-tasks.json` | Generated suggestions (JSON) |
| `cron/ai-task-suggester.json` | Manifest |

---

## Integration

**Run Modes:**
- **On-demand**: User asks for suggestions
- **Morning briefing**: Include in daily briefing
- **Planning sessions**: Run before sprint planning

**Usage:**
```bash
node /workspace/tools/ai-task-suggester.js
# Reads suggestions: cat .suggested-tasks.json | jq
```

**Pattern matching logic:**
- High completion rate → suggest batching
- Errors detected → suggest resolution
- Stuck tasks → suggest intervention
- Calendar events → suggest preparation
- Large backlog → suggest focus
- Many completions → suggest documentation

---

## Database Queries

```sql
-- Completions (7 days)
SELECT id, title, description, completed_at, priority, 
       EXTRACT(EPOCH FROM (completed_at - created_at))/3600 as hours
FROM tasks 
WHERE column_name='complete' 
  AND completed_at > NOW() - INTERVAL '7 days';

-- Backlog analysis
SELECT id, title, priority, description 
FROM tasks 
WHERE column_name='backlog' 
ORDER BY priority, created_at ASC;

-- Stuck tasks
SELECT COUNT(*) 
FROM tasks 
WHERE column_name='in-progress' 
  AND updated_at < NOW() - INTERVAL '1 hour';
```

---

**Status:** Alfred → idle (task-71 complete)  
**Backlog:** Now 0 unassigned tasks

--
-- PostgreSQL database dump
--

\restrict jzdGZRLbju4vAYDEdFNedIG3sUaJLeog5EPE6Qh7y6zHqEa3nolU1W4aVSl6hoa

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: alfred
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO alfred;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    current_task text,
    last_activity timestamp with time zone DEFAULT now(),
    CONSTRAINT agents_status_check CHECK (((status)::text = ANY ((ARRAY['working'::character varying, 'idle'::character varying, 'offline'::character varying])::text[])))
);


ALTER TABLE public.agents OWNER TO alfred;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: alfred
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_id_seq OWNER TO alfred;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alfred
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.calendar_events (
    id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    type character varying(20),
    description text,
    location character varying(500),
    recurring_rule character varying(500),
    recurring_until date,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT calendar_events_type_check CHECK (((type)::text = ANY ((ARRAY['personal'::character varying, 'meeting'::character varying, 'reminder'::character varying, 'cron'::character varying])::text[])))
);


ALTER TABLE public.calendar_events OWNER TO alfred;

--
-- Name: TABLE calendar_events; Type: COMMENT; Schema: public; Owner: alfred
--

COMMENT ON TABLE public.calendar_events IS 'Calendar events: meetings, personal events, reminders, and cron jobs';


--
-- Name: COLUMN calendar_events.recurring_rule; Type: COMMENT; Schema: public; Owner: alfred
--

COMMENT ON COLUMN public.calendar_events.recurring_rule IS 'iCalendar RRULE format (RFC 5545)';


--
-- Name: reminders; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.reminders (
    id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    due_date date NOT NULL,
    due_time time without time zone,
    recurring_rule character varying(500),
    recurring_until date,
    completed boolean DEFAULT false,
    notified_at timestamp with time zone,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reminders OWNER TO alfred;

--
-- Name: TABLE reminders; Type: COMMENT; Schema: public; Owner: alfred
--

COMMENT ON TABLE public.reminders IS 'User reminders with optional recurrence and notification tracking';


--
-- Name: subagents; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.subagents (
    run_id character varying(100) NOT NULL,
    label character varying(200),
    task character varying(500),
    status character varying(20),
    runtime character varying(20),
    total_tokens bigint,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    note text
);


ALTER TABLE public.subagents OWNER TO alfred;

--
-- Name: task_history; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.task_history (
    id integer NOT NULL,
    task_id character varying(50),
    status character varying(50),
    "timestamp" timestamp with time zone DEFAULT now(),
    note text
);


ALTER TABLE public.task_history OWNER TO alfred;

--
-- Name: task_history_id_seq; Type: SEQUENCE; Schema: public; Owner: alfred
--

CREATE SEQUENCE public.task_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_history_id_seq OWNER TO alfred;

--
-- Name: task_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alfred
--

ALTER SEQUENCE public.task_history_id_seq OWNED BY public.task_history.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.tasks (
    id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    column_name character varying(50) NOT NULL,
    assignee character varying(50),
    priority character varying(20) DEFAULT 'medium'::character varying,
    description text,
    parent_task_id character varying(50),
    linked_subagent character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tasks OWNER TO alfred;

--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: task_history id; Type: DEFAULT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.task_history ALTER COLUMN id SET DEFAULT nextval('public.task_history_id_seq'::regclass);


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.agents (id, name, status, current_task, last_activity) FROM stdin;
2	jeeves	idle	All tasks complete	2026-03-06 09:59:13.694293-06
1	alfred	working	task-72: PostgreSQL Auto-Backup	2026-03-11 14:50:53.617108-05
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.calendar_events (id, title, date, start_time, end_time, type, description, location, recurring_rule, recurring_until, created_at, updated_at) FROM stdin;
evt-1772595247161	Team meeting	2026-03-04	14:00:00	15:00:00	personal	\N	\N	\N	\N	2026-03-06 06:58:53.0681-06	2026-03-06 06:58:53.0681-06
evt-1772597198793	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.085827-06	2026-03-06 06:58:53.085827-06
evt-1772597198814	Daily scrum at 8am	2026-03-03	08:00:00	09:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR	\N	2026-03-06 06:58:53.086891-06	2026-03-06 06:58:53.086891-06
evt-1772597198816	Team lunch	2026-03-03	12:00:00	13:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=FR	\N	2026-03-06 06:58:53.088671-06	2026-03-06 06:58:53.088671-06
evt-1772597202310	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.089825-06	2026-03-06 06:58:53.089825-06
evt-1772597202328	Team lunch	2026-03-03	12:00:00	13:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=FR	\N	2026-03-06 06:58:53.090765-06	2026-03-06 06:58:53.091984-06
evt-1772597533939	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.093259-06	2026-03-06 06:58:53.093259-06
evt-1772597533957	Daily scrum at 8am	2026-03-03	08:00:00	09:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR	\N	2026-03-06 06:58:53.094376-06	2026-03-06 06:58:53.094376-06
evt-1772600095771	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.095209-06	2026-03-06 06:58:53.095209-06
evt-1772600218585	Lunch meeting	2026-03-03	14:00:00	15:00:00	personal	\N	\N	\N	\N	2026-03-06 06:58:53.09641-06	2026-03-06 06:58:53.09641-06
evt-1772601359190	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.097224-06	2026-03-06 06:58:53.097224-06
evt-1772601359208	Daily standup	2026-03-03	08:00:00	09:00:00	personal	\N	\N	FREQ=DAILY	\N	2026-03-06 06:58:53.098228-06	2026-03-06 06:58:53.098228-06
evt-1772631056719	Deacons Meeting	2026-03-17	18:00:00	20:00:00	personal	Monthly deacons meeting	\N	\N	\N	2026-03-06 06:58:53.099002-06	2026-03-06 06:58:53.099002-06
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.reminders (id, title, due_date, due_time, recurring_rule, recurring_until, completed, notified_at, description, created_at, updated_at) FROM stdin;
rem-1772639702287	Deacons Meeting in 3 hours	2026-03-17	15:00:00	FREQ=MONTHLY;BYSETPOS=3;BYDAY=TU	\N	f	\N	Monthly deacons meeting starts at 6 PM today	2026-03-06 06:58:53.101839-06	2026-03-06 06:58:53.101839-06
rem-1772639702263	Deacons Meeting in 24 hours	2026-03-16	18:00:00	\N	\N	f	\N	\N	2026-03-06 06:58:53.100682-06	2026-03-06 07:00:23.942822-06
\.


--
-- Data for Name: subagents; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.subagents (run_id, label, task, status, runtime, total_tokens, started_at, completed_at, note) FROM stdin;
mock-1772600098582	Alfred - E2E Testing (task-28)	Second Brain - E2E testing (task-28): Test all commands work correctly	done	~2h	0	2026-03-04 04:54:58-06	2026-03-04 06:42:00-06	Task-28 and parent task-8 marked done by heartbeat - all Second Brain features complete
927e65e4-190c-49c3-b45b-fd25fac0e997	Jeeves - Recurring Events (Retry #2)	Second Brain - Recurring events (task-25): Test & fix existing recurrence implementation	done	330m	0	2026-03-03 23:12:00-06	2026-03-04 04:42:00-06	Task-25 marked done in tasks.json - subagent status synced by heartbeat
8c12ee2f-de9f-48d3-b7a3-bd2b4cc84ac5	Jeeves - Recurring Events	Second Brain - Recurring events (task-25): Implement recurrence patterns	killed	72m	0	2026-03-03 22:00:00-06	2026-03-03 23:12:00-06	\N
22117d4b-b8fb-4707-b785-0792cad2e7c1	Alfred - E2E Testing	Second Brain - E2E testing (task-28): Final comprehensive test	done	9m	1400000	2026-03-03 22:51:00-06	2026-03-03 23:00:00-06	\N
68dd835e-3764-441d-a47a-b1d2a7489f2a	Alfred - Heartbeat Monitoring	Second Brain - Heartbeat monitoring (task-27): Add reminder checks to heartbeat	done	8m	1100000	2026-03-03 22:51:00-06	2026-03-03 22:59:00-06	\N
be0bc7fc-1884-422a-a82a-044ef03fa247	Alfred - E2E Testing	Second Brain - E2E Testing (task-28): Test all commands end-to-end	done	1m	41800	2026-03-03 22:00:00-06	2026-03-03 22:02:00-06	\N
f0539545-4f0b-4b5d-a4be-68df708101d1	Alfred - Event Handler (Retry)	Second Brain - Event Handler (task-24): Handle 'Create event [details]' - RETRY #1	done	4m	488400	2026-03-03 21:32:00-06	2026-03-03 21:36:00-06	\N
b876c551-5d3d-44b2-a729-91ea29ce21d2	Jeeves - Calendar Integration	Second Brain - Calendar integration (task-26): Verify Brain ↔ Calendar	done	7m	978200	2026-03-03 21:28:00-06	2026-03-03 21:36:00-06	\N
95b6067a-a33f-49c6-9a1d-1bd859860b50	Alfred - Event Handler	Second Brain - Event Handler (task-24): Handle 'Create event [details]'	failed	2m	64100	2026-03-03 21:28:00-06	2026-03-03 21:31:00-06	\N
0a480da6-f134-4ef0-b2d6-8b8bb3812602	Alfred - Reminder Handler	Second Brain - Reminder Handler (task-23): Handle 'Remind me to [task] [when]'	done	16m	54062	2026-03-03 20:38:00-06	2026-03-03 20:55:00-06	\N
23e53216-1dd6-447e-8baa-62e35620c9ca	Alfred - Remember Handler	Second Brain - Remember Command Handler (task-21): Handle 'Remember: [URL/content]'	done	5m	34049	2026-03-03 20:38:00-06	2026-03-03 20:52:00-06	\N
758355c6-e9f6-42f1-a28b-dfeaff7ef13d	Jeeves - Keyword Extraction	Second Brain - Keyword Extraction (task-19): Auto-extract 3-5 keywords	done	14m	54253	2026-03-03 20:38:00-06	2026-03-03 20:52:00-06	\N
4b0cd167-d22a-4f76-acaf-acd69ce96d4e	Jeeves - Brain API Endpoints	Create Brain CRUD and search APIs for Brain items	done	8m	28025	2026-03-03 20:14:00-06	2026-03-03 20:28:00-06	\N
9ef07328-2fcb-404f-9ab9-40f0333b8415	Jeeves - Brain Page UI	Building /brain page with saved items list, search, and keyword extraction	done	9m	45773	2026-03-03 19:14:00-06	2026-03-03 19:24:00-06	\N
test-run-456	Test Subagent 2	Task completed	done	\N	\N	2026-03-05 13:08:07.410064-06	2026-03-05 13:08:07.421477-06	\N
bf7296eb-bdff-4f1a-84f3-0c2dd25a95f7	Jeeves - Dad Joke #21 Production with Timing	Task #31: Generate Dad Joke #21 with performance timing	done	0m	0	2026-03-05 07:35:00-06	2026-03-05 13:27:34.374269-06	\N
\.


--
-- Data for Name: task_history; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.task_history (id, task_id, status, "timestamp", note) FROM stdin;
1	task-3	in-progress	2026-03-03 17:08:26.962-06	Status changed to in-progress
2	task-3	done	2026-03-03 18:55:00-06	Heartbeat monitoring implemented and tested - runs every ~30min automatically
3	task-4	in-progress	2026-03-04 08:42:04.063-06	Status changed to in-progress
4	task-4	review	2026-03-04 08:42:05.13-06	Status changed to review
5	task-4	done	2026-03-04 08:42:05.93-06	Status changed to done
6	task-6	in-progress	2026-03-03 16:59:05.837-06	Status changed to in-progress
7	task-6	review	2026-03-03 17:54:57.84-06	Status changed to review
8	task-6	done	2026-03-03 17:54:59.073-06	Status changed to done
9	task-7	in-progress	2026-03-03 13:50:57.782-06	Status changed to in-progress
10	task-7	review	2026-03-03 16:32:40.946-06	Status changed to review
11	task-7	done	2026-03-03 16:32:41.89-06	Status changed to done
12	task-8	done	2026-03-04 06:43:43.536-06	All subtasks completed via individual tasks (task-17 through task-28): Brain UI, API, NLP parser, Remember/Remind/Event handlers, temporal resolver, recurring events, calendar integration, heartbeat monitoring, E2E testing
13	task-15	in-progress	2026-03-03 16:13:05.098-06	Status changed to in-progress
14	task-18	in-progress	2026-03-03 20:14:00-06	Started Brain API implementation
15	task-18	done	2026-03-03 20:28:00-06	✅ All endpoints working: GET (list/limit), POST (create), GET /search (relevance scoring). Auto-metadata updates, type detection, keyword extraction implemented.
16	task-19	done	2026-03-03 20:52:00-06	✅ Enhanced keyword extraction with title boosting, technical term detection, stop word filtering. Created re-extract endpoints (single + bulk). Tested with diverse content.
17	task-21	done	2026-03-03 20:42:00-06	✅ Created remember.js with type detection, auto-keywords, Telegram integration
18	task-23	done	2026-03-03 20:55:00-06	✅ Reminder handler implemented with temporal resolver integration, creates calendar reminders from natural language
19	task-24	in-progress	2026-03-03 21:28:00-06	Auto-assigned by heartbeat - Event handler implementation started
20	task-24	failed	2026-03-03 21:31:00-06	First attempt failed (HTTP 400 - missing context). Retrying with better file references.
21	task-24	done	2026-03-03 21:36:00-06	✅ Event handler created: parses 'Create event [details]', uses temporal resolver, saves to calendar/events.json, returns formatted confirmation
22	task-25	in-progress	2026-03-03 22:00:00-06	Initial implementation started
23	task-25	stuck	2026-03-03 23:12:00-06	Auto-killed after 72 min (>1h). Retry #2 spawned
24	task-25	stuck	2026-03-04 00:45:00-06	Retry #2 killed after 93 min. FINAL attempt spawned
25	task-25	done	2026-03-04 01:12:00-06	✅ VERIFIED via E2E testing (task-28): Recurring events work correctly. 'Weekly standup every Monday at 9am' successfully created with RRULE: FREQ=WEEKLY;BYDAY=MO. Implementation complete despite subagent tooling issues.
26	task-26	in-progress	2026-03-03 21:28:00-06	Auto-assigned by heartbeat - Calendar integration testing started
27	task-26	done	2026-03-03 21:36:00-06	✅ Integration complete: Brain handlers → Calendar API, events/reminders appear in Calendar UI, format normalization for dual format support
28	task-27	in-progress	2026-03-03 22:51:00-06	Auto-assigned by heartbeat - Heartbeat monitoring implementation started
29	task-27	done	2026-03-03 22:59:00-06	✅ Reminder monitoring integrated into heartbeat - checks every 30 min, sends Telegram notifications for due reminders, auto-marks as notified
30	task-28	in-progress	2026-03-03 22:54:58.583-06	Auto-assigned by heartbeat, subagent spawned: mock-1772600098582
31	task-28	done	2026-03-04 05:42:00-06	All Second Brain commands verified: Remember/Remind/Event handlers working, recurring events functional, calendar integration complete, heartbeat monitoring active
32	task-29	in-progress	2026-03-04 08:30:00-06	Started by Kevin via morning briefing interaction
33	task-29	done	2026-03-04 11:57:00-06	✅ Completed: Agent status sync tool, Calendar widget fixes, Brain nav link, Scheduled Jobs section, Mission Control backed up to GitHub
34	task-30	in-progress	2026-03-04 11:57:00-06	Task assigned to Jeeves by Kevin - production automation subagent spawned (c31036f8)
35	task-30	done	2026-03-04 20:02:00-06	✅ Pipeline operational: 512x768@25steps, DPM++ 2M Karras, better prompt engineering, here.now upload working. Jokes #19-20 generated with 100% quality scores.
36	task-31	in-progress	2026-03-05 07:35:00-06	Task created - Jeeves subagent spawned
37	task-31	done	2026-03-05 07:34:23.037-06	✅ Dad Joke #21 complete in 114.40s | Quality: 93/100 | here.now URL ready | MinIO backup complete. Timing instrumentation successful - ready to migrate to PostgreSQL!
40	task-32	in-progress	2026-03-05 08:54:00-06	PostgreSQL setup started
41	task-32	done	2026-03-05 11:13:08.626-06	✅ PostgreSQL 16.13 installed, mission_control database created, 4 tables + 7 indexes created, npm pg installed, db.ts module created, .env.local updated. Ready for data migration!
42	task-35	in-progress	2026-03-05 09:30:01.405-06	Auto-assigned by heartbeat, subagent spawned: mock-1772724601405
43	task-36	testing	2026-03-05 13:52:06.381011-06	Concurrent write test 4 - 13:52:06
44	task-36	testing	2026-03-05 13:52:06.383469-06	Concurrent write test 2 - 13:52:06
45	task-36	testing	2026-03-05 13:52:06.389775-06	Concurrent write test 1 - 13:52:06
46	task-36	testing	2026-03-05 13:52:06.39089-06	Concurrent write test 3 - 13:52:06
47	task-36	testing	2026-03-05 13:52:06.400887-06	Concurrent write test 5 - 13:52:06
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.tasks (id, title, column_name, assignee, priority, description, parent_task_id, linked_subagent, created_at, started_at, completed_at, updated_at) FROM stdin;
task-1	Set up Kanban board	done	alfred	high	Create the Kanban-style Tasks page with all columns and features	\N	\N	2026-03-03 10:00:00-06	\N	\N	2026-03-05 11:37:22.461-06
task-3	Add heartbeat task monitoring	done	alfred	medium	Monitor for new tasks assigned to Alfred during heartbeat checks	\N	\N	2026-03-03 10:10:00-06	\N	2026-03-03 18:55:00-06	2026-03-05 11:37:22.463-06
task-4	Design system improvements	done	kevin	low	Review and improve the Mission Control design system	\N	\N	2026-03-03 10:15:00-06	\N	\N	2026-03-05 11:37:22.468-06
task-5	Test drag-and-drop functionality	done	jeeves	medium	Thoroughly test moving tasks between columns	\N	\N	2026-03-03 10:20:00-06	\N	\N	2026-03-05 11:37:22.472-06
task-6	Optimize memory processes	done	kevin	medium	Discuss and implement strategies to optimize Alfred's memory system - daily capture, long-term curation, mem0 integration, search improvements, and retention policies	\N	\N	2026-03-03 10:45:00-06	\N	\N	2026-03-05 11:37:22.473-06
task-7	Design Calendar system	done	kevin	high	Design and implement a Calendar system to track scheduled tasks/cron jobs and personal events, reminders, etc. Integrate with Google Calendar and local task scheduling.	\N	\N	2026-03-03 10:49:00-06	\N	\N	2026-03-05 11:37:22.477-06
task-8	Second Brain system	done	alfred	high	Build a personal assistant-style knowledge management system with 'Remember:', 'Remind me...', and 'Create event...' commands. Includes Brain page, natural language parsing, calendar integration, and intelligent reminders.	\N	\N	2026-03-03 10:53:00-06	\N	2026-03-04 06:43:43.536-06	2026-03-05 11:37:22.48-06
task-16	Memory optimization implementation	done	alfred	high	Implement Phase 1 & 2 memory optimizations: hybrid search, MMR, temporal decay, mem0 integration	\N	\N	2026-03-03 17:28:00-06	\N	2026-03-03 17:50:00-06	2026-03-05 11:37:22.481-06
task-9	Create calendar data structure and API endpoints	done	jeeves	high	Build APIs for 5-day view, monthly view, events CRUD, and reminders. Data files: events.json, reminders.json	\N	8cdb3456-199f-4bc5-afad-213faf33ea8c	2026-03-03 14:01:00-06	\N	2026-03-03 14:47:00-06	2026-03-05 11:37:22.482-06
task-10	Integrate status hooks into OpenClaw config	done	jeeves-2	high	Create openclaw-hooks.js and register in OpenClaw config for automatic status updates on messages, subagent events, and heartbeat	\N	e09d17aa-41e7-4f4f-b7a6-1b434507a4a8	2026-03-03 14:21:00-06	\N	2026-03-03 14:49:00-06	2026-03-05 11:37:22.483-06
task-11	Build 5-day rolling view (top section)	done	jeeves	high	Create FiveDayView component showing today + 4 days with all events, reminders, and cron jobs	\N	\N	2026-03-03 14:25:00-06	2026-03-03 15:38:00-06	2026-03-03 15:46:37-06	2026-03-05 11:37:22.484-06
task-12	Build traditional monthly calendar view (bottom section)	done	jeeves	high	Create MonthlyView component with 5-week grid, event dots, and click-to-expand day details	\N	\N	2026-03-03 14:25:00-06	2026-03-03 16:00:00-06	2026-03-03 16:02:15-06	2026-03-05 11:37:22.484-06
task-13	Add fixed Agent Activity sidebar (right side)	done	jeeves	medium	Reuse LiveActivitySidebar from Tasks page, fix to right side of Calendar page, poll every 10s	\N	\N	2026-03-03 14:25:00-06	2026-03-03 16:09:00-06	2026-03-03 16:11:30-06	2026-03-05 11:37:22.485-06
task-14	Integrate heartbeat for event/reminder checks	done	alfred	medium	Add calendar/reminder checks to HEARTBEAT.md, notify Kevin of upcoming events	\N	\N	2026-03-03 14:25:00-06	2026-03-03 16:32:00-06	2026-03-03 16:33:00-06	2026-03-05 11:37:22.486-06
task-15	Filter Home page Task Management to show only In Progress tasks	done	jeeves	low	Update DashboardStats and TaskManager widgets on Home page to only display tasks with column='in-progress'. Add toggle or filter option to view all tasks if needed. This keeps the main dashboard clean and focused on active work.	\N	\N	2026-03-03 14:31:00-06	\N	\N	2026-03-05 11:37:22.487-06
task-17	Second Brain: Brain page UI	done	jeeves	high	Create /brain page with saved items list and search - 9 min	\N	\N	2026-03-03 19:14:00-06	\N	2026-03-03 19:24:00-06	2026-03-05 11:37:22.488-06
task-18	Second Brain: Brain API endpoints	done	jeeves	high	Create CRUD and search APIs for Brain items (re-spawned at 8:14 PM)	\N	\N	2026-03-03 19:24:00-06	2026-03-03 20:14:00-06	2026-03-03 20:28:00-06	2026-03-05 11:37:22.489-06
task-19	Second Brain: Keyword extraction	done	jeeves	medium	Auto-extract 3-5 keywords from saved URLs and notes	\N	758355c6-e9f6-42f1-a28b-dfeaff7ef13d	2026-03-03 19:24:00-06	2026-03-03 20:38:00-06	2026-03-03 20:52:00-06	2026-03-05 11:37:22.492-06
task-20	Second Brain: NLP Parser	done	alfred	high	Natural language parser for Remember/Remind/Event commands	\N	\N	2026-03-03 19:19:00-06	\N	2026-03-03 19:24:00-06	2026-03-05 11:37:22.493-06
task-21	Second Brain: Remember handler	done	alfred	high	Handle 'Remember: [URL/content]' - saves to Brain	\N	23e53216-1dd6-447e-8baa-62e35620c9ca	2026-03-03 19:24:00-06	2026-03-03 20:38:00-06	2026-03-03 20:42:00-06	2026-03-05 11:37:22.494-06
task-22	Second Brain: Temporal resolver	done	alfred	high	Parse time expressions: 'this afternoon'→3PM, 'tomorrow morning'→9AM	\N	\N	2026-03-03 19:24:00-06	\N	2026-03-03 19:29:00-06	2026-03-05 11:37:22.496-06
task-23	Second Brain: Reminder handler	done	alfred	high	Handle 'Remind me to [task] [when]' - creates calendar reminders	\N	0a480da6-f134-4ef0-b2d6-8b8bb3812602	2026-03-03 19:24:00-06	2026-03-03 20:38:00-06	2026-03-03 20:55:00-06	2026-03-05 11:37:22.497-06
task-24	Second Brain: Event handler	done	alfred	high	Handle 'Create event [details]' - adds to calendar	\N	f0539545-4f0b-4b5d-a4be-68df708101d1	2026-03-03 19:24:00-06	2026-03-03 21:28:00-06	2026-03-03 21:36:00-06	2026-03-05 11:37:22.499-06
task-25	Second Brain: Recurring events	done	jeeves	medium	Support 'Every Monday at 9am' recurring patterns	\N	\N	2026-03-03 19:24:00-06	2026-03-04 00:45:00-06	2026-03-04 01:12:00-06	2026-03-05 11:37:22.502-06
task-26	Second Brain: Calendar integration	done	jeeves	medium	Integrate with calendar/events.json and reminders.json	\N	b876c551-5d3d-44b2-a729-91ea29ce21d2	2026-03-03 19:24:00-06	2026-03-03 21:28:00-06	2026-03-03 21:36:00-06	2026-03-05 11:37:22.507-06
task-27	Second Brain: Heartbeat monitoring	done	alfred	medium	Add reminder checks to heartbeat for due notifications	\N	68dd835e-3764-441d-a47a-b1d2a7489f2a	2026-03-03 19:24:00-06	2026-03-03 22:51:00-06	2026-03-03 22:59:00-06	2026-03-05 11:37:22.509-06
task-28	Second Brain: E2E testing	done	alfred	high	Test all Second Brain commands work correctly	\N	mock-1772600098582	2026-03-03 19:24:00-06	2026-03-03 22:54:58.582-06	2026-03-04 05:42:00-06	2026-03-05 11:37:22.512-06
task-29	Enhance proactive automation	done	alfred	high	Add automatic dependency resolution, smart prioritization, and interactive briefing features to reduce manual task assignment and improve agent autonomy	\N	\N	2026-03-04 08:30:00-06	2026-03-04 08:30:00-06	2026-03-04 17:57:00-06	2026-03-05 11:37:22.514-06
task-30	Automate Dad Joke Video creation end-to-end	done	jeeves	high	Create fully automated video generation pipeline: analyze generated image, generate audio once, analyze final video to confirm text is correct, timing is right, and production-ready without manual intervention	\N	c31036f8-e4bd-4e8b-861e-50f0774d5adf	2026-03-04 11:57:00-06	2026-03-04 17:57:00-06	2026-03-04 20:02:00-06	2026-03-05 11:37:22.517-06
task-31	Generate Dad Joke #21 with performance timing	done	jeeves	high	Run the production pipeline for joke #21 with enhanced timing instrumentation. Track: joke fetch, audio generation, format detection, image prompt, image generation, video render, quality verification, Sheets update, here.now upload, MinIO backup. Save timing report to output folder.	\N	bf7296eb-bdff-4f1a-84f3-0c2dd25a95f7	2026-03-05 07:35:00-06	2026-03-05 07:35:00-06	2026-03-05 07:34:23.037-06	2026-03-05 11:37:22.521-06
task-32	PostgreSQL Setup and Schema Creation	done	jeeves	high	Install PostgreSQL 16, create mission_control database, run schema scripts for agents, tasks, subagents, and task_history tables. Verify connection and permissions.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 11:13:08.626-06	2026-03-05 11:37:22.528-06
task-72	PostgreSQL Auto-Backup	in-progress	alfred	high	Nightly backup of mission_control database to MinIO with 30-day retention. Impact: Disaster recovery. Effort: 1 hour	\N	\N	2026-03-11 14:50:49.574324-05	\N	\N	2026-03-11 14:50:49.574324-05
task-33	Migrate Kanban Data to PostgreSQL	done	jeeves	high	Migrate tasks.json → tasks + task_history tables, subagents.json → subagents table, agent-status.json → agents table. Verify data integrity with row counts.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 11:30:00-06	2026-03-05 13:51:42.756204-06
task-36	Test Concurrent PostgreSQL Operations	done	alfred	critical	Spawn multiple subagents simultaneously to test concurrent writes. Verify no race conditions, deadlocks, or data corruption. Stress test the new system.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-09 19:45:42.937752-05	2026-03-09 19:45:42.937752-05
dadjoke-17-start	Start Dad Joke Video #17	complete	alfred	medium	Generate dad joke video #17	\N	agent:main:subagent:0b13f857-3713-4135-a93b-c86af9be1b20	2026-03-10 18:06:45.936843-05	2026-03-10 18:28:30.269915-05	\N	2026-03-10 18:38:46.536129-05
task-72-2	Test MinIO upload integration	backlog	alfred	high	Verify mc cp command uploads to hp1/dadjokes/backup/ bucket	\N	\N	2026-03-11 14:51:00.78086-05	\N	\N	2026-03-11 14:51:00.78086-05
task-72-3	Implement 30-day retention cleanup	backlog	alfred	medium	Delete backups older than 30 days from MinIO	\N	\N	2026-03-11 14:51:00.78086-05	\N	\N	2026-03-11 14:51:00.78086-05
task-35	Update Agent Hooks to Write to PostgreSQL	done	alfred	high	Update tools/agent-status-hook.js and openclaw-hooks.js to write to PostgreSQL. Test concurrent writes from multiple subagents.	\N	mock-1772724601405	2026-03-05 08:51:23.507-06	2026-03-05 09:30:01.405-06	2026-03-05 13:08:39.067018-06	2026-03-05 13:08:39.067018-06
task-34	Update Mission Control API Endpoints for PostgreSQL	done	jeeves	high	Update /api/tasks, /api/status, /api/subagents routes to use PostgreSQL instead of JSON files. Add connection pooling, prepared statements, error handling.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 11:30:00-06	2026-03-05 13:51:42.756204-06
task-40	Telegram Command: /status - Quick system status check	done	alfred	high	Add Telegram command handler for /status. Reply with: Tasks in progress, agent status (working/idle), recent completions (last 24h), system health (ollama/gateway/disk). No dashboard needed.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 13:52:11.616758-06	2026-03-05 14:57:15.984617-06	2026-03-05 14:57:15.984617-06
task-42	Make Mission Control responsive for multiple screen sizes (desktop, tablet, phone)	done	jeeves	medium	Implement responsive design for Mission Control dashboard to support desktop, tablet, and mobile devices. Use CSS Grid/Flexbox, media queries, and consider a mobile-first approach. Target breakpoints: 320px (phone), 768px (tablet), 1024px (desktop).	\N	\N	2026-03-05 13:32:43.286-06	\N	2026-03-05 14:57:15.98632-06	2026-03-05 14:57:15.98632-06
task-37	Remove Old JSON Files and Finalize Migration	done	jeeves	high	Backup old JSON files, remove from active use. Update documentation. Verify dashboard still works. Celebrate! 🎉	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 15:03:23.002872-06	2026-03-05 15:03:23.002872-06
task-38	Error Log Cleanup - Review and close resolved errors	done	alfred	medium	Review 14 errors in .learnings/ERRORS.md, categorize, close resolved ones (especially JSON corruption errors from migration). Set up better error logging/monitoring for future.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 15:04:16.196395-06	2026-03-05 15:06:39.952572-06	2026-03-05 15:06:39.952572-06
task-39	Dashboard Enhancement: PostgreSQL Migration Progress Widget	done	jeeves	medium	Add migration progress bar to Mission Control home page. Show: Phase X of Y complete, tables migrated, data integrity check %, time remaining. Real-time updates during migration.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 15:04:42.297896-06	2026-03-05 15:07:11.84006-06	2026-03-05 15:07:11.84006-06
task-41	Task Cleanup: Mark completed subtasks in parent tasks	done	alfred	low	Update parent tasks (task-7 Calendar, task-8 Second Brain) to mark all completed subtasks properly. Ensures accurate completion metrics and clean task hierarchy.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 15:07:27.720041-06	2026-03-05 15:07:49.663636-06	2026-03-05 15:07:49.663636-06
task-43	Implement Auto-Task-Status-Update Hook	done	alfred	high	When subagent completes, automatically update PostgreSQL tasks table with status=done. No manual intervention. Make atomic with completion.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 15:26:19.100462-06	2026-03-05 17:44:01.515389-06	2026-03-05 17:44:01.515389-06
task-45	Create Pre-Deployment Testing Checklist	done	alfred	high	Test API endpoints before production, verify component imports, check response structures match frontend. Prevents deployment bugs.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 17:46:16.828762-06	2026-03-05 17:49:06.079145-06	2026-03-05 17:49:06.079145-06
task-49	Institutionalize Post-Mortem Process	done	alfred	high	Create TEMPLATE-POSTMORTEM.md, completed first post-mortem on 2026-03-05 PostgreSQL migration	\N	\N	2026-03-05 15:21:31.49627-06	2026-03-05 15:21:31.49627-06	2026-03-05 22:27:01.060449-06	2026-03-05 22:27:01.060449-06
task-44	Add Subagent Health Monitoring	done	jeeves	high	Poll active sessions every 5 min, auto-re-spawn if session disappears, alert if respawn needed. Prevents silent failures.	\N	28daf48a-79c5-4f84-854a-7ad80a625d18	2026-03-05 15:21:47.810493-06	2026-03-05 16:14:11.468096-06	2026-03-05 19:33:24.6891-06	2026-03-05 19:33:24.6891-06
task-47	Add Deployment Testing Pipeline	done	jeeves	medium	Spin up test instance, run smoke tests, verify APIs before live. Catch bugs before user impact.	\N	test-run-456	2026-03-05 15:21:47.810493-06	2026-03-05 19:19:22.859484-06	2026-03-05 19:33:24.6891-06	2026-03-05 19:33:24.6891-06
task-46	Improve Error Logging System	done	alfred	medium	Automated error tracking/alerting, link errors to git commits, monthly review process. Better signal-to-noise.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 19:33:35.895654-06	2026-03-05 21:34:47.297022-06	2026-03-05 21:34:47.297022-06
task-48	Simplify Password Strategy	done	alfred	low	Use alphanumeric-only passwords in scripts, store secrets in env vars, document escaping requirements.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 22:02:00.552936-06	2026-03-05 23:08:02.527231-06	2026-03-05 23:00:01.510498-06
task-50	Calendar PostgreSQL Migration - Schema Design	done	alfred	high	Design and create PostgreSQL tables for calendar_events and reminders. Add indexes for date queries, recurring patterns. Create migration script.	\N	\N	2026-03-06 06:57:26.910023-06	\N	2026-03-06 07:01:07.127084-06	2026-03-06 07:01:07.127084-06
task-51	Calendar PostgreSQL Migration - Data Import	done	alfred	high	Write migration script to import existing JSON data (events.json, reminders.json) into PostgreSQL. Verify data integrity after import.	\N	task-51-migration	2026-03-06 06:57:26.910023-06	2026-03-06 07:00:24.067501-06	2026-03-06 07:01:07.187415-06	2026-03-06 07:01:07.187415-06
task-52	Calendar PostgreSQL Migration - Backend Library Update	done	alfred	high	Update src/lib/calendar/events.ts to use PostgreSQL queries instead of file system operations. Update all CRUD functions: getEvents, getReminders, createEvent, updateEvent, deleteEvent, etc.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:01:07.25672-06	2026-03-06 07:03:19.734737-06	2026-03-06 07:03:19.734737-06
task-53	Calendar PostgreSQL Migration - API Testing	done	alfred	medium	Verify all calendar API routes work with PostgreSQL backend. Test /api/calendar/month, /api/calendar/events, and any CRUD endpoints.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:03:19.820398-06	2026-03-06 07:06:17.082261-06	2026-03-06 07:06:17.082261-06
task-54	Calendar PostgreSQL Migration - UI Verification	done	jeeves	medium	Test Mission Control calendar UI with PostgreSQL backend. Verify monthly view, daily view, widgets, event creation/editing forms.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:06:17.183565-06	2026-03-06 07:06:35.893887-06	2026-03-06 07:06:35.893887-06
task-55	Calendar PostgreSQL Migration - Cleanup & Docs	done	alfred	low	Archive old JSON calendar files (do not delete). Update documentation. Add migration notes to OPERATIONAL-RUNBOOK.md.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:06:35.991003-06	2026-03-06 07:07:21.274709-06	2026-03-06 07:07:21.274709-06
task-56	Create Vercel-deployable Dinner Roulette web app with Sven	done	jeeves	high	Collaborate with Sven to create a Next.js/React web version of Dinner Roulette that can be deployed to Vercel. Extract core logic from Flutter app, rebuild as responsive web app.	\N	1687916c-8871-46b4-bb61-72da4be1d63d	2026-03-06 09:26:18.179053-06	2026-03-06 09:27:12.625592-06	2026-03-06 09:59:13.694293-06	2026-03-06 09:59:13.694293-06
task-57	Create GitHub repo russelopenclaw/DinnerRouletteWeb	done	alfred	high	Initialize new repository for Vercel-deployable web version.	\N	\N	2026-03-06 09:26:18.179053-06	\N	2026-03-06 10:29:01.860165-06	2026-03-06 10:29:01.860165-06
task-58	Document Vercel setup process for Kevin	done	alfred	medium	Create step-by-step guide for Kevin to set up Vercel account and connect to repo.	\N	\N	2026-03-06 09:26:18.179053-06	\N	2026-03-06 10:29:01.860165-06	2026-03-06 10:29:01.860165-06
task-59	Send Kevin Vercel setup walkthrough	done	alfred	high	Create and send detailed walkthrough for Kevin to set up Vercel and grant deploy access	\N	\N	2026-03-06 09:27:12.79568-06	\N	2026-03-06 10:29:01.860165-06	2026-03-06 10:29:01.860165-06
task-1772832952	HTTPS SSL Certificate Setup	complete	alfred	high	Configure Caddy reverse proxy with TLS for Mission Control	\N	\N	2026-03-06 15:35:52.726358-06	2026-03-06 15:35:52.726358-06	2026-03-06 15:36:44.469969-06	2026-03-06 15:36:44.469969-06
dadjoke-13	Create Dad Joke Video #13	complete	alfred	medium	Regenerating audio with full joke text + pause, correct background image, and proper text. Issues: 1) AI-generated human face, 2) No pause in audio, 3) Used wrong joke text	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-09 14:50:03.302149-05	2026-03-09 17:19:21.879242-05	2026-03-09 17:19:21.879242-05
dadjoke-14	Create Dad Joke Video #14	complete	alfred	medium	I went on a date with a girl from the zoo. She's a keeper.	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-09 17:33:44.912269-05	2026-03-09 18:25:52.716176-05	2026-03-09 18:25:52.716176-05
dadjoke-15	Create Dad Joke Video #15	complete	alfred	medium	I'm so good at sleeping I can do it with my eyes closed!	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-09 22:25:31.185206-05	\N	2026-03-10 15:07:05.95915-05
dadjoke-16	Create Dad Joke Video #16	complete	alfred	medium	What invention lets us see through walls? Windows.	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-10 12:24:09.013388-05	\N	2026-03-10 18:00:42.920978-05
dadjoke-17	Create Dad Joke Video #17	complete	alfred	medium	I have a fossil joke but you probably wouldn't dig it.	\N	70d0f39b-cce1-4aec-9e3e-61ba1b3d6601	2026-03-09 14:38:10.350449-05	2026-03-10 18:06:50.811481-05	\N	2026-03-10 18:07:13.834345-05
task-66	Smart Morning Briefing Automation	backlog	\N	high	Send briefings automatically at 8 AM via cron job. Impact: More reliable, one less thing to think about. Effort: 30 min	\N	\N	2026-03-11 14:23:41.820607-05	\N	\N	2026-03-11 14:23:41.820607-05
task-67	PostgreSQL Auto-Backup	backlog	\N	high	Nightly backup of mission_control database to MinIO with 30-day retention. Impact: Disaster recovery. Effort: 1 hour	\N	\N	2026-03-11 14:23:41.821998-05	\N	\N	2026-03-11 14:23:41.821998-05
task-68	Self-Healing System	backlog	\N	medium	Auto-restart services when they crash (Mission Control, Gateway, Ollama) with Telegram alerts. Impact: Higher uptime, proactive alerting. Effort: 2-3 hours	\N	\N	2026-03-11 14:23:41.822763-05	\N	\N	2026-03-11 14:23:41.822763-05
task-69	Sub-Agent Pool Management	backlog	\N	medium	Dynamic sub-agent spawning based on workload (scale up when backlog grows, scale down when idle). Impact: Better resource utilization. Effort: 3-4 hours	\N	\N	2026-03-11 14:23:41.823647-05	\N	\N	2026-03-11 14:23:41.823647-05
task-70	Mission Control Mobile App	backlog	\N	low	React Native / Flutter mobile version of Mission Control - check tasks/agents from phone. Impact: Access anywhere, push notifications. Effort: 8-12 hours	\N	\N	2026-03-11 14:23:41.824673-05	\N	\N	2026-03-11 14:23:41.824673-05
task-71	AI Task Suggester	backlog	\N	medium	Analyze completed work patterns + calendar to suggest high-value tasks automatically. Impact: Smarter prioritization. Effort: 4-6 hours	\N	\N	2026-03-11 14:23:41.825325-05	\N	\N	2026-03-11 14:23:41.825325-05
task-72-4	Add cron job for nightly execution	backlog	alfred	high	Schedule backup at 2 AM via cron	\N	\N	2026-03-11 14:51:00.78086-05	\N	\N	2026-03-11 14:51:00.78086-05
task-72-5	Document restoration procedure	backlog	alfred	medium	Write runbook for restoring from backup	\N	\N	2026-03-11 14:51:00.78086-05	\N	\N	2026-03-11 14:51:00.78086-05
task-72-1	Create backup script with pg_dump	in-progress	alfred	high	Write bash script using pg_dump to export mission_control database	\N	\N	2026-03-11 14:51:00.78086-05	2026-03-11 14:51:37.280694-05	\N	2026-03-11 14:51:37.280694-05
\.


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alfred
--

SELECT pg_catalog.setval('public.agents_id_seq', 7, true);


--
-- Name: task_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alfred
--

SELECT pg_catalog.setval('public.task_history_id_seq', 47, true);


--
-- Name: agents agents_name_key; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_name_key UNIQUE (name);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: subagents subagents_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.subagents
    ADD CONSTRAINT subagents_pkey PRIMARY KEY (run_id);


--
-- Name: task_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_agents_status ON public.agents USING btree (status);


--
-- Name: idx_events_date; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_events_date ON public.calendar_events USING btree (date);


--
-- Name: idx_events_recurring; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_events_recurring ON public.calendar_events USING btree (recurring_rule) WHERE (recurring_rule IS NOT NULL);


--
-- Name: idx_events_type; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_events_type ON public.calendar_events USING btree (type);


--
-- Name: idx_reminders_completed; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_reminders_completed ON public.reminders USING btree (completed) WHERE (completed = false);


--
-- Name: idx_reminders_due_date; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_reminders_due_date ON public.reminders USING btree (due_date);


--
-- Name: idx_reminders_recurring; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_reminders_recurring ON public.reminders USING btree (recurring_rule) WHERE (recurring_rule IS NOT NULL);


--
-- Name: idx_subagents_status; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_subagents_status ON public.subagents USING btree (status);


--
-- Name: idx_task_history_task_id; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_task_history_task_id ON public.task_history USING btree (task_id);


--
-- Name: idx_task_history_timestamp; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_task_history_timestamp ON public.task_history USING btree ("timestamp");


--
-- Name: idx_tasks_assignee; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_tasks_assignee ON public.tasks USING btree (assignee);


--
-- Name: idx_tasks_column; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_tasks_column ON public.tasks USING btree (column_name);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (column_name, priority);


--
-- Name: calendar_events update_calendar_events_updated_at; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER update_calendar_events_updated_at BEFORE UPDATE ON public.calendar_events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: reminders update_reminders_updated_at; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER update_reminders_updated_at BEFORE UPDATE ON public.reminders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: task_history task_history_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO alfred;


--
-- PostgreSQL database dump complete
--

\unrestrict jzdGZRLbju4vAYDEdFNedIG3sUaJLeog5EPE6Qh7y6zHqEa3nolU1W4aVSl6hoa


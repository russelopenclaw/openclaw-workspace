--
-- PostgreSQL database dump
--

\restrict 7Vr3iBqoXZrC3FQk7RN0Py9xTqL3eD6xm0kg8bLZ289fUeROG4IQB4vvYT7vdyp

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: trigger_auto_archive_done_tasks(); Type: FUNCTION; Schema: public; Owner: alfred
--

CREATE FUNCTION public.trigger_auto_archive_done_tasks() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Auto-set completed_at if not set
  IF NEW.column_name = 'DONE' AND NEW.completed_at IS NULL THEN
    NEW.completed_at := NOW();
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_auto_archive_done_tasks() OWNER TO alfred;

--
-- Name: trigger_new_task_after(); Type: FUNCTION; Schema: public; Owner: alfred
--

CREATE FUNCTION public.trigger_new_task_after() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Log creation to history
  INSERT INTO task_history (task_id, status, note)
  VALUES (NEW.id, 'created', 
    format('Task created: ID=%s, Title=%s, Column=%s, Agent=%s', 
      NEW.id::text, NEW.title, NEW.column_name, COALESCE(NEW.assignee, 'unassigned')));
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_new_task_after() OWNER TO alfred;

--
-- Name: trigger_new_task_before(); Type: FUNCTION; Schema: public; Owner: alfred
--

CREATE FUNCTION public.trigger_new_task_before() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
  -- New tasks start in BACKLOG (or READY if priority=high)
  IF NEW.column_name IS NULL OR NEW.column_name = '' THEN
    IF NEW.priority = 'high' THEN
      NEW.column_name := 'READY';
    ELSE
      NEW.column_name := 'BACKLOG';
    END IF;
  END IF;
  
  -- Auto-generate task ID if not provided
  IF NEW.id IS NULL OR NEW.id = '' THEN
    NEW.id := 'T-' || COALESCE(
      (SELECT MAX(CAST(SUBSTRING(id FROM 3) AS INTEGER)) + 1 FROM tasks WHERE id ~ '^T-[0-9]+$'),
      101
    )::TEXT;
  END IF;
  
  -- Validate required fields
  IF NEW.deliverables IS NULL OR NEW.deliverables = '' THEN
    RAISE EXCEPTION 'DELIVERABLES_REQUIRED: Task must have deliverables specified. See tools/create-task.js';
  END IF;
  
  -- Set timestamps
  NEW.created_at := NOW();
  NEW.updated_at := NOW();
  
  RETURN NEW;
END;
$_$;


ALTER FUNCTION public.trigger_new_task_before() OWNER TO alfred;

--
-- Name: trigger_task_status_change(); Type: FUNCTION; Schema: public; Owner: alfred
--

CREATE FUNCTION public.trigger_task_status_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  action_text TEXT;
BEGIN
  -- Only fire if column actually changed
  IF OLD.column_name IS DISTINCT FROM NEW.column_name THEN
    
    action_text := format('Transition: %s → %s', OLD.column_name, NEW.column_name);
    
    -- Auto-set timestamps based on new status
    IF NEW.column_name = 'IN_PROGRESS' AND OLD.started_at IS NULL THEN
      NEW.started_at := NOW();
    END IF;
    
    IF NEW.column_name = 'DONE' AND OLD.completed_at IS NULL THEN
      NEW.completed_at := NOW();
    END IF;
    
    NEW.updated_at := NOW();
    
    -- Log transition to history
    INSERT INTO task_history (task_id, status, note)
    VALUES (
      NEW.id, 
      'status_change', 
      action_text
    );
    
    -- Emit notification (for webhook listeners)
    PERFORM pg_notify('task_status_changed', json_build_object(
      'task_id', NEW.id,
      'from', OLD.column_name,
      'to', NEW.column_name,
      'title', NEW.title,
      'assignee', NEW.assignee,
      'timestamp', NOW()
    )::text);
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_task_status_change() OWNER TO alfred;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: alfred
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO alfred;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    current_task text,
    last_activity timestamp with time zone DEFAULT now(),
    CONSTRAINT agents_status_check CHECK (((status)::text = ANY ((ARRAY['working'::character varying, 'idle'::character varying, 'offline'::character varying])::text[])))
);


ALTER TABLE public.agents OWNER TO alfred;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: alfred
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agents_id_seq OWNER TO alfred;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alfred
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.calendar_events (
    id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone,
    type character varying(20),
    description text,
    location character varying(500),
    recurring_rule character varying(500),
    recurring_until date,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT calendar_events_type_check CHECK (((type)::text = ANY ((ARRAY['personal'::character varying, 'meeting'::character varying, 'reminder'::character varying, 'cron'::character varying])::text[])))
);


ALTER TABLE public.calendar_events OWNER TO alfred;

--
-- Name: TABLE calendar_events; Type: COMMENT; Schema: public; Owner: alfred
--

COMMENT ON TABLE public.calendar_events IS 'Calendar events: meetings, personal events, reminders, and cron jobs';


--
-- Name: COLUMN calendar_events.recurring_rule; Type: COMMENT; Schema: public; Owner: alfred
--

COMMENT ON COLUMN public.calendar_events.recurring_rule IS 'iCalendar RRULE format (RFC 5545)';


--
-- Name: event_log; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.event_log (
    id integer NOT NULL,
    channel character varying(50) NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_log OWNER TO alfred;

--
-- Name: event_log_id_seq; Type: SEQUENCE; Schema: public; Owner: alfred
--

CREATE SEQUENCE public.event_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.event_log_id_seq OWNER TO alfred;

--
-- Name: event_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alfred
--

ALTER SEQUENCE public.event_log_id_seq OWNED BY public.event_log.id;


--
-- Name: reminders; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.reminders (
    id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    due_date date NOT NULL,
    due_time time without time zone,
    recurring_rule character varying(500),
    recurring_until date,
    completed boolean DEFAULT false,
    notified_at timestamp with time zone,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reminders OWNER TO alfred;

--
-- Name: TABLE reminders; Type: COMMENT; Schema: public; Owner: alfred
--

COMMENT ON TABLE public.reminders IS 'User reminders with optional recurrence and notification tracking';


--
-- Name: screensaver_prompts; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.screensaver_prompts (
    id character varying(50) NOT NULL,
    video_number integer NOT NULL,
    video_title character varying(200) NOT NULL,
    prompt_number integer NOT NULL,
    model character varying(50) NOT NULL,
    prompt_text text NOT NULL,
    negative_prompt text DEFAULT 'blurry, low quality, distorted, deformed objects, watermark, text'::text,
    status character varying(20) DEFAULT 'pending'::character varying,
    image_path character varying(500),
    video_path character varying(500),
    validation_result text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    sampler character varying(50) DEFAULT 'DPM++ 2M Karras'::character varying,
    steps integer DEFAULT 30,
    effect_type character varying(30) DEFAULT 'none'::character varying,
    effect_duration integer DEFAULT 24,
    audio_track character varying(500),
    audio_volume numeric(3,2) DEFAULT 0.5,
    seed integer,
    share_url character varying(500)
);


ALTER TABLE public.screensaver_prompts OWNER TO alfred;

--
-- Name: subagents; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.subagents (
    run_id character varying(100) NOT NULL,
    label character varying(200),
    task character varying(500),
    status character varying(20),
    runtime character varying(20),
    total_tokens bigint,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    note text
);


ALTER TABLE public.subagents OWNER TO alfred;

--
-- Name: task_history; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.task_history (
    id integer NOT NULL,
    task_id character varying(50),
    status character varying(50),
    "timestamp" timestamp with time zone DEFAULT now(),
    note text
);


ALTER TABLE public.task_history OWNER TO alfred;

--
-- Name: task_history_id_seq; Type: SEQUENCE; Schema: public; Owner: alfred
--

CREATE SEQUENCE public.task_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_history_id_seq OWNER TO alfred;

--
-- Name: task_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alfred
--

ALTER SEQUENCE public.task_history_id_seq OWNED BY public.task_history.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: alfred
--

CREATE TABLE public.tasks (
    id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    column_name character varying(50) NOT NULL,
    assignee character varying(50),
    priority character varying(20) DEFAULT 'medium'::character varying,
    description text,
    parent_task_id character varying(50),
    linked_subagent character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now(),
    deliverables text,
    validation_criteria text[]
);


ALTER TABLE public.tasks OWNER TO alfred;

--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: event_log id; Type: DEFAULT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.event_log ALTER COLUMN id SET DEFAULT nextval('public.event_log_id_seq'::regclass);


--
-- Name: task_history id; Type: DEFAULT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.task_history ALTER COLUMN id SET DEFAULT nextval('public.task_history_id_seq'::regclass);


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.agents (id, name, status, current_task, last_activity) FROM stdin;
1	alfred	working	Heartbeat check	2026-04-15 01:46:32.576935-05
2	jeeves	idle	Standing by	2026-04-14 18:42:27.646657-05
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.calendar_events (id, title, date, start_time, end_time, type, description, location, recurring_rule, recurring_until, created_at, updated_at) FROM stdin;
evt-1772595247161	Team meeting	2026-03-04	14:00:00	15:00:00	personal	\N	\N	\N	\N	2026-03-06 06:58:53.0681-06	2026-03-06 06:58:53.0681-06
evt-1772597198793	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.085827-06	2026-03-06 06:58:53.085827-06
evt-1772597198814	Daily scrum at 8am	2026-03-03	08:00:00	09:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR	\N	2026-03-06 06:58:53.086891-06	2026-03-06 06:58:53.086891-06
evt-1772597198816	Team lunch	2026-03-03	12:00:00	13:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=FR	\N	2026-03-06 06:58:53.088671-06	2026-03-06 06:58:53.088671-06
evt-1772597202310	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.089825-06	2026-03-06 06:58:53.089825-06
evt-1772597202328	Team lunch	2026-03-03	12:00:00	13:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=FR	\N	2026-03-06 06:58:53.090765-06	2026-03-06 06:58:53.091984-06
evt-1772597533939	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.093259-06	2026-03-06 06:58:53.093259-06
evt-1772597533957	Daily scrum at 8am	2026-03-03	08:00:00	09:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR	\N	2026-03-06 06:58:53.094376-06	2026-03-06 06:58:53.094376-06
evt-1772600095771	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.095209-06	2026-03-06 06:58:53.095209-06
evt-1772600218585	Lunch meeting	2026-03-03	14:00:00	15:00:00	personal	\N	\N	\N	\N	2026-03-06 06:58:53.09641-06	2026-03-06 06:58:53.09641-06
evt-1772601359190	Weekly standup	2026-03-03	09:00:00	10:00:00	personal	\N	\N	FREQ=WEEKLY;BYDAY=MO	\N	2026-03-06 06:58:53.097224-06	2026-03-06 06:58:53.097224-06
evt-1772601359208	Daily standup	2026-03-03	08:00:00	09:00:00	personal	\N	\N	FREQ=DAILY	\N	2026-03-06 06:58:53.098228-06	2026-03-06 06:58:53.098228-06
evt-1772631056719	Deacons Meeting	2026-03-17	18:00:00	20:00:00	personal	Monthly deacons meeting	\N	\N	\N	2026-03-06 06:58:53.099002-06	2026-03-06 06:58:53.099002-06
\.


--
-- Data for Name: event_log; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.event_log (id, channel, data, created_at) FROM stdin;
1	agents	{"task": "Building MC improvements", "type": "status_update", "agent": "alfred", "status": "working"}	2026-04-14 19:52:30.046888-05
2	agents	{"task": "Evening report", "type": "status_update", "agent": "alfred", "status": "working"}	2026-04-14 20:01:13.538954-05
3	agents	{"task": "Idle - evening", "type": "status_update", "agent": "alfred", "status": "idle"}	2026-04-14 20:46:31.922687-05
4	agents	{"task": "Idle - late evening", "type": "status_update", "agent": "alfred", "status": "idle"}	2026-04-14 21:16:55.941722-05
5	agents	{"task": "Heartbeat check", "type": "status_update", "agent": "alfred", "status": "working"}	2026-04-14 23:01:34.257466-05
6	agents	{"task": "Heartbeat check", "type": "status_update", "agent": "alfred", "status": "working"}	2026-04-14 23:02:17.057277-05
7	agents	{"task": "Heartbeat check", "type": "status_update", "agent": "alfred", "status": "working"}	2026-04-14 23:16:23.74413-05
8	agents	{"task": "Heartbeat check", "type": "status_update", "agent": "alfred", "status": "working"}	2026-04-15 00:47:11.366614-05
9	agents	{"task": "Heartbeat check", "type": "status_update", "agent": "alfred", "status": "working"}	2026-04-15 01:46:32.631931-05
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.reminders (id, title, due_date, due_time, recurring_rule, recurring_until, completed, notified_at, description, created_at, updated_at) FROM stdin;
call-tino-hinojosa	Call Tino Hinojosa	2026-03-16	14:00:00	\N	\N	t	\N	Phone: 913-944-9829	2026-03-16 12:24:19.708466-05	2026-03-16 14:49:49.747223-05
rem-1772639702263	Deacons Meeting in 24 hours	2026-03-16	18:00:00	\N	\N	t	\N	\N	2026-03-06 06:58:53.100682-06	2026-03-16 22:09:36.801255-05
call-ionos	Call Ionos	2026-03-16	17:00:00	\N	\N	t	\N	Phone: +1-484-254-5555	2026-03-16 12:26:09.54958-05	2026-03-16 22:09:36.801255-05
call-steve-adams	Call Steve Adams	2026-03-16	15:30:00	\N	\N	t	\N	Phone call	2026-03-16 12:27:23.405322-05	2026-03-16 22:09:36.801255-05
call-ionos-2026-03-17	Call Ionos	2026-03-17	16:30:00	\N	\N	t	2026-03-17 17:14:14.312318-05	Phone: +1-484-254-5555	2026-03-17 09:10:50.96331-05	2026-03-18 09:05:34.684484-05
pick-up-titus-2026-03-18	pick up Titus	2026-03-18	20:30:00	\N	\N	t	\N	Natural language reminder: "Remind me to pick up Titus at 8:30 PM"	2026-03-18 09:10:04.87514-05	2026-03-18 20:49:14.061975-05
call-ionos-2026-03-18	Call Ionos (1-484-254-5555)	2026-03-19	16:30:00	\N	\N	f	2026-03-24 07:26:01.287275-05	Natural language reminder: "Remind me to call Ionos (1-484-254-5555) at 4:30 PM"	2026-03-18 09:07:52.954363-05	2026-03-24 07:26:01.287275-05
model-awareness-review	Alfred Model Awareness Review	2026-03-30	10:00:00	\N	\N	f	2026-04-14 21:16:57.228314-05	Review how the Model Awareness approach is working:\n1. Delegation rate: How often did I pause and ask "should I delegate this?"\n2. Model matching: Did I pick the right model for the right task?\n3. Subagent effectiveness: Were delegated tasks completed well?\n4. Missed opportunities: Tasks I should have delegated but did myself?\nContext: On 2026-03-16, Kevin and I discussed the "Company Model" - Alfred as CEO, subagents as department heads. The goal is to create a mental pause before execution.	2026-03-16 11:52:01.174389-05	2026-04-14 21:16:57.228314-05
\.


--
-- Data for Name: screensaver_prompts; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.screensaver_prompts (id, video_number, video_title, prompt_number, model, prompt_text, negative_prompt, status, image_path, video_path, validation_result, created_at, updated_at, completed_at, sampler, steps, effect_type, effect_duration, audio_track, audio_volume, seed, share_url) FROM stdin;
video-1-prompt-1	1	Cherry Blossom Meditation Garden	1	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	complete	screensavers/cherry-blossom/raw/img_01.png	\N	PASS: No text detected (Qwen3.5 vision analysis). Image shows cherry blossom trees with pink flowers, stone pathway, good quality. Suitable for screensaver.	2026-03-17 09:32:18.195024	2026-03-20 13:52:40.487276	2026-03-20 13:52:40.487276	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-1-prompt-2	1	Cherry Blossom Meditation Garden	2	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:18.318722	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-1-prompt-3	1	Cherry Blossom Meditation Garden	3	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:18.47904	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-4	1	Cherry Blossom Meditation Garden	4	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:18.61961	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-1-prompt-5	1	Cherry Blossom Meditation Garden	5	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:18.779478	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-6	1	Cherry Blossom Meditation Garden	6	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:18.95177	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-1-prompt-7	1	Cherry Blossom Meditation Garden	7	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:19.104001	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-8	1	Cherry Blossom Meditation Garden	8	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:19.263368	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-1-prompt-9	1	Cherry Blossom Meditation Garden	9	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:19.404857	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-1-prompt-10	1	Cherry Blossom Meditation Garden	10	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:19.544697	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-1-prompt-11	1	Cherry Blossom Meditation Garden	11	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:19.684599	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-1-prompt-12	1	Cherry Blossom Meditation Garden	12	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:19.828974	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-1-prompt-13	1	Cherry Blossom Meditation Garden	13	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:19.999821	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-1-prompt-14	1	Cherry Blossom Meditation Garden	14	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:20.149321	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-15	1	Cherry Blossom Meditation Garden	15	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:20.293338	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-1-prompt-16	1	Cherry Blossom Meditation Garden	16	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:20.448279	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-1-prompt-17	1	Cherry Blossom Meditation Garden	17	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:20.585277	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-1-prompt-18	1	Cherry Blossom Meditation Garden	18	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:20.726094	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-1-prompt-19	1	Cherry Blossom Meditation Garden	19	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:20.865051	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-1-prompt-20	1	Cherry Blossom Meditation Garden	20	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:21.009012	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-1-prompt-21	1	Cherry Blossom Meditation Garden	21	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:21.165806	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-1-prompt-22	1	Cherry Blossom Meditation Garden	22	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:21.303629	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-1-prompt-23	1	Cherry Blossom Meditation Garden	23	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:21.447518	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-1-prompt-24	1	Cherry Blossom Meditation Garden	24	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:21.587097	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-25	1	Cherry Blossom Meditation Garden	25	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:21.7361	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-1-prompt-26	1	Cherry Blossom Meditation Garden	26	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:21.878609	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-1-prompt-27	1	Cherry Blossom Meditation Garden	27	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:22.018818	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-1-prompt-28	1	Cherry Blossom Meditation Garden	28	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:22.159035	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-29	1	Cherry Blossom Meditation Garden	29	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:22.299286	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-1-prompt-30	1	Cherry Blossom Meditation Garden	30	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:22.441393	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-1-prompt-31	1	Cherry Blossom Meditation Garden	31	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:22.581592	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-1-prompt-32	1	Cherry Blossom Meditation Garden	32	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:22.732841	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-1-prompt-33	1	Cherry Blossom Meditation Garden	33	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:22.873901	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-1-prompt-34	1	Cherry Blossom Meditation Garden	34	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.01384	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-1-prompt-35	1	Cherry Blossom Meditation Garden	35	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.152497	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-1-prompt-36	1	Cherry Blossom Meditation Garden	36	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.291745	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-1-prompt-37	1	Cherry Blossom Meditation Garden	37	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.435386	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-38	1	Cherry Blossom Meditation Garden	38	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.572202	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-1-prompt-39	1	Cherry Blossom Meditation Garden	39	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.691234	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-1-prompt-40	1	Cherry Blossom Meditation Garden	40	juggernautXL	Japanese cherry blossom meditation garden, stone path, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.828122	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-1	2	Bamboo Forest Serenity	1	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:23.970827	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-2-prompt-2	2	Bamboo Forest Serenity	2	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:24.11617	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-3	2	Bamboo Forest Serenity	3	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:24.26377	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-2-prompt-4	2	Bamboo Forest Serenity	4	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:24.411479	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-5	2	Bamboo Forest Serenity	5	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:24.552201	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-2-prompt-6	2	Bamboo Forest Serenity	6	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:24.70309	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-7	2	Bamboo Forest Serenity	7	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:24.843592	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-8	2	Bamboo Forest Serenity	8	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:24.981481	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-9	2	Bamboo Forest Serenity	9	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:25.126672	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-2-prompt-10	2	Bamboo Forest Serenity	10	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:25.266884	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-11	2	Bamboo Forest Serenity	11	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:25.414511	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-2-prompt-12	2	Bamboo Forest Serenity	12	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:25.554162	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-13	2	Bamboo Forest Serenity	13	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:25.695165	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-14	2	Bamboo Forest Serenity	14	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:25.835076	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-2-prompt-15	2	Bamboo Forest Serenity	15	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:25.97659	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-16	2	Bamboo Forest Serenity	16	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:26.115095	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-2-prompt-17	2	Bamboo Forest Serenity	17	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:26.257391	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-18	2	Bamboo Forest Serenity	18	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:26.399354	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-2-prompt-19	2	Bamboo Forest Serenity	19	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:26.540757	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-20	2	Bamboo Forest Serenity	20	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:26.681081	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-21	2	Bamboo Forest Serenity	21	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:26.819218	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-2-prompt-22	2	Bamboo Forest Serenity	22	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:26.961208	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-2-prompt-23	2	Bamboo Forest Serenity	23	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:27.104567	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-24	2	Bamboo Forest Serenity	24	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:27.245904	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-2-prompt-25	2	Bamboo Forest Serenity	25	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:27.386014	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-2-prompt-26	2	Bamboo Forest Serenity	26	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:27.52413	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-27	2	Bamboo Forest Serenity	27	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:27.667879	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-2-prompt-28	2	Bamboo Forest Serenity	28	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:27.832748	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-29	2	Bamboo Forest Serenity	29	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:28.00064	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-30	2	Bamboo Forest Serenity	30	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:28.146177	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-31	2	Bamboo Forest Serenity	31	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:28.289725	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-32	2	Bamboo Forest Serenity	32	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:28.430579	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-33	2	Bamboo Forest Serenity	33	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:28.576372	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-34	2	Bamboo Forest Serenity	34	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:28.717401	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-2-prompt-35	2	Bamboo Forest Serenity	35	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:28.858168	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-2-prompt-36	2	Bamboo Forest Serenity	36	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:29.004037	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-2-prompt-37	2	Bamboo Forest Serenity	37	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:29.170259	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-2-prompt-38	2	Bamboo Forest Serenity	38	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:29.320754	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-2-prompt-39	2	Bamboo Forest Serenity	39	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:29.464116	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-2-prompt-40	2	Bamboo Forest Serenity	40	realvisXL	peaceful bamboo forest path, tall bamboo, tranquil nature scene,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:29.603334	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-3-prompt-1	3	Ocean Sunset Calm	1	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:29.74257	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-3-prompt-2	3	Ocean Sunset Calm	2	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:29.88032	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-3-prompt-3	3	Ocean Sunset Calm	3	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:30.024152	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-3-prompt-4	3	Ocean Sunset Calm	4	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:30.167818	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-3-prompt-5	3	Ocean Sunset Calm	5	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:30.307226	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-3-prompt-6	3	Ocean Sunset Calm	6	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:30.456576	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-3-prompt-7	3	Ocean Sunset Calm	7	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:30.592873	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-3-prompt-8	3	Ocean Sunset Calm	8	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:30.733479	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-3-prompt-9	3	Ocean Sunset Calm	9	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:30.88091	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-3-prompt-10	3	Ocean Sunset Calm	10	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:31.02407	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-3-prompt-11	3	Ocean Sunset Calm	11	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:31.162658	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-3-prompt-12	3	Ocean Sunset Calm	12	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:31.303534	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-3-prompt-13	3	Ocean Sunset Calm	13	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:31.445168	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-3-prompt-14	3	Ocean Sunset Calm	14	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:31.583161	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-3-prompt-15	3	Ocean Sunset Calm	15	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:31.73637	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-3-prompt-16	3	Ocean Sunset Calm	16	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:31.887034	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-3-prompt-17	3	Ocean Sunset Calm	17	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:32.027011	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-3-prompt-18	3	Ocean Sunset Calm	18	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:32.168908	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-3-prompt-19	3	Ocean Sunset Calm	19	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:32.307312	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-3-prompt-20	3	Ocean Sunset Calm	20	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:32.450449	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-3-prompt-21	3	Ocean Sunset Calm	21	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:32.598074	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-3-prompt-22	3	Ocean Sunset Calm	22	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:32.739569	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-3-prompt-23	3	Ocean Sunset Calm	23	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:32.881798	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-3-prompt-24	3	Ocean Sunset Calm	24	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:33.025407	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-3-prompt-25	3	Ocean Sunset Calm	25	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:33.169928	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-3-prompt-26	3	Ocean Sunset Calm	26	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:33.313081	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-3-prompt-27	3	Ocean Sunset Calm	27	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:33.455456	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-3-prompt-28	3	Ocean Sunset Calm	28	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:33.60219	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-3-prompt-29	3	Ocean Sunset Calm	29	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:33.751145	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-3-prompt-30	3	Ocean Sunset Calm	30	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:33.891443	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-3-prompt-31	3	Ocean Sunset Calm	31	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:34.032142	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-3-prompt-32	3	Ocean Sunset Calm	32	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:34.180424	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-3-prompt-33	3	Ocean Sunset Calm	33	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:34.317978	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-3-prompt-34	3	Ocean Sunset Calm	34	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:34.457831	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-3-prompt-35	3	Ocean Sunset Calm	35	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:34.595815	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-3-prompt-36	3	Ocean Sunset Calm	36	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:34.736614	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-3-prompt-37	3	Ocean Sunset Calm	37	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:34.874535	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-3-prompt-38	3	Ocean Sunset Calm	38	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:35.048117	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-3-prompt-39	3	Ocean Sunset Calm	39	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:35.188972	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-3-prompt-40	3	Ocean Sunset Calm	40	realvisXL	calm tropical ocean shoreline, gentle waves, peaceful beach,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:35.328112	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-4-prompt-1	4	Rainy Japanese Tea Garden	1	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:35.491164	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-2	4	Rainy Japanese Tea Garden	2	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:35.648202	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-4-prompt-3	4	Rainy Japanese Tea Garden	3	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:35.78782	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-4-prompt-4	4	Rainy Japanese Tea Garden	4	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:35.926079	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-4-prompt-5	4	Rainy Japanese Tea Garden	5	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:36.069069	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-4-prompt-6	4	Rainy Japanese Tea Garden	6	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:36.218773	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-4-prompt-7	4	Rainy Japanese Tea Garden	7	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:36.358157	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-8	4	Rainy Japanese Tea Garden	8	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:36.500413	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-9	4	Rainy Japanese Tea Garden	9	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:36.641908	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-4-prompt-10	4	Rainy Japanese Tea Garden	10	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:36.779797	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-11	4	Rainy Japanese Tea Garden	11	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:36.921262	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-12	4	Rainy Japanese Tea Garden	12	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:37.065811	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-4-prompt-13	4	Rainy Japanese Tea Garden	13	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:37.210182	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-14	4	Rainy Japanese Tea Garden	14	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:37.35294	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-4-prompt-15	4	Rainy Japanese Tea Garden	15	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:37.499451	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-4-prompt-16	4	Rainy Japanese Tea Garden	16	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:37.645809	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-17	4	Rainy Japanese Tea Garden	17	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:37.787328	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-4-prompt-18	4	Rainy Japanese Tea Garden	18	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:37.931152	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-4-prompt-19	4	Rainy Japanese Tea Garden	19	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:38.07443	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-20	4	Rainy Japanese Tea Garden	20	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:38.217143	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-21	4	Rainy Japanese Tea Garden	21	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:38.357101	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-4-prompt-22	4	Rainy Japanese Tea Garden	22	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:38.499193	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-23	4	Rainy Japanese Tea Garden	23	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:38.641044	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-24	4	Rainy Japanese Tea Garden	24	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:38.79017	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-4-prompt-25	4	Rainy Japanese Tea Garden	25	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:38.942335	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-26	4	Rainy Japanese Tea Garden	26	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:39.083066	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-27	4	Rainy Japanese Tea Garden	27	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:39.230026	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-4-prompt-28	4	Rainy Japanese Tea Garden	28	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:39.367201	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-29	4	Rainy Japanese Tea Garden	29	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:39.508106	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-4-prompt-30	4	Rainy Japanese Tea Garden	30	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:39.648117	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-4-prompt-31	4	Rainy Japanese Tea Garden	31	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:39.787044	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-32	4	Rainy Japanese Tea Garden	32	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:39.930534	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-4-prompt-33	4	Rainy Japanese Tea Garden	33	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:40.068469	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-34	4	Rainy Japanese Tea Garden	34	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:40.211902	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-4-prompt-35	4	Rainy Japanese Tea Garden	35	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:40.350224	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-36	4	Rainy Japanese Tea Garden	36	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:40.490487	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-4-prompt-37	4	Rainy Japanese Tea Garden	37	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:40.631255	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-38	4	Rainy Japanese Tea Garden	38	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:40.771607	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-4-prompt-39	4	Rainy Japanese Tea Garden	39	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:40.919305	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-4-prompt-40	4	Rainy Japanese Tea Garden	40	juggernautXL	japanese tea garden with stone path and lanterns, gentle rain,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:41.056216	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-5-prompt-1	5	Zen Temple Courtyard	1	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:41.199492	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-5-prompt-2	5	Zen Temple Courtyard	2	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:41.337696	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-5-prompt-3	5	Zen Temple Courtyard	3	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:41.481614	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-5-prompt-4	5	Zen Temple Courtyard	4	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:41.624677	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-5-prompt-5	5	Zen Temple Courtyard	5	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:41.758427	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-5-prompt-6	5	Zen Temple Courtyard	6	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:41.899355	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-5-prompt-7	5	Zen Temple Courtyard	7	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:42.04106	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-5-prompt-8	5	Zen Temple Courtyard	8	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:42.181731	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-9	5	Zen Temple Courtyard	9	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:42.318274	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-5-prompt-10	5	Zen Temple Courtyard	10	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:42.45825	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-5-prompt-11	5	Zen Temple Courtyard	11	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:42.59583	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-5-prompt-12	5	Zen Temple Courtyard	12	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:42.73798	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-5-prompt-13	5	Zen Temple Courtyard	13	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:42.877023	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-14	5	Zen Temple Courtyard	14	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:43.019323	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-5-prompt-15	5	Zen Temple Courtyard	15	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:43.172208	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-5-prompt-16	5	Zen Temple Courtyard	16	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:43.311561	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-5-prompt-17	5	Zen Temple Courtyard	17	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:43.460397	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-18	5	Zen Temple Courtyard	18	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:43.599952	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-5-prompt-19	5	Zen Temple Courtyard	19	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:43.740376	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-20	5	Zen Temple Courtyard	20	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:43.881413	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-5-prompt-21	5	Zen Temple Courtyard	21	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:44.022001	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-22	5	Zen Temple Courtyard	22	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:44.163004	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-5-prompt-23	5	Zen Temple Courtyard	23	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:44.301908	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-5-prompt-24	5	Zen Temple Courtyard	24	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:44.45456	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-25	5	Zen Temple Courtyard	25	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:44.602729	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-5-prompt-26	5	Zen Temple Courtyard	26	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:44.741929	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-5-prompt-27	5	Zen Temple Courtyard	27	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:44.880869	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-5-prompt-28	5	Zen Temple Courtyard	28	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.008925	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-5-prompt-29	5	Zen Temple Courtyard	29	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.149571	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-5-prompt-30	5	Zen Temple Courtyard	30	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.289393	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-5-prompt-31	5	Zen Temple Courtyard	31	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.43085	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-5-prompt-32	5	Zen Temple Courtyard	32	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.531548	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-33	5	Zen Temple Courtyard	33	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.677715	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-5-prompt-34	5	Zen Temple Courtyard	34	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.816274	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-5-prompt-35	5	Zen Temple Courtyard	35	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:45.968807	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-5-prompt-36	5	Zen Temple Courtyard	36	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:46.117331	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-5-prompt-37	5	Zen Temple Courtyard	37	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:46.26196	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-5-prompt-38	5	Zen Temple Courtyard	38	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:46.412758	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-5-prompt-39	5	Zen Temple Courtyard	39	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:46.555176	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-5-prompt-40	5	Zen Temple Courtyard	40	juggernautXL	ancient japanese zen temple courtyard, peaceful meditation space,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:46.713433	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-6-prompt-1	6	Mountain Lake Reflection	1	realvisXL	calm alpine mountain lake with mirror reflections, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:46.857218	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-2	6	Mountain Lake Reflection	2	realvisXL	calm alpine mountain lake with mirror reflections, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:47.013122	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-6-prompt-3	6	Mountain Lake Reflection	3	realvisXL	calm alpine mountain lake with mirror reflections, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:47.154955	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-4	6	Mountain Lake Reflection	4	realvisXL	calm alpine mountain lake with mirror reflections, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:47.298497	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-6-prompt-5	6	Mountain Lake Reflection	5	realvisXL	calm alpine mountain lake with mirror reflections, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:47.448566	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-6-prompt-6	6	Mountain Lake Reflection	6	realvisXL	calm alpine mountain lake with mirror reflections, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:47.563249	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-6-prompt-7	6	Mountain Lake Reflection	7	realvisXL	calm alpine mountain lake with mirror reflections, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:47.709354	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-6-prompt-8	6	Mountain Lake Reflection	8	realvisXL	calm alpine mountain lake with mirror reflections, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:47.851381	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-6-prompt-9	6	Mountain Lake Reflection	9	realvisXL	calm alpine mountain lake with mirror reflections, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:48.005273	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-10	6	Mountain Lake Reflection	10	realvisXL	calm alpine mountain lake with mirror reflections, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:48.146277	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-6-prompt-11	6	Mountain Lake Reflection	11	realvisXL	calm alpine mountain lake with mirror reflections, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:48.286966	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-6-prompt-12	6	Mountain Lake Reflection	12	realvisXL	calm alpine mountain lake with mirror reflections, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:48.428721	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-6-prompt-13	6	Mountain Lake Reflection	13	realvisXL	calm alpine mountain lake with mirror reflections, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:48.577079	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-6-prompt-14	6	Mountain Lake Reflection	14	realvisXL	calm alpine mountain lake with mirror reflections, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:48.720895	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-6-prompt-15	6	Mountain Lake Reflection	15	realvisXL	calm alpine mountain lake with mirror reflections, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:48.864491	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-16	6	Mountain Lake Reflection	16	realvisXL	calm alpine mountain lake with mirror reflections, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:49.006505	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-6-prompt-17	6	Mountain Lake Reflection	17	realvisXL	calm alpine mountain lake with mirror reflections, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:49.146598	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-18	6	Mountain Lake Reflection	18	realvisXL	calm alpine mountain lake with mirror reflections, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:49.291287	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-6-prompt-19	6	Mountain Lake Reflection	19	realvisXL	calm alpine mountain lake with mirror reflections, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:49.435489	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-6-prompt-20	6	Mountain Lake Reflection	20	realvisXL	calm alpine mountain lake with mirror reflections, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:49.581342	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-6-prompt-21	6	Mountain Lake Reflection	21	realvisXL	calm alpine mountain lake with mirror reflections, soft fog,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:49.724422	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-6-prompt-22	6	Mountain Lake Reflection	22	realvisXL	calm alpine mountain lake with mirror reflections, soft fog, wide	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:49.867354	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-6-prompt-23	6	Mountain Lake Reflection	23	realvisXL	calm alpine mountain lake with mirror reflections, soft fog, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:50.028978	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-6-prompt-24	6	Mountain Lake Reflection	24	realvisXL	calm alpine mountain lake with mirror reflections, soft fog,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:50.164581	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-25	6	Mountain Lake Reflection	25	realvisXL	calm alpine mountain lake with mirror reflections, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:50.318403	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-6-prompt-26	6	Mountain Lake Reflection	26	realvisXL	calm alpine mountain lake with mirror reflections, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:50.480508	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-6-prompt-27	6	Mountain Lake Reflection	27	realvisXL	calm alpine mountain lake with mirror reflections, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:50.655163	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-6-prompt-28	6	Mountain Lake Reflection	28	realvisXL	calm alpine mountain lake with mirror reflections, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:50.802701	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-6-prompt-29	6	Mountain Lake Reflection	29	realvisXL	calm alpine mountain lake with mirror reflections, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:50.946155	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-6-prompt-30	6	Mountain Lake Reflection	30	realvisXL	calm alpine mountain lake with mirror reflections, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:51.091977	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-31	6	Mountain Lake Reflection	31	realvisXL	calm alpine mountain lake with mirror reflections, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:51.246127	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-6-prompt-32	6	Mountain Lake Reflection	32	realvisXL	calm alpine mountain lake with mirror reflections, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:51.410526	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-6-prompt-33	6	Mountain Lake Reflection	33	realvisXL	calm alpine mountain lake with mirror reflections, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:51.518347	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-6-prompt-34	6	Mountain Lake Reflection	34	realvisXL	calm alpine mountain lake with mirror reflections, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:51.676404	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-6-prompt-35	6	Mountain Lake Reflection	35	realvisXL	calm alpine mountain lake with mirror reflections, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:51.777179	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-6-prompt-36	6	Mountain Lake Reflection	36	realvisXL	calm alpine mountain lake with mirror reflections, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:51.919517	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-6-prompt-37	6	Mountain Lake Reflection	37	realvisXL	calm alpine mountain lake with mirror reflections, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:52.064479	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-6-prompt-38	6	Mountain Lake Reflection	38	realvisXL	calm alpine mountain lake with mirror reflections, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:52.175536	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-6-prompt-39	6	Mountain Lake Reflection	39	realvisXL	calm alpine mountain lake with mirror reflections, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:52.319992	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-6-prompt-40	6	Mountain Lake Reflection	40	realvisXL	calm alpine mountain lake with mirror reflections, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:52.460512	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-1	7	Cozy Rainy Cafe Window	1	realvisXL	cozy cafe window interior view, rain outside, warm lighting, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:52.603255	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-2	7	Cozy Rainy Cafe Window	2	realvisXL	cozy cafe window interior view, rain outside, warm lighting, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:52.757275	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-3	7	Cozy Rainy Cafe Window	3	realvisXL	cozy cafe window interior view, rain outside, warm lighting, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:52.902282	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-7-prompt-4	7	Cozy Rainy Cafe Window	4	realvisXL	cozy cafe window interior view, rain outside, warm lighting, sunrise	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:53.045096	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-5	7	Cozy Rainy Cafe Window	5	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:53.18712	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-7-prompt-6	7	Cozy Rainy Cafe Window	6	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:53.326492	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-7-prompt-7	7	Cozy Rainy Cafe Window	7	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:53.471989	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-8	7	Cozy Rainy Cafe Window	8	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:53.612202	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-9	7	Cozy Rainy Cafe Window	9	realvisXL	cozy cafe window interior view, rain outside, warm lighting, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:53.754381	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-7-prompt-10	7	Cozy Rainy Cafe Window	10	realvisXL	cozy cafe window interior view, rain outside, warm lighting, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:53.898177	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-11	7	Cozy Rainy Cafe Window	11	realvisXL	cozy cafe window interior view, rain outside, warm lighting, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:54.041496	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-7-prompt-12	7	Cozy Rainy Cafe Window	12	realvisXL	cozy cafe window interior view, rain outside, warm lighting, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:54.195463	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-13	7	Cozy Rainy Cafe Window	13	realvisXL	cozy cafe window interior view, rain outside, warm lighting, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:54.336402	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-14	7	Cozy Rainy Cafe Window	14	realvisXL	cozy cafe window interior view, rain outside, warm lighting, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:54.479889	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-15	7	Cozy Rainy Cafe Window	15	realvisXL	cozy cafe window interior view, rain outside, warm lighting, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:54.623319	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-16	7	Cozy Rainy Cafe Window	16	realvisXL	cozy cafe window interior view, rain outside, warm lighting, glowing	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:54.770217	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-17	7	Cozy Rainy Cafe Window	17	realvisXL	cozy cafe window interior view, rain outside, warm lighting, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:54.912614	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-7-prompt-18	7	Cozy Rainy Cafe Window	18	realvisXL	cozy cafe window interior view, rain outside, warm lighting, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:55.061042	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-19	7	Cozy Rainy Cafe Window	19	realvisXL	cozy cafe window interior view, rain outside, warm lighting, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:55.221281	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-7-prompt-20	7	Cozy Rainy Cafe Window	20	realvisXL	cozy cafe window interior view, rain outside, warm lighting, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:55.361837	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-21	7	Cozy Rainy Cafe Window	21	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:55.504732	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-22	7	Cozy Rainy Cafe Window	22	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:55.646384	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-23	7	Cozy Rainy Cafe Window	23	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:55.796959	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-24	7	Cozy Rainy Cafe Window	24	realvisXL	cozy cafe window interior view, rain outside, warm lighting, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:55.94245	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-7-prompt-25	7	Cozy Rainy Cafe Window	25	realvisXL	cozy cafe window interior view, rain outside, warm lighting, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:56.081999	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-26	7	Cozy Rainy Cafe Window	26	realvisXL	cozy cafe window interior view, rain outside, warm lighting, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:56.232847	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-27	7	Cozy Rainy Cafe Window	27	realvisXL	cozy cafe window interior view, rain outside, warm lighting, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:56.373223	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-7-prompt-28	7	Cozy Rainy Cafe Window	28	realvisXL	cozy cafe window interior view, rain outside, warm lighting, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:56.516948	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-7-prompt-29	7	Cozy Rainy Cafe Window	29	realvisXL	cozy cafe window interior view, rain outside, warm lighting, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:56.661132	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-7-prompt-30	7	Cozy Rainy Cafe Window	30	realvisXL	cozy cafe window interior view, rain outside, warm lighting, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:56.769322	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-31	7	Cozy Rainy Cafe Window	31	realvisXL	cozy cafe window interior view, rain outside, warm lighting, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:56.912719	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-7-prompt-32	7	Cozy Rainy Cafe Window	32	realvisXL	cozy cafe window interior view, rain outside, warm lighting, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:57.057366	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-33	7	Cozy Rainy Cafe Window	33	realvisXL	cozy cafe window interior view, rain outside, warm lighting, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:57.204336	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-7-prompt-34	7	Cozy Rainy Cafe Window	34	realvisXL	cozy cafe window interior view, rain outside, warm lighting, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:57.344299	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-35	7	Cozy Rainy Cafe Window	35	realvisXL	cozy cafe window interior view, rain outside, warm lighting, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:57.489302	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-7-prompt-36	7	Cozy Rainy Cafe Window	36	realvisXL	cozy cafe window interior view, rain outside, warm lighting, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:57.634904	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-7-prompt-37	7	Cozy Rainy Cafe Window	37	realvisXL	cozy cafe window interior view, rain outside, warm lighting,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:57.760366	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-38	7	Cozy Rainy Cafe Window	38	realvisXL	cozy cafe window interior view, rain outside, warm lighting,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:57.902793	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-7-prompt-39	7	Cozy Rainy Cafe Window	39	realvisXL	cozy cafe window interior view, rain outside, warm lighting,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:58.047966	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-7-prompt-40	7	Cozy Rainy Cafe Window	40	realvisXL	cozy cafe window interior view, rain outside, warm lighting,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:58.193074	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-8-prompt-1	8	Lantern Forest Path	1	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:58.333211	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-2	8	Lantern Forest Path	2	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:58.476946	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-8-prompt-3	8	Lantern Forest Path	3	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:58.62002	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-8-prompt-4	8	Lantern Forest Path	4	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:58.763845	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-8-prompt-5	8	Lantern Forest Path	5	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:58.918503	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-8-prompt-6	8	Lantern Forest Path	6	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:59.059313	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-8-prompt-7	8	Lantern Forest Path	7	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:59.201354	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-8-prompt-8	8	Lantern Forest Path	8	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:59.342437	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-8-prompt-9	8	Lantern Forest Path	9	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:59.48716	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-8-prompt-10	8	Lantern Forest Path	10	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:59.628472	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-8-prompt-11	8	Lantern Forest Path	11	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:59.771026	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-8-prompt-12	8	Lantern Forest Path	12	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, after	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:32:59.913098	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-8-prompt-13	8	Lantern Forest Path	13	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:00.058566	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-8-prompt-14	8	Lantern Forest Path	14	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:00.207189	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-15	8	Lantern Forest Path	15	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:00.348976	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-8-prompt-16	8	Lantern Forest Path	16	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:00.498746	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-17	8	Lantern Forest Path	17	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:00.6434	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-8-prompt-18	8	Lantern Forest Path	18	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:00.763131	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-19	8	Lantern Forest Path	19	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:00.908927	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-8-prompt-20	8	Lantern Forest Path	20	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:01.04928	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-21	8	Lantern Forest Path	21	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:01.207737	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-8-prompt-22	8	Lantern Forest Path	22	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:01.350446	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-8-prompt-23	8	Lantern Forest Path	23	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:01.494221	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-8-prompt-24	8	Lantern Forest Path	24	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:01.637248	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-8-prompt-25	8	Lantern Forest Path	25	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:01.773552	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-26	8	Lantern Forest Path	26	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:01.914145	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-8-prompt-27	8	Lantern Forest Path	27	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:02.054203	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-8-prompt-28	8	Lantern Forest Path	28	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, calm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:02.202379	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-8-prompt-29	8	Lantern Forest Path	29	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:02.341847	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-8-prompt-30	8	Lantern Forest Path	30	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:02.489638	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-31	8	Lantern Forest Path	31	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:02.630059	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-8-prompt-32	8	Lantern Forest Path	32	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, warm	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:02.770896	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-8-prompt-33	8	Lantern Forest Path	33	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:02.919908	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-8-prompt-34	8	Lantern Forest Path	34	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:03.061858	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-35	8	Lantern Forest Path	35	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:03.206396	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-8-prompt-36	8	Lantern Forest Path	36	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere, spring	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:03.346324	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-8-prompt-37	8	Lantern Forest Path	37	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:03.492019	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-8-prompt-38	8	Lantern Forest Path	38	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:03.651366	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-8-prompt-39	8	Lantern Forest Path	39	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:03.788784	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-8-prompt-40	8	Lantern Forest Path	40	juggernautXL	forest path lined with glowing lanterns, mystical atmosphere,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:03.93394	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-9-prompt-1	9	Japanese Water Garden	1	juggernautXL	japanese koi pond water garden with wooden bridge, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:04.073844	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-9-prompt-2	9	Japanese Water Garden	2	juggernautXL	japanese koi pond water garden with wooden bridge, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:04.220348	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-9-prompt-3	9	Japanese Water Garden	3	juggernautXL	japanese koi pond water garden with wooden bridge, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:04.361959	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-9-prompt-4	9	Japanese Water Garden	4	juggernautXL	japanese koi pond water garden with wooden bridge, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:04.502288	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-5	9	Japanese Water Garden	5	juggernautXL	japanese koi pond water garden with wooden bridge, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:04.642775	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-9-prompt-6	9	Japanese Water Garden	6	juggernautXL	japanese koi pond water garden with wooden bridge, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:04.794832	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-9-prompt-7	9	Japanese Water Garden	7	juggernautXL	japanese koi pond water garden with wooden bridge, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:04.942908	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-9-prompt-8	9	Japanese Water Garden	8	juggernautXL	japanese koi pond water garden with wooden bridge, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:05.085955	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-9-prompt-9	9	Japanese Water Garden	9	juggernautXL	japanese koi pond water garden with wooden bridge, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:05.232425	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-9-prompt-10	9	Japanese Water Garden	10	juggernautXL	japanese koi pond water garden with wooden bridge, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:05.373385	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-9-prompt-11	9	Japanese Water Garden	11	juggernautXL	japanese koi pond water garden with wooden bridge, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:05.517515	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-12	9	Japanese Water Garden	12	juggernautXL	japanese koi pond water garden with wooden bridge, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:05.699185	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-9-prompt-13	9	Japanese Water Garden	13	juggernautXL	japanese koi pond water garden with wooden bridge, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:05.843291	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-9-prompt-14	9	Japanese Water Garden	14	juggernautXL	japanese koi pond water garden with wooden bridge, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:05.985417	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-9-prompt-15	9	Japanese Water Garden	15	juggernautXL	japanese koi pond water garden with wooden bridge, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:06.127784	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-16	9	Japanese Water Garden	16	juggernautXL	japanese koi pond water garden with wooden bridge, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:06.268615	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-9-prompt-17	9	Japanese Water Garden	17	juggernautXL	japanese koi pond water garden with wooden bridge, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:06.411981	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-18	9	Japanese Water Garden	18	juggernautXL	japanese koi pond water garden with wooden bridge, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:06.558455	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-9-prompt-19	9	Japanese Water Garden	19	juggernautXL	japanese koi pond water garden with wooden bridge, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:06.70679	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-9-prompt-20	9	Japanese Water Garden	20	juggernautXL	japanese koi pond water garden with wooden bridge, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:06.846462	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-9-prompt-21	9	Japanese Water Garden	21	juggernautXL	japanese koi pond water garden with wooden bridge, soft fog,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:06.999725	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-9-prompt-22	9	Japanese Water Garden	22	juggernautXL	japanese koi pond water garden with wooden bridge, soft fog, wide	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:07.151684	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-23	9	Japanese Water Garden	23	juggernautXL	japanese koi pond water garden with wooden bridge, soft fog, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:07.293236	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-9-prompt-24	9	Japanese Water Garden	24	juggernautXL	japanese koi pond water garden with wooden bridge, soft fog,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:07.437702	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-9-prompt-25	9	Japanese Water Garden	25	juggernautXL	japanese koi pond water garden with wooden bridge, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:07.576227	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-26	9	Japanese Water Garden	26	juggernautXL	japanese koi pond water garden with wooden bridge, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:07.720076	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-9-prompt-27	9	Japanese Water Garden	27	juggernautXL	japanese koi pond water garden with wooden bridge, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:07.863285	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-28	9	Japanese Water Garden	28	juggernautXL	japanese koi pond water garden with wooden bridge, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:08.005566	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-9-prompt-29	9	Japanese Water Garden	29	juggernautXL	japanese koi pond water garden with wooden bridge, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:08.148721	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-9-prompt-30	9	Japanese Water Garden	30	juggernautXL	japanese koi pond water garden with wooden bridge, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:08.289605	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-9-prompt-31	9	Japanese Water Garden	31	juggernautXL	japanese koi pond water garden with wooden bridge, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:08.43422	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-9-prompt-32	9	Japanese Water Garden	32	juggernautXL	japanese koi pond water garden with wooden bridge, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:08.57477	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-33	9	Japanese Water Garden	33	juggernautXL	japanese koi pond water garden with wooden bridge, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:08.717246	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-9-prompt-34	9	Japanese Water Garden	34	juggernautXL	japanese koi pond water garden with wooden bridge, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:08.858006	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-9-prompt-35	9	Japanese Water Garden	35	juggernautXL	japanese koi pond water garden with wooden bridge, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:09.000312	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-36	9	Japanese Water Garden	36	juggernautXL	japanese koi pond water garden with wooden bridge, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:09.142417	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-9-prompt-37	9	Japanese Water Garden	37	juggernautXL	japanese koi pond water garden with wooden bridge, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:09.282046	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-9-prompt-38	9	Japanese Water Garden	38	juggernautXL	japanese koi pond water garden with wooden bridge, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:09.422473	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-9-prompt-39	9	Japanese Water Garden	39	juggernautXL	japanese koi pond water garden with wooden bridge, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:09.562794	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-9-prompt-40	9	Japanese Water Garden	40	juggernautXL	japanese koi pond water garden with wooden bridge, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:09.721748	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-1	10	Snowy Zen Garden	1	realvisXL	snow covered zen garden with raked sand and lanterns, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:09.861703	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-2	10	Snowy Zen Garden	2	realvisXL	snow covered zen garden with raked sand and lanterns, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:10.005148	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-3	10	Snowy Zen Garden	3	realvisXL	snow covered zen garden with raked sand and lanterns, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:10.146626	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-10-prompt-4	10	Snowy Zen Garden	4	realvisXL	snow covered zen garden with raked sand and lanterns, sunrise golden	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:10.292382	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-10-prompt-5	10	Snowy Zen Garden	5	realvisXL	snow covered zen garden with raked sand and lanterns, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:10.434642	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-10-prompt-6	10	Snowy Zen Garden	6	realvisXL	snow covered zen garden with raked sand and lanterns, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:10.574613	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-10-prompt-7	10	Snowy Zen Garden	7	realvisXL	snow covered zen garden with raked sand and lanterns, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:10.723382	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-10-prompt-8	10	Snowy Zen Garden	8	realvisXL	snow covered zen garden with raked sand and lanterns, soft morning	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:10.863601	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-9	10	Snowy Zen Garden	9	realvisXL	snow covered zen garden with raked sand and lanterns, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:11.00845	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-10-prompt-10	10	Snowy Zen Garden	10	realvisXL	snow covered zen garden with raked sand and lanterns, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:11.148556	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-11	10	Snowy Zen Garden	11	realvisXL	snow covered zen garden with raked sand and lanterns, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:11.291145	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-10-prompt-12	10	Snowy Zen Garden	12	realvisXL	snow covered zen garden with raked sand and lanterns, after gentle	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:11.442165	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-13	10	Snowy Zen Garden	13	realvisXL	snow covered zen garden with raked sand and lanterns, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:11.581714	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-10-prompt-14	10	Snowy Zen Garden	14	realvisXL	snow covered zen garden with raked sand and lanterns, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:11.729119	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-10-prompt-15	10	Snowy Zen Garden	15	realvisXL	snow covered zen garden with raked sand and lanterns, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:11.87047	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-16	10	Snowy Zen Garden	16	realvisXL	snow covered zen garden with raked sand and lanterns, glowing sunset	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:12.015557	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-10-prompt-17	10	Snowy Zen Garden	17	realvisXL	snow covered zen garden with raked sand and lanterns, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:12.159201	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-18	10	Snowy Zen Garden	18	realvisXL	snow covered zen garden with raked sand and lanterns, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:12.298025	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-10-prompt-19	10	Snowy Zen Garden	19	realvisXL	snow covered zen garden with raked sand and lanterns, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:12.469839	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-20	10	Snowy Zen Garden	20	realvisXL	snow covered zen garden with raked sand and lanterns, golden hour	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:12.612422	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-10-prompt-21	10	Snowy Zen Garden	21	realvisXL	snow covered zen garden with raked sand and lanterns, soft fog,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:12.757234	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-22	10	Snowy Zen Garden	22	realvisXL	snow covered zen garden with raked sand and lanterns, soft fog, wide	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:12.909233	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-23	10	Snowy Zen Garden	23	realvisXL	snow covered zen garden with raked sand and lanterns, soft fog, soft	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:13.051949	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-24	10	Snowy Zen Garden	24	realvisXL	snow covered zen garden with raked sand and lanterns, soft fog,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:13.196399	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-10-prompt-25	10	Snowy Zen Garden	25	realvisXL	snow covered zen garden with raked sand and lanterns, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:13.336358	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-26	10	Snowy Zen Garden	26	realvisXL	snow covered zen garden with raked sand and lanterns, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:13.483336	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-10-prompt-27	10	Snowy Zen Garden	27	realvisXL	snow covered zen garden with raked sand and lanterns, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:13.627799	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-10-prompt-28	10	Snowy Zen Garden	28	realvisXL	snow covered zen garden with raked sand and lanterns, calm peaceful	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:13.771152	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-29	10	Snowy Zen Garden	29	realvisXL	snow covered zen garden with raked sand and lanterns, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:13.914635	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-10-prompt-30	10	Snowy Zen Garden	30	realvisXL	snow covered zen garden with raked sand and lanterns, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:14.054838	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_right	27	\N	0.50	\N	\N
video-10-prompt-31	10	Snowy Zen Garden	31	realvisXL	snow covered zen garden with raked sand and lanterns, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:14.200544	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-10-prompt-32	10	Snowy Zen Garden	32	realvisXL	snow covered zen garden with raked sand and lanterns, warm evening	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:14.342623	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-33	10	Snowy Zen Garden	33	realvisXL	snow covered zen garden with raked sand and lanterns, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:14.487477	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
video-10-prompt-34	10	Snowy Zen Garden	34	realvisXL	snow covered zen garden with raked sand and lanterns, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:14.63835	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-35	10	Snowy Zen Garden	35	realvisXL	snow covered zen garden with raked sand and lanterns, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:14.782131	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-36	10	Snowy Zen Garden	36	realvisXL	snow covered zen garden with raked sand and lanterns, spring breeze,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:14.923451	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_in	27	\N	0.50	\N	\N
video-10-prompt-37	10	Snowy Zen Garden	37	realvisXL	snow covered zen garden with raked sand and lanterns, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:15.069268	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	zoom_out	27	\N	0.50	\N	\N
video-10-prompt-38	10	Snowy Zen Garden	38	realvisXL	snow covered zen garden with raked sand and lanterns, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:15.21442	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_left	27	\N	0.50	\N	\N
video-10-prompt-39	10	Snowy Zen Garden	39	realvisXL	snow covered zen garden with raked sand and lanterns, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:15.357367	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_up	27	\N	0.50	\N	\N
video-10-prompt-40	10	Snowy Zen Garden	40	realvisXL	snow covered zen garden with raked sand and lanterns, twilight sky,	blurry, low quality, distorted, deformed objects, watermark, text	pending	\N	\N	\N	2026-03-17 09:33:15.508249	2026-03-19 22:15:38.304093	\N	DPM++ 2M Karras	30	pan_down	27	\N	0.50	\N	\N
\.


--
-- Data for Name: subagents; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.subagents (run_id, label, task, status, runtime, total_tokens, started_at, completed_at, note) FROM stdin;
mock-1772600098582	Alfred - E2E Testing (task-28)	Second Brain - E2E testing (task-28): Test all commands work correctly	done	~2h	0	2026-03-04 04:54:58-06	2026-03-04 06:42:00-06	Task-28 and parent task-8 marked done by heartbeat - all Second Brain features complete
927e65e4-190c-49c3-b45b-fd25fac0e997	Jeeves - Recurring Events (Retry #2)	Second Brain - Recurring events (task-25): Test & fix existing recurrence implementation	done	330m	0	2026-03-03 23:12:00-06	2026-03-04 04:42:00-06	Task-25 marked done in tasks.json - subagent status synced by heartbeat
8c12ee2f-de9f-48d3-b7a3-bd2b4cc84ac5	Jeeves - Recurring Events	Second Brain - Recurring events (task-25): Implement recurrence patterns	killed	72m	0	2026-03-03 22:00:00-06	2026-03-03 23:12:00-06	\N
22117d4b-b8fb-4707-b785-0792cad2e7c1	Alfred - E2E Testing	Second Brain - E2E testing (task-28): Final comprehensive test	done	9m	1400000	2026-03-03 22:51:00-06	2026-03-03 23:00:00-06	\N
68dd835e-3764-441d-a47a-b1d2a7489f2a	Alfred - Heartbeat Monitoring	Second Brain - Heartbeat monitoring (task-27): Add reminder checks to heartbeat	done	8m	1100000	2026-03-03 22:51:00-06	2026-03-03 22:59:00-06	\N
be0bc7fc-1884-422a-a82a-044ef03fa247	Alfred - E2E Testing	Second Brain - E2E Testing (task-28): Test all commands end-to-end	done	1m	41800	2026-03-03 22:00:00-06	2026-03-03 22:02:00-06	\N
f0539545-4f0b-4b5d-a4be-68df708101d1	Alfred - Event Handler (Retry)	Second Brain - Event Handler (task-24): Handle 'Create event [details]' - RETRY #1	done	4m	488400	2026-03-03 21:32:00-06	2026-03-03 21:36:00-06	\N
b876c551-5d3d-44b2-a729-91ea29ce21d2	Jeeves - Calendar Integration	Second Brain - Calendar integration (task-26): Verify Brain ↔ Calendar	done	7m	978200	2026-03-03 21:28:00-06	2026-03-03 21:36:00-06	\N
95b6067a-a33f-49c6-9a1d-1bd859860b50	Alfred - Event Handler	Second Brain - Event Handler (task-24): Handle 'Create event [details]'	failed	2m	64100	2026-03-03 21:28:00-06	2026-03-03 21:31:00-06	\N
0a480da6-f134-4ef0-b2d6-8b8bb3812602	Alfred - Reminder Handler	Second Brain - Reminder Handler (task-23): Handle 'Remind me to [task] [when]'	done	16m	54062	2026-03-03 20:38:00-06	2026-03-03 20:55:00-06	\N
23e53216-1dd6-447e-8baa-62e35620c9ca	Alfred - Remember Handler	Second Brain - Remember Command Handler (task-21): Handle 'Remember: [URL/content]'	done	5m	34049	2026-03-03 20:38:00-06	2026-03-03 20:52:00-06	\N
758355c6-e9f6-42f1-a28b-dfeaff7ef13d	Jeeves - Keyword Extraction	Second Brain - Keyword Extraction (task-19): Auto-extract 3-5 keywords	done	14m	54253	2026-03-03 20:38:00-06	2026-03-03 20:52:00-06	\N
4b0cd167-d22a-4f76-acaf-acd69ce96d4e	Jeeves - Brain API Endpoints	Create Brain CRUD and search APIs for Brain items	done	8m	28025	2026-03-03 20:14:00-06	2026-03-03 20:28:00-06	\N
9ef07328-2fcb-404f-9ab9-40f0333b8415	Jeeves - Brain Page UI	Building /brain page with saved items list, search, and keyword extraction	done	9m	45773	2026-03-03 19:14:00-06	2026-03-03 19:24:00-06	\N
test-run-456	Test Subagent 2	Task completed	done	\N	\N	2026-03-05 13:08:07.410064-06	2026-03-05 13:08:07.421477-06	\N
bf7296eb-bdff-4f1a-84f3-0c2dd25a95f7	Jeeves - Dad Joke #21 Production with Timing	Task #31: Generate Dad Joke #21 with performance timing	done	0m	0	2026-03-05 07:35:00-06	2026-03-05 13:27:34.374269-06	\N
\.


--
-- Data for Name: task_history; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.task_history (id, task_id, status, "timestamp", note) FROM stdin;
1	task-3	in-progress	2026-03-03 17:08:26.962-06	Status changed to in-progress
2	task-3	done	2026-03-03 18:55:00-06	Heartbeat monitoring implemented and tested - runs every ~30min automatically
3	task-4	in-progress	2026-03-04 08:42:04.063-06	Status changed to in-progress
4	task-4	review	2026-03-04 08:42:05.13-06	Status changed to review
5	task-4	done	2026-03-04 08:42:05.93-06	Status changed to done
6	task-6	in-progress	2026-03-03 16:59:05.837-06	Status changed to in-progress
7	task-6	review	2026-03-03 17:54:57.84-06	Status changed to review
8	task-6	done	2026-03-03 17:54:59.073-06	Status changed to done
9	task-7	in-progress	2026-03-03 13:50:57.782-06	Status changed to in-progress
10	task-7	review	2026-03-03 16:32:40.946-06	Status changed to review
11	task-7	done	2026-03-03 16:32:41.89-06	Status changed to done
12	task-8	done	2026-03-04 06:43:43.536-06	All subtasks completed via individual tasks (task-17 through task-28): Brain UI, API, NLP parser, Remember/Remind/Event handlers, temporal resolver, recurring events, calendar integration, heartbeat monitoring, E2E testing
13	task-15	in-progress	2026-03-03 16:13:05.098-06	Status changed to in-progress
14	task-18	in-progress	2026-03-03 20:14:00-06	Started Brain API implementation
15	task-18	done	2026-03-03 20:28:00-06	✅ All endpoints working: GET (list/limit), POST (create), GET /search (relevance scoring). Auto-metadata updates, type detection, keyword extraction implemented.
16	task-19	done	2026-03-03 20:52:00-06	✅ Enhanced keyword extraction with title boosting, technical term detection, stop word filtering. Created re-extract endpoints (single + bulk). Tested with diverse content.
17	task-21	done	2026-03-03 20:42:00-06	✅ Created remember.js with type detection, auto-keywords, Telegram integration
18	task-23	done	2026-03-03 20:55:00-06	✅ Reminder handler implemented with temporal resolver integration, creates calendar reminders from natural language
19	task-24	in-progress	2026-03-03 21:28:00-06	Auto-assigned by heartbeat - Event handler implementation started
20	task-24	failed	2026-03-03 21:31:00-06	First attempt failed (HTTP 400 - missing context). Retrying with better file references.
21	task-24	done	2026-03-03 21:36:00-06	✅ Event handler created: parses 'Create event [details]', uses temporal resolver, saves to calendar/events.json, returns formatted confirmation
22	task-25	in-progress	2026-03-03 22:00:00-06	Initial implementation started
23	task-25	stuck	2026-03-03 23:12:00-06	Auto-killed after 72 min (>1h). Retry #2 spawned
24	task-25	stuck	2026-03-04 00:45:00-06	Retry #2 killed after 93 min. FINAL attempt spawned
25	task-25	done	2026-03-04 01:12:00-06	✅ VERIFIED via E2E testing (task-28): Recurring events work correctly. 'Weekly standup every Monday at 9am' successfully created with RRULE: FREQ=WEEKLY;BYDAY=MO. Implementation complete despite subagent tooling issues.
26	task-26	in-progress	2026-03-03 21:28:00-06	Auto-assigned by heartbeat - Calendar integration testing started
27	task-26	done	2026-03-03 21:36:00-06	✅ Integration complete: Brain handlers → Calendar API, events/reminders appear in Calendar UI, format normalization for dual format support
28	task-27	in-progress	2026-03-03 22:51:00-06	Auto-assigned by heartbeat - Heartbeat monitoring implementation started
29	task-27	done	2026-03-03 22:59:00-06	✅ Reminder monitoring integrated into heartbeat - checks every 30 min, sends Telegram notifications for due reminders, auto-marks as notified
30	task-28	in-progress	2026-03-03 22:54:58.583-06	Auto-assigned by heartbeat, subagent spawned: mock-1772600098582
31	task-28	done	2026-03-04 05:42:00-06	All Second Brain commands verified: Remember/Remind/Event handlers working, recurring events functional, calendar integration complete, heartbeat monitoring active
32	task-29	in-progress	2026-03-04 08:30:00-06	Started by Kevin via morning briefing interaction
33	task-29	done	2026-03-04 11:57:00-06	✅ Completed: Agent status sync tool, Calendar widget fixes, Brain nav link, Scheduled Jobs section, Mission Control backed up to GitHub
34	task-30	in-progress	2026-03-04 11:57:00-06	Task assigned to Jeeves by Kevin - production automation subagent spawned (c31036f8)
35	task-30	done	2026-03-04 20:02:00-06	✅ Pipeline operational: 512x768@25steps, DPM++ 2M Karras, better prompt engineering, here.now upload working. Jokes #19-20 generated with 100% quality scores.
36	task-31	in-progress	2026-03-05 07:35:00-06	Task created - Jeeves subagent spawned
37	task-31	done	2026-03-05 07:34:23.037-06	✅ Dad Joke #21 complete in 114.40s | Quality: 93/100 | here.now URL ready | MinIO backup complete. Timing instrumentation successful - ready to migrate to PostgreSQL!
183	T-104	status_change	2026-03-18 09:01:27.497041-05	Transition: READY → in-progress
40	task-32	in-progress	2026-03-05 08:54:00-06	PostgreSQL setup started
41	task-32	done	2026-03-05 11:13:08.626-06	✅ PostgreSQL 16.13 installed, mission_control database created, 4 tables + 7 indexes created, npm pg installed, db.ts module created, .env.local updated. Ready for data migration!
42	task-35	in-progress	2026-03-05 09:30:01.405-06	Auto-assigned by heartbeat, subagent spawned: mock-1772724601405
43	task-36	testing	2026-03-05 13:52:06.381011-06	Concurrent write test 4 - 13:52:06
44	task-36	testing	2026-03-05 13:52:06.383469-06	Concurrent write test 2 - 13:52:06
45	task-36	testing	2026-03-05 13:52:06.389775-06	Concurrent write test 1 - 13:52:06
46	task-36	testing	2026-03-05 13:52:06.39089-06	Concurrent write test 3 - 13:52:06
47	task-36	testing	2026-03-05 13:52:06.400887-06	Concurrent write test 5 - 13:52:06
52	T-101	created	2026-03-12 14:58:39.023663-05	Task created: ID=T-101, Title=Test Workflow Validation, Column=READY, Agent=TestRunner
53	T-101	status_change	2026-03-12 14:58:48.101551-05	Transition: READY → IN_PROGRESS
54	T-101	status_change	2026-03-12 14:58:48.108294-05	Transition: IN_PROGRESS → VALIDATION
55	T-101	status_change	2026-03-12 14:58:52.261136-05	Transition: VALIDATION → DONE
56	T-101	status_change	2026-03-12 14:59:15.729228-05	Transition: DONE → VALIDATION
57	T-101	status_change	2026-03-12 14:59:15.8257-05	Transition: VALIDATION → DONE
58	T-101	validated	2026-03-12 14:59:15.865838-05	Validation by validation-agent: Status=PASS | All validation criteria passed | Issues: 0
59	T-102	created	2026-03-12 16:22:31.853087-05	Task created: ID=T-102, Title=Dad Joke #25 Video Generation, Column=READY, Agent=DadJ
60	task-72	DONE	2026-03-13 00:03:18.542852-05	Fixed PATH issue in backup script - mc now found, backup verified
61	T-102	status_change	2026-03-13 03:31:58.824321-05	Transition: READY → IN_PROGRESS
62	T-102	status_change	2026-03-13 09:49:25.518327-05	Transition: IN_PROGRESS → READY
63	task-24	complete	2026-03-13 09:49:25.606484-05	YouTube uploaded (private), MinIO backed up
64	T-102	status_change	2026-03-13 10:51:10.075319-05	Transition: READY → in-progress
65	T-102	status_change	2026-03-13 15:55:28.708879-05	Transition: in-progress → done
66	task-opt-01	created	2026-03-13 20:19:47.834206-05	Task created: ID=task-opt-01, Title=Fix Gateway Stability - Discord disconnects, Column=backlog, Agent=alfred
67	task-opt-02	created	2026-03-13 20:19:47.834206-05	Task created: ID=task-opt-02, Title=Memory Deduplication, Column=backlog, Agent=alfred
68	task-opt-03	created	2026-03-13 20:19:47.834206-05	Task created: ID=task-opt-03, Title=Subagent Model Routing, Column=backlog, Agent=alfred
69	task-opt-04	created	2026-03-13 20:19:47.834206-05	Task created: ID=task-opt-04, Title=Heartbeat Batching Optimization, Column=backlog, Agent=healthmon
70	task-opt-05	created	2026-03-13 20:19:47.834206-05	Task created: ID=task-opt-05, Title=Error Log Auto-Cleanup, Column=backlog, Agent=healthmon
71	task-opt-06	created	2026-03-13 20:19:47.834206-05	Task created: ID=task-opt-06, Title=Alfred Hub Real-Time Sync, Column=backlog, Agent=alfred
275	task-opt-06	status_change	2026-03-21 06:17:17.718166-05	Transition: backlog → in-progress
276	task-opt-06	status_change	2026-03-21 06:18:09.020357-05	Transition: in-progress → done
277	T-102	status_change	2026-04-14 18:42:25.138614-05	Transition: done → archived
278	task-opt-06	status_change	2026-04-14 18:42:25.138614-05	Transition: done → archived
279	task-1	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
280	task-4	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
281	task-opt-01	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
282	task-opt-03	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
283	task-opt-02	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
284	T-103	status_change	2026-04-14 18:42:25.138614-05	Transition: done → archived
285	task-qmd-001	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
286	task-33	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
287	task-36	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
288	task-57	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
289	T-105	status_change	2026-04-14 18:42:25.138614-05	Transition: done → archived
290	T-101	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
291	task-brief-001	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
292	dadjoke-17-start	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
91	task-qmd-001	created	2026-03-15 20:26:05.34856-05	Task created: ID=task-qmd-001, Title=Install QMD Memory Backend, Column=DONE, Agent=alfred
92	task-brief-001	created	2026-03-15 20:26:05.415474-05	Task created: ID=task-brief-001, Title=Fix Morning/Evening Briefing Delivery, Column=DONE, Agent=alfred
93	task-cron-001	created	2026-03-15 20:26:05.471718-05	Task created: ID=task-cron-001, Title=Clean Up Cron & Add Task Notifications, Column=DONE, Agent=alfred
293	task-58	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
294	task-72-2	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
295	task-35	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
97	task-opt-01	status_change	2026-03-15 21:47:45.077485-05	Transition: backlog → READY
98	task-opt-01	status_change	2026-03-15 22:01:56.39259-05	Transition: READY → DONE
99	task-opt-03	status_change	2026-03-15 22:01:56.479906-05	Transition: backlog → DONE
100	task-opt-02	status_change	2026-03-15 22:01:56.534579-05	Transition: backlog → DONE
296	task-1772832952	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
297	task-72-1	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
298	dadjoke-13	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
299	task-67	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
300	dadjoke-14	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
301	dadjoke-15	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
302	task-66	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
303	task-cron-001	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
304	task-3	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
305	task-5	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
306	task-6	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
307	task-7	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
308	task-8	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
309	task-16	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
310	task-9	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
311	task-10	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
312	task-11	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
313	task-12	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
314	task-13	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
315	task-14	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
316	task-15	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
317	task-17	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
318	task-18	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
319	task-19	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
320	task-20	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
180	T-103	created	2026-03-18 09:01:17.269509-05	Task created: ID=T-103, Title=Google Calendar API integration, Column=READY, Agent=alfred
181	T-104	created	2026-03-18 09:01:20.438729-05	Task created: ID=T-104, Title=Natural language reminder parser, Column=READY, Agent=alfred
182	T-105	created	2026-03-18 09:01:24.672591-05	Task created: ID=T-105, Title=Mission Control Calendar page update, Column=READY, Agent=alfred
184	T-104	status_change	2026-03-18 09:01:59.709199-05	Transition: in-progress → done
185	T-103	status_change	2026-03-18 09:01:59.712512-05	Transition: READY → in-progress
186	T-103	status_change	2026-03-18 09:02:14.319433-05	Transition: in-progress → done
187	T-105	status_change	2026-03-18 09:02:14.332942-05	Transition: READY → in-progress
188	T-105	status_change	2026-03-18 09:02:36.653325-05	Transition: in-progress → done
321	task-21	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
322	task-22	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
323	task-23	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
324	task-24	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
325	task-25	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
326	task-26	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
327	task-27	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
328	task-28	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
329	task-29	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
330	task-30	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
331	task-31	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
332	task-32	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
333	task-70-6	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
334	task-34	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
335	task-40	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
336	task-37	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
337	task-38	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
338	task-39	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
339	task-41	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
340	task-43	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
341	task-45	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
342	task-49	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
343	task-44	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
344	task-47	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
345	task-46	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
346	task-48	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
347	task-50	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
348	task-51	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
349	task-52	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
350	task-53	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
351	task-54	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
352	task-55	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
353	task-68	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
354	dadjoke-16	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
355	dadjoke-17	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
356	task-42	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
357	task-70	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
358	task-70-1	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
359	task-59	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
360	task-56	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
361	task-70-2	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
362	task-69	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
363	task-72-3	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
364	task-72-4	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
365	task-72-5	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
366	task-71	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
367	task-72	status_change	2026-04-14 18:42:25.138614-05	Transition: DONE → archived
368	T-104	status_change	2026-04-14 18:42:25.138614-05	Transition: done → archived
369	mc-01	created	2026-04-14 18:42:46.546338-05	Task created: ID=mc-01, Title=Fix agent status updates in heartbeat, Column=in-progress, Agent=alfred
370	mc-02	created	2026-04-14 18:42:46.546338-05	Task created: ID=mc-02, Title=Add Plex activity dashboard widget, Column=backlog, Agent=alfred
371	mc-03	created	2026-04-14 18:42:46.546338-05	Task created: ID=mc-03, Title=Add real-time push updates via websocket, Column=backlog, Agent=alfred
372	mc-04	created	2026-04-14 18:42:46.546338-05	Task created: ID=mc-04, Title=Add activity feed timeline, Column=backlog, Agent=alfred
373	mc-05	created	2026-04-14 18:42:46.546338-05	Task created: ID=mc-05, Title=Clean up and refresh MC stale data, Column=done, Agent=alfred
374	mc-01	status_change	2026-04-14 18:54:00.083505-05	Transition: in-progress → done
375	mc-02	status_change	2026-04-14 18:54:00.083505-05	Transition: backlog → in-progress
376	mc-02	status_change	2026-04-14 19:52:35.881969-05	Transition: in-progress → done
377	mc-03	status_change	2026-04-14 19:52:35.881969-05	Transition: backlog → done
378	mc-04	status_change	2026-04-14 19:52:35.881969-05	Transition: backlog → in-progress
379	mc-04	status_change	2026-04-14 19:59:15.05837-05	Transition: in-progress → done
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: alfred
--

COPY public.tasks (id, title, column_name, assignee, priority, description, parent_task_id, linked_subagent, created_at, started_at, completed_at, updated_at, deliverables, validation_criteria) FROM stdin;
mc-01	Fix agent status updates in heartbeat	done	alfred	high	Heartbeat runner writes agent status to PostgreSQL every cycle	\N	\N	2026-04-14 18:42:46.546338-05	\N	2026-04-14 18:54:00.083505-05	2026-04-14 18:42:46.546338-05	Updated heartbeat-runner.js with agent status write-back	\N
mc-02	Add Plex activity dashboard widget	done	alfred	high	New MC page showing Plex activity	\N	\N	2026-04-14 18:42:46.546338-05	\N	2026-04-14 19:52:35.881969-05	2026-04-14 19:30:11.80052-05	New /plex page with currently watching, recent watches, top shows, user activity	\N
task-opt-04	Heartbeat Batching Optimization	backlog	healthmon	medium	Cache results, run expensive checks less frequently, skip redundant checks.	\N	\N	2026-03-13 20:19:47.834206-05	\N	\N	2026-03-13 20:19:47.834206-05	1. Caching implemented 2. Optimized heartbeat runner	\N
task-opt-05	Error Log Auto-Cleanup	backlog	healthmon	low	Auto-archive entries >30 days, dedupe repeated errors, add metrics widget.	\N	\N	2026-03-13 20:19:47.834206-05	\N	\N	2026-03-13 20:19:47.834206-05	1. Auto-archive cron 2. Metrics widget	\N
T-102	Dad Joke #25 Video Generation	archived	jeeves	medium	Task ID: T-102\n\nTitle: Dad Joke #25 Video Generation\n\nDescription: Daily automated dad joke pipeline\n\nDeliverables: Video MP4 rendered, uploaded to MinIO hp1/dadj/25/, Dadabase Used=TRUE, approval sent to Kevin via Telegram\n\nAssigned Agent: DadJ\n\nStatus: READY\n\nValidation Criteria:\n- --criteria\n- Video renders without errors\n- --criteria\n- Text displays correctly (Georgia serif font)\n- --criteria\n- Audio padded with 1s start/end buffers\n- --criteria\n- Background generated by Stable Diffusion (no text)\n- --criteria\n- All assets uploaded to MinIO: hp1/dadj/25/\n- --criteria\n- Dadbabase row C26 marked Used=TRUE\n- --criteria\n- Approval message sent to telegram:8177470832 with video attached	\N	\N	2026-03-12 16:22:31.853087-05	2026-03-13 10:51:10.075319-05	\N	2026-03-13 15:55:28.708879-05	Video MP4 rendered, uploaded to MinIO hp1/dadj/25/, Dadabase Used=TRUE, approval sent to Kevin via Telegram	{--criteria,"Video renders without errors",--criteria,"Text displays correctly (Georgia serif font)",--criteria,"Audio padded with 1s start/end buffers",--criteria,"Background generated by Stable Diffusion (no text)",--criteria,"All assets uploaded to MinIO: hp1/dadj/25/",--criteria,"Dadbabase row C26 marked Used=TRUE",--criteria,"Approval message sent to telegram:8177470832 with video attached"}
task-opt-06	Alfred Hub Real-Time Sync	archived	alfred	low	Add WebSocket live updates, agent activity heatmap, task velocity.	\N	\N	2026-03-13 20:19:47.834206-05	\N	2026-03-21 06:18:09.020357-05	2026-03-21 06:18:09.020357-05	1. WebSocket integration 2. Dashboard updates	\N
task-1	Set up Kanban board	archived	alfred	high	Create the Kanban-style Tasks page with all columns and features	\N	\N	2026-03-03 10:00:00-06	\N	\N	2026-03-05 11:37:22.461-06	\N	\N
task-4	Design system improvements	archived	kevin	low	Review and improve the Mission Control design system	\N	\N	2026-03-03 10:15:00-06	\N	\N	2026-03-05 11:37:22.468-06	\N	\N
mc-05	Clean up and refresh MC stale data	done	alfred	high	Archive done tasks, update statuses	\N	\N	2026-04-14 18:42:46.546338-05	\N	2026-04-14 18:54:00.083505-05	2026-04-14 18:42:46.546338-05	Archived tasks, updated agent table	\N
task-opt-01	Fix Gateway Stability - Discord disconnects	archived	alfred	critical	Discord gateway stability investigated - no recent disconnects, gateway running stable, Discord token valid. Issue appears resolved.	\N	\N	2026-03-13 20:19:47.834206-05	\N	\N	2026-03-15 22:01:56.39259-05	Checked gateway status, Discord config, error logs - no issues found	\N
mc-04	Add activity feed timeline	done	alfred	medium	Daily activity timeline	\N	\N	2026-04-14 18:42:46.546338-05	\N	2026-04-14 19:59:15.05837-05	2026-04-14 18:42:46.546338-05	Activity feed component showing today's events	\N
task-opt-03	Subagent Model Routing	archived	alfred	high	Superseded by cloud-only model architecture (March 2026)	\N	\N	2026-03-13 20:19:47.834206-05	\N	\N	2026-03-15 22:01:56.479906-05	1. Model routing helper function 2. Updated spawn calls	\N
task-opt-02	Memory Deduplication	archived	alfred	high	QMD now handles memory indexing	\N	\N	2026-03-13 20:19:47.834206-05	\N	\N	2026-03-15 22:01:56.534579-05	1. Deduped memories 2. Embedding verified 3. Compaction script	\N
T-103	Google Calendar API integration	archived	alfred	medium	Task ID: T-103\n\nTitle: Google Calendar API integration\n\nDescription: Sync PostgreSQL reminders to Google Calendar for native notification delivery\n\nDeliverables: Working GCal event creation with reminders\n\nAssigned Agent: alfred\n\nStatus: READY\n\nValidation Criteria:\n- OAuth configured\n- Events created\n- Reminders set	\N	\N	2026-03-18 09:01:17.269509-05	2026-03-18 09:01:59.712512-05	2026-03-18 09:02:14.319433-05	2026-03-18 09:01:17.269509-05	Working GCal event creation with reminders	{"OAuth configured","Events created","Reminders set"}
task-qmd-001	Install QMD Memory Backend	archived	alfred	high	Replace broken mem0 with QMD (BM25 + vector + reranking) for memory search.	\N	\N	2026-03-15 20:26:05.34856-05	\N	\N	2026-03-15 20:26:05.34856-05	QMD CLI installed, 14 memory files indexed, OpenClaw config updated, hybrid search tested	\N
task-33	Migrate Kanban Data to PostgreSQL	archived	jeeves	high	Migrate tasks.json → tasks + task_history tables, subagents.json → subagents table, agent-status.json → agents table. Verify data integrity with row counts.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 11:30:00-06	2026-03-05 13:51:42.756204-06	\N	\N
task-36	Test Concurrent PostgreSQL Operations	archived	alfred	critical	Spawn multiple subagents simultaneously to test concurrent writes. Verify no race conditions, deadlocks, or data corruption. Stress test the new system.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-09 19:45:42.937752-05	2026-03-09 19:45:42.937752-05	\N	\N
task-57	Create GitHub repo russelopenclaw/DinnerRouletteWeb	archived	alfred	high	Initialize new repository for Vercel-deployable web version. [ARCHIVED - Vercel deployment not needed, using ddns.net port forwarding]	\N	\N	2026-03-06 09:26:18.179053-06	\N	2026-03-06 10:29:01.860165-06	2026-03-12 13:49:50.163107-05	\N	\N
T-105	Mission Control Calendar page update	archived	alfred	medium	Task ID: T-105\n\nTitle: Mission Control Calendar page update\n\nDescription: Update Mission Control Calendar page to show reminders from PostgreSQL alongside GCal events\n\nDeliverables: Calendar page displays PostgreSQL reminders\n\nAssigned Agent: alfred\n\nStatus: READY\n\nValidation Criteria:\n- Reminders visible\n- Sync with GCal	\N	\N	2026-03-18 09:01:24.672591-05	2026-03-18 09:02:14.332942-05	2026-03-18 09:02:36.653325-05	2026-03-18 09:01:24.672591-05	Calendar page displays PostgreSQL reminders	{"Reminders visible","Sync with GCal"}
task-3	Add heartbeat task monitoring	archived	alfred	medium	Monitor for new tasks assigned to Alfred during heartbeat checks	\N	\N	2026-03-03 10:10:00-06	\N	2026-03-03 18:55:00-06	2026-03-05 11:37:22.463-06	\N	\N
task-5	Test drag-and-drop functionality	archived	jeeves	medium	Thoroughly test moving tasks between columns	\N	\N	2026-03-03 10:20:00-06	\N	\N	2026-03-05 11:37:22.472-06	\N	\N
task-6	Optimize memory processes	archived	kevin	medium	Discuss and implement strategies to optimize Alfred's memory system - daily capture, long-term curation, mem0 integration, search improvements, and retention policies	\N	\N	2026-03-03 10:45:00-06	\N	\N	2026-03-05 11:37:22.473-06	\N	\N
task-7	Design Calendar system	archived	kevin	high	Design and implement a Calendar system to track scheduled tasks/cron jobs and personal events, reminders, etc. Integrate with Google Calendar and local task scheduling.	\N	\N	2026-03-03 10:49:00-06	\N	\N	2026-03-05 11:37:22.477-06	\N	\N
task-8	Second Brain system	archived	alfred	high	Build a personal assistant-style knowledge management system with 'Remember:', 'Remind me...', and 'Create event...' commands. Includes Brain page, natural language parsing, calendar integration, and intelligent reminders.	\N	\N	2026-03-03 10:53:00-06	\N	2026-03-04 06:43:43.536-06	2026-03-05 11:37:22.48-06	\N	\N
task-16	Memory optimization implementation	archived	alfred	high	Implement Phase 1 & 2 memory optimizations: hybrid search, MMR, temporal decay, mem0 integration	\N	\N	2026-03-03 17:28:00-06	\N	2026-03-03 17:50:00-06	2026-03-05 11:37:22.481-06	\N	\N
task-9	Create calendar data structure and API endpoints	archived	jeeves	high	Build APIs for 5-day view, monthly view, events CRUD, and reminders. Data files: events.json, reminders.json	\N	8cdb3456-199f-4bc5-afad-213faf33ea8c	2026-03-03 14:01:00-06	\N	2026-03-03 14:47:00-06	2026-03-05 11:37:22.482-06	\N	\N
task-10	Integrate status hooks into OpenClaw config	archived	jeeves-2	high	Create openclaw-hooks.js and register in OpenClaw config for automatic status updates on messages, subagent events, and heartbeat	\N	e09d17aa-41e7-4f4f-b7a6-1b434507a4a8	2026-03-03 14:21:00-06	\N	2026-03-03 14:49:00-06	2026-03-05 11:37:22.483-06	\N	\N
task-11	Build 5-day rolling view (top section)	archived	jeeves	high	Create FiveDayView component showing today + 4 days with all events, reminders, and cron jobs	\N	\N	2026-03-03 14:25:00-06	2026-03-03 15:38:00-06	2026-03-03 15:46:37-06	2026-03-05 11:37:22.484-06	\N	\N
task-12	Build traditional monthly calendar view (bottom section)	archived	jeeves	high	Create MonthlyView component with 5-week grid, event dots, and click-to-expand day details	\N	\N	2026-03-03 14:25:00-06	2026-03-03 16:00:00-06	2026-03-03 16:02:15-06	2026-03-05 11:37:22.484-06	\N	\N
task-13	Add fixed Agent Activity sidebar (right side)	archived	jeeves	medium	Reuse LiveActivitySidebar from Tasks page, fix to right side of Calendar page, poll every 10s	\N	\N	2026-03-03 14:25:00-06	2026-03-03 16:09:00-06	2026-03-03 16:11:30-06	2026-03-05 11:37:22.485-06	\N	\N
T-101	Test Workflow Validation	archived	TestRunner	high	Task ID: T-101\n\nTitle: Test Workflow Validation\n\nDescription: Testing the full workflow: READY → IN_PROGRESS → VALIDATION → DONE\n\nDeliverables: Completed unit test suite\n\nAssigned Agent: TestRunner\n\nStatus: READY\n\nValidation Criteria:\n- All tests pass\n- Code coverage >80%\n- No lint errors	\N	\N	2026-03-12 14:58:39.023663-05	2026-03-12 14:58:48.101551-05	2026-03-12 14:59:15.8257-05	2026-03-12 14:59:15.8257-05	Completed unit test suite	{"All tests pass","Code coverage >80%","No lint errors"}
task-brief-001	Fix Morning/Evening Briefing Delivery	archived	alfred	high	Fixed briefing scripts to send directly to Telegram API instead of just queueing.	\N	\N	2026-03-15 20:26:05.415474-05	\N	\N	2026-03-15 20:26:05.415474-05	morning-briefing.js sends to Telegram, send-briefing.js uses openclaw.json for bot token, tested successfully	\N
dadjoke-17-start	Start Dad Joke Video #17	archived	alfred	medium	Generate dad joke video #17	\N	agent:main:subagent:0b13f857-3713-4135-a93b-c86af9be1b20	2026-03-10 18:06:45.936843-05	2026-03-10 18:28:30.269915-05	\N	2026-03-10 18:38:46.536129-05	\N	\N
task-58	Document Vercel setup process for Kevin	archived	alfred	medium	Create step-by-step guide for Kevin to set up Vercel account and connect to repo. [ARCHIVED - Vercel deployment not needed, using ddns.net port forwarding]	\N	\N	2026-03-06 09:26:18.179053-06	\N	2026-03-06 10:29:01.860165-06	2026-03-12 13:49:50.163107-05	\N	\N
task-72-2	Test MinIO upload integration	archived	alfred	high	Verify mc cp command uploads to hp1/dadjokes/backup/ bucket	\N	\N	2026-03-11 14:51:00.78086-05	2026-03-11 14:52:12.030962-05	2026-03-11 14:52:28.803436-05	2026-03-11 14:52:28.803436-05	\N	\N
task-35	Update Agent Hooks to Write to PostgreSQL	archived	alfred	high	Update tools/agent-status-hook.js and openclaw-hooks.js to write to PostgreSQL. Test concurrent writes from multiple subagents.	\N	mock-1772724601405	2026-03-05 08:51:23.507-06	2026-03-05 09:30:01.405-06	2026-03-05 13:08:39.067018-06	2026-03-05 13:08:39.067018-06	\N	\N
task-1772832952	HTTPS SSL Certificate Setup	archived	alfred	high	Configure Caddy reverse proxy with TLS for Mission Control	\N	\N	2026-03-06 15:35:52.726358-06	2026-03-06 15:35:52.726358-06	2026-03-06 15:36:44.469969-06	2026-03-06 15:36:44.469969-06	\N	\N
task-72-1	Create backup script with pg_dump	archived	alfred	high	Write bash script using pg_dump to export mission_control database	\N	\N	2026-03-11 14:51:00.78086-05	2026-03-11 14:51:37.280694-05	2026-03-11 15:24:30.538179-05	2026-03-11 15:24:30.538179-05	\N	\N
dadjoke-13	Create Dad Joke Video #13	archived	alfred	medium	Regenerating audio with full joke text + pause, correct background image, and proper text. Issues: 1) AI-generated human face, 2) No pause in audio, 3) Used wrong joke text	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-09 14:50:03.302149-05	2026-03-09 17:19:21.879242-05	2026-03-09 17:19:21.879242-05	\N	\N
task-67	PostgreSQL Auto-Backup	archived	\N	high	Nightly backup of mission_control database to MinIO with 30-day retention. Impact: Disaster recovery. Effort: 1 hour	\N	\N	2026-03-11 14:23:41.821998-05	\N	2026-03-11 15:34:39.931044-05	2026-03-11 15:34:39.931044-05	\N	\N
dadjoke-14	Create Dad Joke Video #14	archived	alfred	medium	I went on a date with a girl from the zoo. She's a keeper.	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-09 17:33:44.912269-05	2026-03-09 18:25:52.716176-05	2026-03-09 18:25:52.716176-05	\N	\N
dadjoke-15	Create Dad Joke Video #15	archived	alfred	medium	I'm so good at sleeping I can do it with my eyes closed!	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-09 22:25:31.185206-05	\N	2026-03-10 15:07:05.95915-05	\N	\N
task-66	Smart Morning Briefing Automation	archived	\N	high	Send briefings automatically at 8 AM via cron job. Impact: More reliable, one less thing to think about. Effort: 30 min	\N	\N	2026-03-11 14:23:41.820607-05	2026-03-11 15:34:39.931044-05	2026-03-11 15:35:33.967201-05	2026-03-11 15:35:33.967201-05	\N	\N
task-14	Integrate heartbeat for event/reminder checks	archived	alfred	medium	Add calendar/reminder checks to HEARTBEAT.md, notify Kevin of upcoming events	\N	\N	2026-03-03 14:25:00-06	2026-03-03 16:32:00-06	2026-03-03 16:33:00-06	2026-03-05 11:37:22.486-06	\N	\N
task-15	Filter Home page Task Management to show only In Progress tasks	archived	jeeves	low	Update DashboardStats and TaskManager widgets on Home page to only display tasks with column='in-progress'. Add toggle or filter option to view all tasks if needed. This keeps the main dashboard clean and focused on active work.	\N	\N	2026-03-03 14:31:00-06	\N	\N	2026-03-05 11:37:22.487-06	\N	\N
task-17	Second Brain: Brain page UI	archived	jeeves	high	Create /brain page with saved items list and search - 9 min	\N	\N	2026-03-03 19:14:00-06	\N	2026-03-03 19:24:00-06	2026-03-05 11:37:22.488-06	\N	\N
task-18	Second Brain: Brain API endpoints	archived	jeeves	high	Create CRUD and search APIs for Brain items (re-spawned at 8:14 PM)	\N	\N	2026-03-03 19:24:00-06	2026-03-03 20:14:00-06	2026-03-03 20:28:00-06	2026-03-05 11:37:22.489-06	\N	\N
task-19	Second Brain: Keyword extraction	archived	jeeves	medium	Auto-extract 3-5 keywords from saved URLs and notes	\N	758355c6-e9f6-42f1-a28b-dfeaff7ef13d	2026-03-03 19:24:00-06	2026-03-03 20:38:00-06	2026-03-03 20:52:00-06	2026-03-05 11:37:22.492-06	\N	\N
task-cron-001	Clean Up Cron & Add Task Notifications	archived	alfred	medium	Removed duplicate 8AM briefing cron, updated dad joke to n8n pipeline, created task notification utility.	\N	\N	2026-03-15 20:26:05.471718-05	\N	\N	2026-03-15 20:26:05.471718-05	7 clean cron entries, tools/task-notify.js sends Telegram notifications	\N
task-20	Second Brain: NLP Parser	archived	alfred	high	Natural language parser for Remember/Remind/Event commands	\N	\N	2026-03-03 19:19:00-06	\N	2026-03-03 19:24:00-06	2026-03-05 11:37:22.493-06	\N	\N
task-21	Second Brain: Remember handler	archived	alfred	high	Handle 'Remember: [URL/content]' - saves to Brain	\N	23e53216-1dd6-447e-8baa-62e35620c9ca	2026-03-03 19:24:00-06	2026-03-03 20:38:00-06	2026-03-03 20:42:00-06	2026-03-05 11:37:22.494-06	\N	\N
task-22	Second Brain: Temporal resolver	archived	alfred	high	Parse time expressions: 'this afternoon'→3PM, 'tomorrow morning'→9AM	\N	\N	2026-03-03 19:24:00-06	\N	2026-03-03 19:29:00-06	2026-03-05 11:37:22.496-06	\N	\N
task-23	Second Brain: Reminder handler	archived	alfred	high	Handle 'Remind me to [task] [when]' - creates calendar reminders	\N	0a480da6-f134-4ef0-b2d6-8b8bb3812602	2026-03-03 19:24:00-06	2026-03-03 20:38:00-06	2026-03-03 20:55:00-06	2026-03-05 11:37:22.497-06	\N	\N
task-24	Second Brain: Event handler	archived	alfred	high	Handle 'Create event [details]' - adds to calendar	\N	f0539545-4f0b-4b5d-a4be-68df708101d1	2026-03-03 19:24:00-06	2026-03-03 21:28:00-06	2026-03-03 21:36:00-06	2026-03-05 11:37:22.499-06	\N	\N
task-25	Second Brain: Recurring events	archived	jeeves	medium	Support 'Every Monday at 9am' recurring patterns	\N	\N	2026-03-03 19:24:00-06	2026-03-04 00:45:00-06	2026-03-04 01:12:00-06	2026-03-05 11:37:22.502-06	\N	\N
task-26	Second Brain: Calendar integration	archived	jeeves	medium	Integrate with calendar/events.json and reminders.json	\N	b876c551-5d3d-44b2-a729-91ea29ce21d2	2026-03-03 19:24:00-06	2026-03-03 21:28:00-06	2026-03-03 21:36:00-06	2026-03-05 11:37:22.507-06	\N	\N
task-27	Second Brain: Heartbeat monitoring	archived	alfred	medium	Add reminder checks to heartbeat for due notifications	\N	68dd835e-3764-441d-a47a-b1d2a7489f2a	2026-03-03 19:24:00-06	2026-03-03 22:51:00-06	2026-03-03 22:59:00-06	2026-03-05 11:37:22.509-06	\N	\N
task-28	Second Brain: E2E testing	archived	alfred	high	Test all Second Brain commands work correctly	\N	mock-1772600098582	2026-03-03 19:24:00-06	2026-03-03 22:54:58.582-06	2026-03-04 05:42:00-06	2026-03-05 11:37:22.512-06	\N	\N
task-29	Enhance proactive automation	archived	alfred	high	Add automatic dependency resolution, smart prioritization, and interactive briefing features to reduce manual task assignment and improve agent autonomy	\N	\N	2026-03-04 08:30:00-06	2026-03-04 08:30:00-06	2026-03-04 17:57:00-06	2026-03-05 11:37:22.514-06	\N	\N
task-30	Automate Dad Joke Video creation end-to-end	archived	jeeves	high	Create fully automated video generation pipeline: analyze generated image, generate audio once, analyze final video to confirm text is correct, timing is right, and production-ready without manual intervention	\N	c31036f8-e4bd-4e8b-861e-50f0774d5adf	2026-03-04 11:57:00-06	2026-03-04 17:57:00-06	2026-03-04 20:02:00-06	2026-03-05 11:37:22.517-06	\N	\N
task-31	Generate Dad Joke #21 with performance timing	archived	jeeves	high	Run the production pipeline for joke #21 with enhanced timing instrumentation. Track: joke fetch, audio generation, format detection, image prompt, image generation, video render, quality verification, Sheets update, here.now upload, MinIO backup. Save timing report to output folder.	\N	bf7296eb-bdff-4f1a-84f3-0c2dd25a95f7	2026-03-05 07:35:00-06	2026-03-05 07:35:00-06	2026-03-05 07:34:23.037-06	2026-03-05 11:37:22.521-06	\N	\N
task-32	PostgreSQL Setup and Schema Creation	archived	jeeves	high	Install PostgreSQL 16, create mission_control database, run schema scripts for agents, tasks, subagents, and task_history tables. Verify connection and permissions.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 11:13:08.626-06	2026-03-05 11:37:22.528-06	\N	\N
task-70-6	Mobile-responsive layouts	archived	alfred	medium	Adapt desktop dashboard for phone screens, test on emulator. 2 hours. [ARCHIVED - Mobile app scope changed]	\N	\N	2026-03-11 16:44:27.949211-05	\N	\N	2026-03-12 13:49:50.105975-05	\N	\N
task-34	Update Mission Control API Endpoints for PostgreSQL	archived	jeeves	high	Update /api/tasks, /api/status, /api/subagents routes to use PostgreSQL instead of JSON files. Add connection pooling, prepared statements, error handling.	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 11:30:00-06	2026-03-05 13:51:42.756204-06	\N	\N
task-40	Telegram Command: /status - Quick system status check	archived	alfred	high	Add Telegram command handler for /status. Reply with: Tasks in progress, agent status (working/idle), recent completions (last 24h), system health (ollama/gateway/disk). No dashboard needed.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 13:52:11.616758-06	2026-03-05 14:57:15.984617-06	2026-03-05 14:57:15.984617-06	\N	\N
task-37	Remove Old JSON Files and Finalize Migration	archived	jeeves	high	Backup old JSON files, remove from active use. Update documentation. Verify dashboard still works. Celebrate! 🎉	\N	\N	2026-03-05 08:51:23.507-06	\N	2026-03-05 15:03:23.002872-06	2026-03-05 15:03:23.002872-06	\N	\N
task-38	Error Log Cleanup - Review and close resolved errors	archived	alfred	medium	Review 14 errors in .learnings/ERRORS.md, categorize, close resolved ones (especially JSON corruption errors from migration). Set up better error logging/monitoring for future.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 15:04:16.196395-06	2026-03-05 15:06:39.952572-06	2026-03-05 15:06:39.952572-06	\N	\N
task-39	Dashboard Enhancement: PostgreSQL Migration Progress Widget	archived	jeeves	medium	Add migration progress bar to Mission Control home page. Show: Phase X of Y complete, tables migrated, data integrity check %, time remaining. Real-time updates during migration.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 15:04:42.297896-06	2026-03-05 15:07:11.84006-06	2026-03-05 15:07:11.84006-06	\N	\N
task-41	Task Cleanup: Mark completed subtasks in parent tasks	archived	alfred	low	Update parent tasks (task-7 Calendar, task-8 Second Brain) to mark all completed subtasks properly. Ensures accurate completion metrics and clean task hierarchy.	\N	\N	2026-03-05 09:34:51.995-06	2026-03-05 15:07:27.720041-06	2026-03-05 15:07:49.663636-06	2026-03-05 15:07:49.663636-06	\N	\N
task-43	Implement Auto-Task-Status-Update Hook	archived	alfred	high	When subagent completes, automatically update PostgreSQL tasks table with status=done. No manual intervention. Make atomic with completion.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 15:26:19.100462-06	2026-03-05 17:44:01.515389-06	2026-03-05 17:44:01.515389-06	\N	\N
task-45	Create Pre-Deployment Testing Checklist	archived	alfred	high	Test API endpoints before production, verify component imports, check response structures match frontend. Prevents deployment bugs.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 17:46:16.828762-06	2026-03-05 17:49:06.079145-06	2026-03-05 17:49:06.079145-06	\N	\N
task-49	Institutionalize Post-Mortem Process	archived	alfred	high	Create TEMPLATE-POSTMORTEM.md, completed first post-mortem on 2026-03-05 PostgreSQL migration	\N	\N	2026-03-05 15:21:31.49627-06	2026-03-05 15:21:31.49627-06	2026-03-05 22:27:01.060449-06	2026-03-05 22:27:01.060449-06	\N	\N
task-44	Add Subagent Health Monitoring	archived	jeeves	high	Poll active sessions every 5 min, auto-re-spawn if session disappears, alert if respawn needed. Prevents silent failures.	\N	28daf48a-79c5-4f84-854a-7ad80a625d18	2026-03-05 15:21:47.810493-06	2026-03-05 16:14:11.468096-06	2026-03-05 19:33:24.6891-06	2026-03-05 19:33:24.6891-06	\N	\N
task-47	Add Deployment Testing Pipeline	archived	jeeves	medium	Spin up test instance, run smoke tests, verify APIs before live. Catch bugs before user impact.	\N	test-run-456	2026-03-05 15:21:47.810493-06	2026-03-05 19:19:22.859484-06	2026-03-05 19:33:24.6891-06	2026-03-05 19:33:24.6891-06	\N	\N
task-46	Improve Error Logging System	archived	alfred	medium	Automated error tracking/alerting, link errors to git commits, monthly review process. Better signal-to-noise.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 19:33:35.895654-06	2026-03-05 21:34:47.297022-06	2026-03-05 21:34:47.297022-06	\N	\N
task-48	Simplify Password Strategy	archived	alfred	low	Use alphanumeric-only passwords in scripts, store secrets in env vars, document escaping requirements.	\N	\N	2026-03-05 15:21:47.810493-06	2026-03-05 22:02:00.552936-06	2026-03-05 23:08:02.527231-06	2026-03-05 23:00:01.510498-06	\N	\N
task-50	Calendar PostgreSQL Migration - Schema Design	archived	alfred	high	Design and create PostgreSQL tables for calendar_events and reminders. Add indexes for date queries, recurring patterns. Create migration script.	\N	\N	2026-03-06 06:57:26.910023-06	\N	2026-03-06 07:01:07.127084-06	2026-03-06 07:01:07.127084-06	\N	\N
task-51	Calendar PostgreSQL Migration - Data Import	archived	alfred	high	Write migration script to import existing JSON data (events.json, reminders.json) into PostgreSQL. Verify data integrity after import.	\N	task-51-migration	2026-03-06 06:57:26.910023-06	2026-03-06 07:00:24.067501-06	2026-03-06 07:01:07.187415-06	2026-03-06 07:01:07.187415-06	\N	\N
task-52	Calendar PostgreSQL Migration - Backend Library Update	archived	alfred	high	Update src/lib/calendar/events.ts to use PostgreSQL queries instead of file system operations. Update all CRUD functions: getEvents, getReminders, createEvent, updateEvent, deleteEvent, etc.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:01:07.25672-06	2026-03-06 07:03:19.734737-06	2026-03-06 07:03:19.734737-06	\N	\N
task-53	Calendar PostgreSQL Migration - API Testing	archived	alfred	medium	Verify all calendar API routes work with PostgreSQL backend. Test /api/calendar/month, /api/calendar/events, and any CRUD endpoints.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:03:19.820398-06	2026-03-06 07:06:17.082261-06	2026-03-06 07:06:17.082261-06	\N	\N
task-54	Calendar PostgreSQL Migration - UI Verification	archived	jeeves	medium	Test Mission Control calendar UI with PostgreSQL backend. Verify monthly view, daily view, widgets, event creation/editing forms.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:06:17.183565-06	2026-03-06 07:06:35.893887-06	2026-03-06 07:06:35.893887-06	\N	\N
task-55	Calendar PostgreSQL Migration - Cleanup & Docs	archived	alfred	low	Archive old JSON calendar files (do not delete). Update documentation. Add migration notes to OPERATIONAL-RUNBOOK.md.	\N	\N	2026-03-06 06:57:26.910023-06	2026-03-06 07:06:35.991003-06	2026-03-06 07:07:21.274709-06	2026-03-06 07:07:21.274709-06	\N	\N
task-68	Self-Healing System	archived	\N	medium	Auto-restart services when they crash (Mission Control, Gateway, Ollama) with Telegram alerts. Impact: Higher uptime, proactive alerting. Effort: 2-3 hours	\N	\N	2026-03-11 14:23:41.822763-05	2026-03-11 15:37:29.45455-05	2026-03-11 15:43:02.26091-05	2026-03-11 15:43:02.26091-05	\N	\N
dadjoke-16	Create Dad Joke Video #16	archived	alfred	medium	What invention lets us see through walls? Windows.	\N	\N	2026-03-09 14:38:10.350449-05	2026-03-10 12:24:09.013388-05	\N	2026-03-10 18:00:42.920978-05	\N	\N
dadjoke-17	Create Dad Joke Video #17	archived	alfred	medium	I have a fossil joke but you probably wouldn't dig it.	\N	70d0f39b-cce1-4aec-9e3e-61ba1b3d6601	2026-03-09 14:38:10.350449-05	2026-03-10 18:06:50.811481-05	\N	2026-03-10 18:07:13.834345-05	\N	\N
task-42	Make Mission Control responsive for multiple screen sizes (desktop, tablet, phone)	archived	jeeves	medium	Implement responsive design for Mission Control dashboard to support desktop, tablet, and mobile devices. Use CSS Grid/Flexbox, media queries, and consider a mobile-first approach. Target breakpoints: 320px (phone), 768px (tablet), 1024px (desktop). [ARCHIVED - Mobile app scope changed]	\N	\N	2026-03-05 13:32:43.286-06	\N	2026-03-05 14:57:15.98632-06	2026-03-12 13:49:50.105975-05	\N	\N
task-70	Mission Control Mobile App	archived	auto-pool	low	Original epic - broken into subtasks [ARCHIVED - Mobile app scope changed]	\N	\N	2026-03-11 14:23:41.824673-05	\N	2026-03-11 16:44:27.947072-05	2026-03-12 13:49:50.105975-05	\N	\N
task-70-1	Setup Flutter project structure	archived	alfred	medium	Initialize Flutter project with proper folder structure, pubspec.yaml, and basic navigation. 1-2 hours. [ARCHIVED - Mobile app scope changed]	\N	\N	2026-03-11 16:44:27.949211-05	\N	\N	2026-03-12 13:49:50.105975-05	\N	\N
task-59	Send Kevin Vercel setup walkthrough	archived	alfred	high	Create and send detailed walkthrough for Kevin to set up Vercel and grant deploy access [ARCHIVED - Vercel deployment not needed, using ddns.net port forwarding]	\N	\N	2026-03-06 09:27:12.79568-06	\N	2026-03-06 10:29:01.860165-06	2026-03-12 13:49:50.163107-05	\N	\N
task-56	Create Vercel-deployable Dinner Roulette web app with Sven	archived	jeeves	high	Collaborate with Sven to create a Next.js/React web version of Dinner Roulette that can be deployed to Vercel. Extract core logic from Flutter app, rebuild as responsive web app. [ARCHIVED - Mobile app scope changed] [ARCHIVED - Vercel deployment not needed, using ddns.net port forwarding]	\N	1687916c-8871-46b4-bb61-72da4be1d63d	2026-03-06 09:26:18.179053-06	2026-03-06 09:27:12.625592-06	2026-03-06 09:59:13.694293-06	2026-03-12 13:49:50.163107-05	\N	\N
task-70-2	Build login screen with auth	archived	alfred	high	✅ COMPLETED (March 3) - Login screen built with JWT auth. [Mobile app scope archived]	\N	\N	2026-03-11 16:44:27.949211-05	\N	\N	2026-03-12 14:03:03.629309-05	\N	\N
task-69	Sub-Agent Pool Management	archived	\N	medium	Dynamic sub-agent spawning based on workload (scale up when backlog grows, scale down when idle). Impact: Better resource utilization. Effort: 3-4 hours	\N	\N	2026-03-11 14:23:41.823647-05	2026-03-11 15:48:32.562925-05	2026-03-11 15:51:35.399625-05	2026-03-11 15:51:35.399625-05	\N	\N
task-72-3	Implement 30-day retention cleanup	archived	alfred	medium	Delete backups older than 30 days from MinIO	\N	\N	2026-03-11 14:51:00.78086-05	2026-03-11 14:52:28.803436-05	2026-03-11 14:52:36.331607-05	2026-03-11 14:52:36.331607-05	\N	\N
task-72-4	Add cron job for nightly execution	archived	alfred	high	Schedule backup at 2 AM via cron	\N	\N	2026-03-11 14:51:00.78086-05	2026-03-11 14:52:36.331607-05	2026-03-11 14:53:10.190987-05	2026-03-11 14:53:10.190987-05	\N	\N
task-72-5	Document restoration procedure	archived	alfred	medium	Write runbook for restoring from backup	\N	\N	2026-03-11 14:51:00.78086-05	2026-03-11 14:53:10.190987-05	2026-03-11 14:53:30.673745-05	2026-03-11 14:53:30.673745-05	\N	\N
task-71	AI Task Suggester	archived	\N	medium	Analyze completed work patterns + calendar to suggest high-value tasks automatically. Impact: Smarter prioritization. Effort: 4-6 hours	\N	\N	2026-03-11 14:23:41.825325-05	2026-03-11 15:58:59.5691-05	2026-03-11 16:00:41.646044-05	2026-03-11 16:00:41.646044-05	\N	\N
task-72	PostgreSQL Auto-Backup	archived	alfred	high	Nightly backup of mission_control database to MinIO with 30-day retention. Impact: Disaster recovery. Effort: 1 hour	\N	\N	2026-03-11 14:50:49.574324-05	\N	2026-03-13 00:03:09.186355-05	2026-03-13 00:03:09.186355-05	\N	\N
T-104	Natural language reminder parser	archived	alfred	medium	Task ID: T-104\n\nTitle: Natural language reminder parser\n\nDescription: Parse natural language reminders like Remind me to call Mom at 4:30 and create database entries\n\nDeliverables: Working parser that detects Remind me to X at TIME pattern\n\nAssigned Agent: alfred\n\nStatus: READY\n\nValidation Criteria:\n- Parser detects pattern\n- Time parsing works\n- PostgreSQL insert works	\N	\N	2026-03-18 09:01:20.438729-05	2026-03-18 09:01:27.497041-05	2026-03-18 09:01:59.709199-05	2026-03-18 09:01:20.438729-05	Working parser that detects Remind me to X at TIME pattern	{"Parser detects pattern","Time parsing works","PostgreSQL insert works"}
mc-03	Add real-time push updates via websocket	done	alfred	medium	Push events via websocket instead of polling	\N	\N	2026-04-14 18:42:46.546338-05	\N	2026-04-14 19:52:35.881969-05	2026-04-14 18:42:46.546338-05	Working websocket with event push on task/status changes	\N
\.


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alfred
--

SELECT pg_catalog.setval('public.agents_id_seq', 7, true);


--
-- Name: event_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alfred
--

SELECT pg_catalog.setval('public.event_log_id_seq', 9, true);


--
-- Name: task_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alfred
--

SELECT pg_catalog.setval('public.task_history_id_seq', 379, true);


--
-- Name: agents agents_name_key; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_name_key UNIQUE (name);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: event_log event_log_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.event_log
    ADD CONSTRAINT event_log_pkey PRIMARY KEY (id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: screensaver_prompts screensaver_prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.screensaver_prompts
    ADD CONSTRAINT screensaver_prompts_pkey PRIMARY KEY (id);


--
-- Name: screensaver_prompts screensaver_prompts_video_number_prompt_number_key; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.screensaver_prompts
    ADD CONSTRAINT screensaver_prompts_video_number_prompt_number_key UNIQUE (video_number, prompt_number);


--
-- Name: subagents subagents_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.subagents
    ADD CONSTRAINT subagents_pkey PRIMARY KEY (run_id);


--
-- Name: task_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_agents_status ON public.agents USING btree (status);


--
-- Name: idx_event_log_channel; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_event_log_channel ON public.event_log USING btree (channel);


--
-- Name: idx_event_log_created; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_event_log_created ON public.event_log USING btree (created_at DESC);


--
-- Name: idx_events_date; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_events_date ON public.calendar_events USING btree (date);


--
-- Name: idx_events_recurring; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_events_recurring ON public.calendar_events USING btree (recurring_rule) WHERE (recurring_rule IS NOT NULL);


--
-- Name: idx_events_type; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_events_type ON public.calendar_events USING btree (type);


--
-- Name: idx_reminders_completed; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_reminders_completed ON public.reminders USING btree (completed) WHERE (completed = false);


--
-- Name: idx_reminders_due_date; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_reminders_due_date ON public.reminders USING btree (due_date);


--
-- Name: idx_reminders_recurring; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_reminders_recurring ON public.reminders USING btree (recurring_rule) WHERE (recurring_rule IS NOT NULL);


--
-- Name: idx_subagents_status; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_subagents_status ON public.subagents USING btree (status);


--
-- Name: idx_task_history_task_id; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_task_history_task_id ON public.task_history USING btree (task_id);


--
-- Name: idx_task_history_timestamp; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_task_history_timestamp ON public.task_history USING btree ("timestamp");


--
-- Name: idx_tasks_assignee; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_tasks_assignee ON public.tasks USING btree (assignee);


--
-- Name: idx_tasks_column; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_tasks_column ON public.tasks USING btree (column_name);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: alfred
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (column_name, priority);


--
-- Name: tasks trg_auto_archive; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER trg_auto_archive BEFORE UPDATE ON public.tasks FOR EACH ROW WHEN ((((old.column_name)::text = 'DONE'::text) AND ((new.column_name)::text = 'DONE'::text))) EXECUTE FUNCTION public.trigger_auto_archive_done_tasks();


--
-- Name: tasks trg_new_task_after; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER trg_new_task_after AFTER INSERT ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.trigger_new_task_after();


--
-- Name: tasks trg_new_task_before; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER trg_new_task_before BEFORE INSERT ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.trigger_new_task_before();


--
-- Name: tasks trg_status_change; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER trg_status_change AFTER UPDATE OF column_name ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.trigger_task_status_change();


--
-- Name: calendar_events update_calendar_events_updated_at; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER update_calendar_events_updated_at BEFORE UPDATE ON public.calendar_events FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: reminders update_reminders_updated_at; Type: TRIGGER; Schema: public; Owner: alfred
--

CREATE TRIGGER update_reminders_updated_at BEFORE UPDATE ON public.reminders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: task_history task_history_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alfred
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO alfred;


--
-- PostgreSQL database dump complete
--

\unrestrict 7Vr3iBqoXZrC3FQk7RN0Py9xTqL3eD6xm0kg8bLZ289fUeROG4IQB4vvYT7vdyp


#!/bin/bash
# Generate one SD image with timeout handling
IMG_NUM=$1
PROMPT="$2"
OUTPUT="/home/kevin/.openclaw/workspace/images/library_$(printf '%02d' $IMG_NUM).png"

echo "[$(date '+%H:%M:%S')] Starting image $IMG_NUM: ${PROMPT:0:50}..."

curl -s -X POST http://192.168.1.33:7860/sdapi/v1/txt2img \
  -H "Content-Type: application/json" \
  -d "{
    \"prompt\": \"$PROMPT\",
    \"negative_prompt\": \"ugly, blurry, low quality, distorted, deformed, text, watermark\",
    \"steps\": 25,
    \"width\": 1920,
    \"height\": 1080,
    \"cfg_scale\": 7,
    \"seed\": -1
  }" | python3 -c "
import sys, base64, json
try:
    d = json.load(sys.stdin)
    if 'images' in d and len(d['images']) > 0:
        open('$OUTPUT', 'wb').write(base64.b64decode(d['images'][0]))
        print('[$(date \"+%H:%M:%S\")] ✓ Image $IMG_NUM saved to $OUTPUT')
    else:
        print('[$(date \"+%H:%M:%S\")] ✗ Image $IMG_NUM failed: no images in response')
        sys.exit(1)
except Exception as e:
    print(f'[$(date \"+%H:%M:%S\")] ✗ Image $IMG_NUM error: {e}')
    sys.exit(1)
"

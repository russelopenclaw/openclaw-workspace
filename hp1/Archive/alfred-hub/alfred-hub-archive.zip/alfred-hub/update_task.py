#!/usr/bin/env python3
"""
Helper script for agents to update kanban tasks.
Usage: python3 update_task.py --task ss-aurora2-images --status complete
"""

import json
import argparse
from datetime import datetime

def update_task(task_id, status, notes=None):
    tasks_path = '/home/kevin/.openclaw/workspace/alfred-hub/tasks.json'
    
    with open(tasks_path, 'r') as f:
        data = json.load(f)
    
    # Find and update task
    found = False
    for task in data['epics']['revenue-products']['tasks']:
        if task['id'] == task_id:
            task['status'] = status
            if status == 'in-progress' and not task.get('startedAt'):
                task['startedAt'] = datetime.now().isoformat() + 'Z'
            if status == 'complete':
                task['completedAt'] = datetime.now().isoformat() + 'Z'
            if notes:
                task['notes'] = notes
            found = True
            break
    
    if not found:
        print(f"Task {task_id} not found")
        return
    
    # Update columns
    cols = data['columns']
    for col_name, col_data in cols.items():
        task_ids = col_data.get('taskIds', [])
        if task_id in task_ids:
            if col_name != status_to_column(status):
                task_ids.remove(task_id)
        if col_name == status_to_column(status) and task_id not in task_ids:
            task_ids.append(task_id)
    
    # Update agent status
    data['agents']['alfred']['lastActivity'] = datetime.now().isoformat() + 'Z'
    
    # Write back
    with open(tasks_path, 'w') as f:
        json.dump(data, f, indent=2)
    
    print(f"✅ Updated {task_id} to {status}")

def status_to_column(status):
    mapping = {
        'todo': 'todo',
        'backlog': 'todo',
        'in-progress': 'in-progress',
        'complete': 'complete'
    }
    return mapping.get(status, 'todo')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Update kanban task')
    parser.add_argument('--task', required=True, help='Task ID (e.g., ss-aurora2-images)')
    parser.add_argument('--status', required=True, choices=['todo', 'in-progress', 'complete'])
    parser.add_argument('--notes', help='Optional notes to add')
    
    args = parser.parse_args()
    update_task(args.task, args.status, args.notes)

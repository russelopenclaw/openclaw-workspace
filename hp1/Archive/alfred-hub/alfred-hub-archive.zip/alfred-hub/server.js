const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8765;
const BASE_DIR = '/home/kevin/.openclaw/workspace/alfred-hub';
const DOCS_DIR = '/home/kevin/.openclaw/workspace/docs';

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.md': 'text/markdown',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif'
};

function getMime(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return MIME_TYPES[ext] || 'application/octet-stream';
}

function loadJSON(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch(e) {
    return null;
  }
}

function saveJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

const server = http.createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }
  
  // POST /save - Save quick capture to tasks.json
  if (req.method === 'POST' && req.url === '/save') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { type, title, text, date, time } = JSON.parse(body);
        
        // Load tasks.json
        const tasksPath = path.join(BASE_DIR, 'tasks.json');
        const tasks = loadJSON(tasksPath) || { meta: {}, agents: {}, calendar: {}, epics: {} };
        
        if (!tasks.calendar) tasks.calendar = {};
        
        if (type === 'reminder') {
          // Add to reminders
          if (!tasks.calendar.reminders) tasks.calendar.reminders = [];
          tasks.calendar.reminders.unshift({
            id: Date.now().toString(),
            title: text || title,
            time: date + 'T' + (time || '09:00:00'),
            completed: false,
            createdAt: new Date().toISOString()
          });
        } else if (type === 'doc') {
          // Add to docs (in tasks.json for now, or docs.json)
          const docsPath = path.join(BASE_DIR, 'docs.json');
          const docs = loadJSON(docsPath) || { documents: [] };
          docs.documents.unshift({
            id: Date.now().toString(),
            title: title,
            keywords: [],
            createdAt: new Date().toISOString()
          });
          saveJSON(docsPath, docs);
        } else if (type === 'note') {
          // Add to knowledge.json (brain)
          const brainPath = path.join(BASE_DIR, 'knowledge.json');
          const brain = loadJSON(brainPath) || { items: [] };
          brain.items.unshift({
            id: Date.now().toString(),
            title: title || text,
            summary: text,
            type: 'note',
            tags: ['quick-capture'],
            createdAt: new Date().toISOString()
          });
          saveJSON(brainPath, brain);
        }
        
        // Always save tasks.json if we modified it
        saveJSON(tasksPath, tasks);
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, type }));
      } catch(e) {
        console.error('Save error:', e);
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }
  
  // GET requests - serve static files
  let filePath = req.url.split('?')[0]; // Strip query string
  let serveFromDocs = false;
  
  // Root goes to index.html
  if (filePath === '/') {
    filePath = '/index.html';
  }
  
  // /docs/* routes to workspace/docs/
  if (filePath.startsWith('/docs/')) {
    serveFromDocs = true;
    filePath = filePath.substring(6); // Remove '/docs/' prefix (6 chars)
  }
  
  if (serveFromDocs) {
    filePath = path.join(DOCS_DIR, filePath);
    // Security: prevent directory traversal
    if (!filePath.startsWith(DOCS_DIR)) {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }
  } else {
    filePath = path.join(BASE_DIR, filePath);
    // Security: prevent directory traversal
    if (!filePath.startsWith(BASE_DIR)) {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }
  }
  
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found: ' + req.url);
      return;
    }
    res.writeHead(200, { 'Content-Type': getMime(filePath) });
    res.end(data);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});

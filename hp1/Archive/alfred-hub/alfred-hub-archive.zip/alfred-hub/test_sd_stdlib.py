#!/usr/bin/env python3
import http.client
import base64
import json

SD_HOST = "192.168.1.33"
SD_PORT = 7860

print("Testing Stable Diffusion API connection...")

try:
    conn = http.client.HTTPConnection(SD_HOST, SD_PORT, timeout=120)
    
    payload = {
        "prompt": "simple test image, plain background, minimalist",
        "negative_prompt": "",
        "steps": 15,
        "width": 512,
        "height": 512,
        "cfg_scale": 7,
        "seed": -1
    }
    
    headers = {"Content-Type": "application/json"}
    
    print(f"Sending request to http://{SD_HOST}:{SD_PORT}/sdapi/v1/txt2img...")
    conn.request("POST", "/sdapi/v1/txt2img", json.dumps(payload), headers)
    
    response = conn.getresponse()
    print(f"Status: {response.status}")
    
    body = response.read().decode('utf-8')
    
    if response.status == 200:
        data = json.loads(body)
        print(f"Response keys: {list(data.keys())}")
        
        if 'images' in data and len(data['images']) > 0:
            img_data = data['images'][0]
            img_bytes = base64.b64decode(img_data)
            
            with open('/home/kevin/.openclaw/workspace/alfred-hub/images/test.png', 'wb') as f:
                f.write(img_bytes)
            
            print(f"✓ Test image saved! Size: {len(img_bytes)} bytes")
        else:
            print(f"Error: No images in response")
            print(json.dumps(data, indent=2)[:1000])
    else:
        print(f"Error: HTTP {response.status}")
        print(body[:500])
        
    conn.close()
        
except Exception as e:
    print(f"Error: {type(e).__name__}: {e}")

#!/usr/bin/env python3
import requests
import base64
import json

SD_URL = "http://192.168.1.33:7860"

print("Testing Stable Diffusion API connection...")

try:
    # Test the endpoint
    payload = {
        "prompt": "simple test image, plain background",
        "negative_prompt": "",
        "steps": 10,
        "width": 512,
        "height": 512,
        "cfg_scale": 7,
        "seed": -1
    }
    
    print(f"Sending request to {SD_URL}/sdapi/v1/txt2img...")
    response = requests.post(f"{SD_URL}/sdapi/v1/txt2img", json=payload, timeout=120)
    
    print(f"Status code: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"Response keys: {data.keys()}")
        
        if 'images' in data and len(data['images']) > 0:
            img_data = data['images'][0]
            img_bytes = base64.b64decode(img_data)
            
            with open('/home/kevin/.openclaw/workspace/alfred-hub/images/test.png', 'wb') as f:
                f.write(img_bytes)
            
            print(f"✓ Test image saved! Size: {len(img_bytes)} bytes")
        else:
            print(f"Error: No images in response")
            print(json.dumps(data, indent=2)[:1000])
    else:
        print(f"Error: HTTP {response.status_code}")
        print(response.text[:500])
        
except requests.exceptions.Timeout:
    print("Error: Request timed out (120s)")
except requests.exceptions.ConnectionError as e:
    print(f"Error: Connection failed - {e}")
except Exception as e:
    print(f"Error: {type(e).__name__}: {e}")

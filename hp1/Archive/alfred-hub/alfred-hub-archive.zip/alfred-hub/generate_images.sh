#!/bin/bash

# Generate 5 cozy fantasy library images for screensaver video
IMAGE_DIR="/home/kevin/.openclaw/workspace/alfred-hub/images"
SD_URL="http://192.168.1.33:7860/sdapi/v1/txt2img"

# Common negative prompt
NEG_PROMPT="ugly, duplicate, text, watermark, blurry, low quality, distorted, deformed, ugly, bad anatomy, disfigured"

# Prompt variations for the library theme
PROMPTS=(
  "cozy fantasy library interior, warm candlelight, ancient books on wooden shelves, magical floating dust particles, ornate reading desk, gothic arched windows, atmospheric lighting, highly detailed, 8k, digital art"
  "fantasy library reading nook, comfortable leather chair by fireplace, bookshelves surrounding, soft warm glow, magical ambiance, intricate wood carvings, evening light through stained glass, cinematic, 8k"
  "grand library hall, spiral staircases, countless books, floating candles, magical atmosphere, medieval fantasy, ornate architecture, volumetric lighting, hyperdetailed, masterpiece"
  "cozy library corner, open ancient book on desk, quill pen, flickering candles, tower window with moonlight, dust particles in air, peaceful study space, warm tones, 8k render"
  "mystical library interior, magical glowing books on shelves, crystal ornaments, ancient scrolls, enchanted atmosphere, deep blues and warm golds, fantasy concept art, ultra detailed"
)

echo "Generating 5 Cozy Fantasy Library images for screensaver video..."

for i in "${!PROMPTS[@]}"; do
  IMG_NUM=$((i + 1))
  OUTPUT_FILE="$IMAGE_DIR/library_$(printf '%02d' $IMG_NUM).png"
  
  echo "Generating image $IMG_NUM/5..."
  
  curl -s -X POST "$SD_URL" \
    -H "Content-Type: application/json" \
    -d "{
      \"prompt\": \"${PROMPTS[$i]}\",
      \"negative_prompt\": \"$NEG_PROMPT\",
      \"steps\": 25,
      \"width\": 1920,
      \"height\": 1080,
      \"cfg_scale\": 7,
      \"seed\": -1,
      \"batch_size\": 1
    }" | python3 -c "
import sys, json, base64
data = json.load(sys.stdin)
if 'images' in data and len(data['images']) > 0:
    img_data = data['images'][0]
    with open('$OUTPUT_FILE', 'wb') as f:
        f.write(base64.b64decode(img_data))
    print('  Saved: $OUTPUT_FILE')
else:
    print('  Error: No image received')
    sys.exit(1)
"
  
  if [ $? -ne 0 ]; then
    echo "Failed to generate image $IMG_NUM"
    exit 1
  fi
done

echo ""
echo "✓ All 5 images generated successfully!"
ls -la "$IMAGE_DIR"/library_*.png
